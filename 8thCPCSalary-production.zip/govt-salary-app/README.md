# 🏛️ 8thCPCSalary.com — Government Employee Financial Super App

> India's #1 Platform for 8th Pay Commission Salary Calculations, DA Updates, News & AI Assistant

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/govt-salary-app)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🧮 **8th CPC Calculator** | Exact salary projection with fitment 1.92× – 3.68× |
| 📈 **DA Calculator** | Current DA + arrears calculation |
| 🔮 **DA Prediction Engine** | AI-powered DA forecast |
| 🏠 **HRA Calculator** | X, Y, Z city HRA with 7th & 8th CPC rates |
| 🏛️ **Pension Calculator** | OPS pension with commutation |
| 📊 **NPS Corpus** | Projected corpus with multiple return rates |
| 🎁 **Gratuity Calculator** | With tax implications |
| 🌴 **Leave Encashment** | EL encashment on retirement |
| ⬆️ **Promotion Calculator** | Pay fixation after promotion |
| 📋 **Salary Slip Generator** | Printable + downloadable PDF |
| 📄 **PDF Reports** | Professional government-styled reports |
| 🤖 **AI Assistant** | Gemini/OpenAI/DeepSeek powered chatbot |
| 📰 **News CMS** | Categorized articles with admin panel |
| 📜 **Orders Repository** | Searchable government orders |
| 👤 **User Auth** | Email + Google login via Supabase |
| 💾 **Saved Profiles** | Multi-profile management |
| 📱 **PWA** | Installable, offline-capable |
| 🌙 **Dark Mode** | Full dark theme support |
| 📊 **Charts** | Interactive Chart.js visualizations |

---

## 🚀 Quick Deploy to Vercel

### Step 1: Clone & Upload to GitHub

```bash
# 1. Extract the zip
unzip govt-salary-app.zip -d govt-salary-app
cd govt-salary-app

# 2. Initialize git
git init
git add .
git commit -m "Initial commit: 8th CPC Salary Super App"

# 3. Create GitHub repo and push
gh repo create govt-salary-app --public --push
# OR
git remote add origin https://github.com/YOUR_USERNAME/govt-salary-app.git
git push -u origin main
```

### Step 2: Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Add environment secrets
vercel secrets add supabase_url "https://YOUR_PROJECT.supabase.co"
vercel secrets add supabase_anon_key "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
vercel secrets add gemini_api_key "AIzaSy..."

# Deploy
vercel --prod
```

Or connect your GitHub repo at [vercel.com/new](https://vercel.com/new).

---

## 🗄️ Supabase Setup

### Step 1: Create Project
1. Go to [supabase.com](https://supabase.com)
2. Create a new project
3. Note your **Project URL** and **Anon Key** from Settings → API

### Step 2: Run Schema Migration
1. Go to your Supabase Dashboard → SQL Editor
2. Click "New Query"
3. Paste the entire contents of `data/schema.sql`
4. Click "Run"

### Step 3: Enable Google Auth (Optional)
1. Go to Authentication → Providers → Google
2. Add your Google OAuth credentials
3. Add `https://your-project.supabase.co/auth/v1/callback` to Google Console

### Step 4: Create Storage Buckets
Run in SQL Editor:
```sql
INSERT INTO storage.buckets (id, name, public) VALUES ('article-images', 'article-images', true);
INSERT INTO storage.buckets (id, name, public) VALUES ('order-pdfs', 'order-pdfs', true);
```

### Step 5: Set Admin Role
```sql
UPDATE public.profiles
SET role = 'admin'
WHERE email = 'your-admin@email.com';
```

---

## ⚙️ Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `SUPABASE_URL` | ✅ Yes | Your Supabase project URL |
| `SUPABASE_ANON_KEY` | ✅ Yes | Supabase anonymous/public key |
| `GEMINI_API_KEY` | ⚡ Recommended | Google Gemini API key for AI chat |
| `OPENAI_API_KEY` | Optional | OpenAI fallback for AI chat |
| `DEEPSEEK_API_KEY` | Optional | DeepSeek fallback for AI chat |

### Add to Vercel Dashboard
1. Go to your Vercel project → Settings → Environment Variables
2. Add each variable for **Production**, **Preview**, and **Development**

---

## 📊 Google Analytics Setup

The GA4 tracking ID `G-G9V3KYRB5F` is pre-configured. To use your own:

1. Replace `G-G9V3KYRB5F` in `index.html` (lines 2 occurrences)
2. Events automatically tracked:
   - `salary_calculated` — Every salary computation
   - `pdf_download` — PDF report downloads
   - `article_view` — News article opens
   - `ai_query` — AI assistant usage
   - `share_result` — Result sharing
   - And 10+ more custom events

---

## 📢 Google AdSense Setup

1. Replace `ca-pub-YOUR_ADSENSE_ID` in `index.html` (3 ad slots)
2. Replace `YOUR_TOP_AD_SLOT`, `YOUR_MID_AD_SLOT`, `YOUR_BOTTOM_AD_SLOT` with your Ad Unit IDs
3. Ads are lazy-loaded for performance

---

## 🔍 Google Search Console

1. Go to [search.google.com/search-console](https://search.google.com/search-console)
2. Add property: `https://8thcpcsalary.com`
3. Verify using HTML tag — replace `YOUR_GSC_VERIFICATION_CODE` in `index.html`
4. Submit `https://8thcpcsalary.com/sitemap.xml`

---

## 🔍 Microsoft Clarity

1. Go to [clarity.microsoft.com](https://clarity.microsoft.com)
2. Create project, copy Tracking ID
3. Replace `YOUR_CLARITY_ID` in `index.html`

---

## 🌐 Custom Domain Setup

### On Vercel
1. Go to Project → Settings → Domains
2. Add `8thcpcsalary.com`
3. Add DNS records at your registrar:
   - Type: `A`, Value: `76.76.19.19`
   - Type: `CNAME` for `www`, Value: `cname.vercel-dns.com`

---

## 👑 Admin Panel

Access the admin panel by:
1. Logging in with an admin account
2. Clicking the **👑 Admin** floating button
3. Or opening the user menu

### Admin Capabilities
- ✅ Create / Edit / Delete articles
- ✅ Upload government orders with PDF links
- ✅ View analytics dashboard
- ✅ Manage subscribers
- ✅ Moderate comments

---

## 🏗️ Project Structure

```
govt-salary-app/
├── index.html              # Main SPA entry point
├── manifest.json           # PWA manifest
├── sw.js                   # Service worker (PWA + offline)
├── robots.txt              # SEO crawler rules
├── sitemap.xml             # SEO sitemap
├── vercel.json             # Vercel deployment config
├── .env.example            # Environment variable template
├── README.md               # This file
├── LICENSE                 # MIT License
│
├── api/
│   └── ask-ai.js           # Serverless AI proxy (Gemini/OpenAI/DeepSeek)
│
├── css/
│   └── styles.css          # Complete UI stylesheet (dark mode, responsive)
│
├── js/
│   ├── app.js              # Core calculator engine (all 10+ calculators)
│   ├── supabase.js         # Database & auth layer
│   ├── charts.js           # Chart.js visualizations
│   ├── cms.js              # News, orders, admin panel
│   ├── ai.js               # AI chat UI & fallback engine
│   ├── pdf.js              # PDF report generator (jsPDF)
│   ├── analytics.js        # GA4 custom events & web vitals
│   └── utils.js            # Shared utilities
│
├── data/
│   └── schema.sql          # Complete Supabase database schema
│
└── images/
    └── icons/              # PWA icons (add your own 192px & 512px)
```

---

## 🔧 Local Development

```bash
# No build step needed — pure HTML/CSS/JS
# Use any static server:

# Python
python3 -m http.server 3000

# Node.js
npx serve . -p 3000

# VS Code Live Server extension
# Right-click index.html → Open with Live Server
```

---

## 📱 PWA Installation

The app is installable as a PWA. Add to home screen:
- **Android**: Chrome → Menu → "Add to Home Screen"
- **iOS**: Safari → Share → "Add to Home Screen"
- **Desktop**: Chrome address bar → Install icon

---

## 🔒 Security Features

- ✅ Content Security Policy headers
- ✅ X-Frame-Options: SAMEORIGIN
- ✅ XSS Protection headers
- ✅ Row Level Security on all Supabase tables
- ✅ API keys never exposed to frontend
- ✅ Input validation and sanitization
- ✅ Admin routes protected by Supabase RLS

---

## 📈 Performance Targets

| Metric | Target | Strategy |
|--------|--------|----------|
| Lighthouse Performance | > 95 | Lazy loading, minified assets |
| SEO Score | 100 | Complete meta, structured data |
| Accessibility | > 95 | ARIA labels, semantic HTML |
| First Contentful Paint | < 1.5s | Inline critical CSS |
| Largest Contentful Paint | < 2.5s | CDN assets, caching |

---

## 🗺️ Roadmap

- [ ] Multi-language support (Hindi, Telugu, Tamil)
- [ ] WhatsApp notification integration
- [ ] Salary comparison across departments
- [ ] State government employee support
- [ ] Mobile app (React Native)

---

## 📄 License

MIT License — See [LICENSE](./LICENSE) file.

---

## 🙏 Acknowledgements

- [Supabase](https://supabase.com) — Backend & Auth
- [Chart.js](https://chartjs.org) — Charts
- [jsPDF](https://github.com/parallax/jsPDF) — PDF generation
- [Google Fonts](https://fonts.google.com) — Plus Jakarta Sans
- Ministry of Finance, Government of India — Pay Commission data

---

**Built with ❤️ for India's 50 lakh+ Central Government Employees**

*8thCPCSalary.com — Trusted. Accurate. Updated Daily.*
