/**
 * sw.js — Service Worker for 8thCPCSalary.com PWA
 * Provides offline support, caching, and background sync
 */

const CACHE_VERSION = 'v2.1.0';
const STATIC_CACHE = `cpc8-static-${CACHE_VERSION}`;
const DYNAMIC_CACHE = `cpc8-dynamic-${CACHE_VERSION}`;
const API_CACHE = `cpc8-api-${CACHE_VERSION}`;

const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/css/styles.css',
  '/js/app.js',
  '/js/charts.js',
  '/js/cms.js',
  '/js/ai.js',
  '/js/pdf.js',
  '/js/supabase.js',
  '/manifest.json',
  '/images/icons/icon-192.png',
  '/images/icons/icon-512.png',
];

const CDN_CACHE_URLS = [
  'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans',
  'https://fonts.gstatic.com',
  'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js',
];

const CACHE_DURATION = {
  static: 7 * 24 * 60 * 60 * 1000,   // 7 days
  dynamic: 24 * 60 * 60 * 1000,       // 1 day
  api: 5 * 60 * 1000,                 // 5 minutes
};

// ── Install ──────────────────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll(STATIC_ASSETS.map(url => new Request(url, { cache: 'reload' })));
    }).catch(err => console.warn('SW install cache error:', err))
  );
  self.skipWaiting();
});

// ── Activate ─────────────────────────────────────────
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter(key => key.startsWith('cpc8-') && ![STATIC_CACHE, DYNAMIC_CACHE, API_CACHE].includes(key))
          .map(key => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

// ── Fetch Strategy ───────────────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET and non-http(s)
  if (request.method !== 'GET') return;
  if (!url.protocol.startsWith('http')) return;

  // API calls — Network first, short cache fallback
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(networkFirstWithCache(request, API_CACHE, CACHE_DURATION.api));
    return;
  }

  // Supabase API — Network only (no cache for auth/data)
  if (url.hostname.includes('supabase.co')) return;

  // Static assets — Cache first
  if (isStaticAsset(url.pathname)) {
    event.respondWith(cacheFirstWithNetwork(request, STATIC_CACHE));
    return;
  }

  // CDN assets — Cache first with long TTL
  if (isCDNAsset(url.href)) {
    event.respondWith(cacheFirstWithNetwork(request, DYNAMIC_CACHE));
    return;
  }

  // HTML pages — Network first, offline fallback
  if (request.headers.get('accept')?.includes('text/html')) {
    event.respondWith(networkFirstWithOfflineFallback(request));
    return;
  }

  // Everything else — Stale while revalidate
  event.respondWith(staleWhileRevalidate(request, DYNAMIC_CACHE));
});

// ── Caching Strategies ───────────────────────────────
async function cacheFirstWithNetwork(request, cacheName) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    return new Response('Offline — resource not cached', { status: 503 });
  }
}

async function networkFirstWithCache(request, cacheName, maxAge) {
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(cacheName);
      const toCache = response.clone();
      // Add timestamp header
      const headers = new Headers(toCache.headers);
      headers.set('sw-cached-at', Date.now().toString());
      const body = await toCache.blob();
      cache.put(request, new Response(body, { status: response.status, headers }));
    }
    return response;
  } catch {
    const cached = await caches.match(request);
    if (cached) {
      const cachedAt = parseInt(cached.headers.get('sw-cached-at') || '0');
      if (Date.now() - cachedAt < maxAge) return cached;
    }
    return new Response(JSON.stringify({ error: 'Offline — AI not available' }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function networkFirstWithOfflineFallback(request) {
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(DYNAMIC_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    const cached = await caches.match(request) || await caches.match('/index.html');
    return cached || offlinePage();
  }
}

async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  const fetchPromise = fetch(request).then(response => {
    if (response.ok) cache.put(request, response.clone());
    return response;
  }).catch(() => null);
  return cached || await fetchPromise || new Response('Offline', { status: 503 });
}

function offlinePage() {
  return new Response(`
    <!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Offline — 8thCPCSalary.com</title>
    <style>
      body{font-family:sans-serif;background:#F4F5F9;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px}
      .card{background:white;border-radius:16px;padding:40px;max-width:400px;text-align:center;box-shadow:0 4px 20px rgba(0,0,0,.1)}
      h1{color:#E8751A;font-size:1.5rem}p{color:#7A8AAA;font-size:.9rem;line-height:1.6}
      button{background:#E8751A;color:white;border:none;padding:12px 24px;border-radius:8px;cursor:pointer;font-size:.9rem;font-weight:700;margin-top:16px}
    </style></head><body>
    <div class="card">
      <div style="font-size:3rem;margin-bottom:16px">📡</div>
      <h1>You're Offline</h1>
      <p>8thCPCSalary.com requires an internet connection for latest data. Your saved calculations are still available.</p>
      <button onclick="location.reload()">Try Again</button>
    </div></body></html>
  `, { headers: { 'Content-Type': 'text/html' } });
}

// ── Helpers ──────────────────────────────────────────
function isStaticAsset(pathname) {
  return /\.(css|js|json|woff2?|ttf|eot)$/.test(pathname) ||
    STATIC_ASSETS.includes(pathname);
}

function isCDNAsset(href) {
  return CDN_CACHE_URLS.some(url => href.startsWith(url)) ||
    href.includes('fonts.gstatic.com') ||
    href.includes('cdn.jsdelivr.net') ||
    href.includes('cdnjs.cloudflare.com');
}

// ── Background Sync ──────────────────────────────────
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-calculations') {
    event.waitUntil(syncSavedCalculations());
  }
});

async function syncSavedCalculations() {
  // Sync locally saved calculations to Supabase when back online
  const clients = await self.clients.matchAll();
  clients.forEach(client => client.postMessage({ type: 'SYNC_READY' }));
}

// ── Push Notifications ───────────────────────────────
self.addEventListener('push', (event) => {
  const data = event.data?.json() || {};
  const options = {
    body: data.body || 'New update from 8thCPCSalary.com',
    icon: '/images/icons/icon-192.png',
    badge: '/images/icons/icon-72.png',
    tag: data.tag || 'cpc8-notification',
    renotify: true,
    vibrate: [100, 50, 100],
    data: { url: data.url || '/' },
    actions: [
      { action: 'view', title: 'View Update' },
      { action: 'dismiss', title: 'Dismiss' }
    ]
  };
  event.waitUntil(
    self.registration.showNotification(data.title || '8th CPC Update', options)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  if (event.action !== 'dismiss') {
    event.waitUntil(
      clients.openWindow(event.notification.data?.url || '/')
    );
  }
});
