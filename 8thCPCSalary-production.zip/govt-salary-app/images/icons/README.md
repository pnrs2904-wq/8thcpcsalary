# PWA Icons

Place the following icon files in this directory:

| File | Size | Purpose |
|------|------|---------|
| icon-72.png  | 72×72   | Android home screen |
| icon-96.png  | 96×96   | Android home screen |
| icon-128.png | 128×128 | Chrome Web Store |
| icon-144.png | 144×144 | Windows tiles |
| icon-152.png | 152×152 | iOS home screen |
| icon-192.png | 192×192 | PWA splash screen (maskable) |
| icon-384.png | 384×384 | High-DPI displays |
| icon-512.png | 512×512 | PWA install prompt (maskable) |

## Quick Generation

Use the included `icon.svg` as source:

```bash
# Install ImageMagick
brew install imagemagick  # macOS
apt install imagemagick   # Ubuntu

# Generate all sizes
for size in 72 96 128 144 152 192 384 512; do
  convert -background none icon.svg -resize ${size}x${size} icon-${size}.png
done
```

Or use an online tool like:
- https://realfavicongenerator.net/
- https://maskable.app/editor
- https://pwa-image-generator.firebaseapp.com/

## Design Guidelines

- Use a maskable icon (subject centered in 80% of canvas)
- Background: #002B7F (India Blue)
- Primary color: #E8751A (Saffron)
- Include the 🏛️ temple or "8CPC" text
