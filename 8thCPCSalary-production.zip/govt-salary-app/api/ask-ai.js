// api/ask-ai.js — Vercel Edge/Serverless function
// Proxies AI requests to keep API keys server-side

export const config = { runtime: 'edge' };

const SYSTEM_PROMPT = `You are an expert AI assistant for Indian government employees, specializing in:
- 8th Pay Commission (8th CPC) salary calculations
- Dearness Allowance (DA) calculations and predictions
- House Rent Allowance (HRA) for X, Y, Z cities
- Pension calculations (OPS/NPS)
- Gratuity, Leave Encashment calculations
- UPSC, SSC, Railway recruitment pay scales
- Government orders and circulars

Current facts (as of June 2026):
- Current DA: 62% (effective January 2026)
- Expected DA July 2026: 65%
- 8th CPC: Constituted, expected fitment factor 2.57× to 3.68×
- 7th CPC pay levels: Level 1 (₹18,000) to Level 18 (₹2,50,000)
- NPS: Employee 10%, Government 14% of (Basic+DA)
- Pension (OPS): 50% of last basic pay

Provide precise, actionable answers with:
- Exact calculations with step-by-step working
- Indian currency formatting (₹, lakhs, crores)
- References to relevant government orders when applicable
- Concise, well-structured responses`;

export default async function handler(request) {
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      }
    });
  }

  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405 });
  }

  try {
    const { message, history = [], system } = await request.json();
    if (!message) return new Response(JSON.stringify({ error: 'Message required' }), { status: 400 });

    const systemPrompt = system || SYSTEM_PROMPT;

    // Try Gemini first
    const geminiKey = process.env.GEMINI_API_KEY;
    if (geminiKey) {
      const geminiRes = await callGemini(message, history, systemPrompt, geminiKey);
      if (geminiRes) {
        return new Response(JSON.stringify({ response: geminiRes, provider: 'gemini' }), {
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
      }
    }

    // Try OpenAI
    const openaiKey = process.env.OPENAI_API_KEY;
    if (openaiKey) {
      const openaiRes = await callOpenAI(message, history, systemPrompt, openaiKey);
      if (openaiRes) {
        return new Response(JSON.stringify({ response: openaiRes, provider: 'openai' }), {
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
      }
    }

    // Try DeepSeek
    const deepseekKey = process.env.DEEPSEEK_API_KEY;
    if (deepseekKey) {
      const deepseekRes = await callDeepSeek(message, history, systemPrompt, deepseekKey);
      if (deepseekRes) {
        return new Response(JSON.stringify({ response: deepseekRes, provider: 'deepseek' }), {
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
      }
    }

    return new Response(JSON.stringify({ error: 'No AI provider configured. Add GEMINI_API_KEY, OPENAI_API_KEY, or DEEPSEEK_API_KEY to environment variables.' }), { status: 503 });

  } catch (err) {
    console.error('AI API error:', err);
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 });
  }
}

async function callGemini(message, history, systemPrompt, apiKey) {
  try {
    const contents = [
      ...history.map(h => ({ role: h.role === 'assistant' ? 'model' : 'user', parts: [{ text: h.content }] })),
      { role: 'user', parts: [{ text: message }] }
    ];
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: systemPrompt }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 1024 }
      })
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || null;
  } catch { return null; }
}

async function callOpenAI(message, history, systemPrompt, apiKey) {
  try {
    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map(h => ({ role: h.role, content: h.content })),
      { role: 'user', content: message }
    ];
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({ model: 'gpt-4o-mini', messages, max_tokens: 1024, temperature: 0.7 })
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.choices?.[0]?.message?.content || null;
  } catch { return null; }
}

async function callDeepSeek(message, history, systemPrompt, apiKey) {
  try {
    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map(h => ({ role: h.role, content: h.content })),
      { role: 'user', content: message }
    ];
    const res = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({ model: 'deepseek-chat', messages, max_tokens: 1024, temperature: 0.7 })
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.choices?.[0]?.message?.content || null;
  } catch { return null; }
}
