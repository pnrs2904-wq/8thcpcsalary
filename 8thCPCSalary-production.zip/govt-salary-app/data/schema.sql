-- ============================================================
-- 8thCPCSalary.com — Supabase Database Schema
-- Run this in Supabase SQL Editor > New Query
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- PROFILES (extends Supabase auth.users)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT,
  full_name TEXT,
  avatar_url TEXT,
  role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin', 'editor')),
  department TEXT,
  designation TEXT,
  pay_level INTEGER,
  basic_pay INTEGER,
  city_category TEXT DEFAULT 'Y' CHECK (city_category IN ('X', 'Y', 'Z')),
  date_of_joining DATE,
  date_of_retirement DATE,
  notifications_enabled BOOLEAN DEFAULT TRUE,
  dark_mode BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Admins can view all profiles" ON public.profiles FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- SAVED CALCULATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.saved_calculations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  calc_type TEXT NOT NULL CHECK (calc_type IN ('salary', 'da', 'hra', 'pension', 'nps', 'gratuity', 'leave', 'promotion', 'arrears', 'comparison')),
  label TEXT,
  inputs JSONB NOT NULL,
  results JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.saved_calculations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own calculations" ON public.saved_calculations FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- ARTICLES (News CMS)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.articles (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  excerpt TEXT,
  content TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('8th CPC', 'DA Update', 'Pension', 'NPS', 'Railways', 'Defence', 'SSC', 'UPSC', 'Teachers', 'Government Orders', 'Benefits', 'Retirement')),
  tags TEXT[] DEFAULT '{}',
  author_id UUID REFERENCES auth.users(id),
  author_name TEXT DEFAULT 'Editorial Team',
  featured_image TEXT,
  status TEXT DEFAULT 'published' CHECK (status IN ('draft', 'published', 'scheduled', 'archived')),
  is_featured BOOLEAN DEFAULT FALSE,
  is_trending BOOLEAN DEFAULT FALSE,
  views INTEGER DEFAULT 0,
  scheduled_at TIMESTAMPTZ,
  published_at TIMESTAMPTZ DEFAULT NOW(),
  meta_title TEXT,
  meta_description TEXT,
  structured_data JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read published articles" ON public.articles FOR SELECT USING (status = 'published');
CREATE POLICY "Admins/editors can manage articles" ON public.articles FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'editor'))
);

-- Increment article views
CREATE OR REPLACE FUNCTION public.increment_article_views(article_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE public.articles SET views = views + 1 WHERE id = article_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- GOVERNMENT ORDERS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.govt_orders (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title TEXT NOT NULL,
  order_number TEXT,
  department TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('Pay', 'DA', 'HRA', 'Pension', 'NPS', 'Leave', 'Promotion', 'Transfer', 'Recruitment', 'Training', 'Other')),
  year INTEGER NOT NULL,
  pdf_url TEXT,
  storage_path TEXT,
  summary TEXT,
  tags TEXT[] DEFAULT '{}',
  downloads INTEGER DEFAULT 0,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.govt_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view orders" ON public.govt_orders FOR SELECT USING (TRUE);
CREATE POLICY "Admins can manage orders" ON public.govt_orders FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

CREATE OR REPLACE FUNCTION public.increment_order_downloads(order_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE public.govt_orders SET downloads = downloads + 1 WHERE id = order_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- BOOKMARKS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.bookmarks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  content_type TEXT NOT NULL CHECK (content_type IN ('article', 'order', 'calculation')),
  content_id UUID NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, content_type, content_id)
);

ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own bookmarks" ON public.bookmarks FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- COMMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.comments (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  article_id UUID REFERENCES public.articles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  is_approved BOOLEAN DEFAULT FALSE,
  parent_id UUID REFERENCES public.comments(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read approved comments" ON public.comments FOR SELECT USING (is_approved = TRUE);
CREATE POLICY "Users can create comments" ON public.comments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins can manage comments" ON public.comments FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

-- ============================================================
-- SUBSCRIBERS (Newsletter)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.subscribers (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  category_prefs TEXT[] DEFAULT '{}',
  is_active BOOLEAN DEFAULT TRUE,
  subscribed_at TIMESTAMPTZ DEFAULT NOW(),
  unsubscribed_at TIMESTAMPTZ
);

ALTER TABLE public.subscribers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage subscribers" ON public.subscribers FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "Anyone can subscribe" ON public.subscribers FOR INSERT WITH CHECK (TRUE);

-- ============================================================
-- AI CHAT HISTORY
-- ============================================================
CREATE TABLE IF NOT EXISTS public.ai_conversations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL,
  messages JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.ai_conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own conversations" ON public.ai_conversations FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- ANALYTICS EVENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.analytics_events (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  event_type TEXT NOT NULL,
  event_data JSONB DEFAULT '{}',
  session_id TEXT,
  ip_hash TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.analytics_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert events" ON public.analytics_events FOR INSERT WITH CHECK (TRUE);
CREATE POLICY "Admins can view events" ON public.analytics_events FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

-- ============================================================
-- DA HISTORY (reference data)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.da_history (
  id SERIAL PRIMARY KEY,
  effective_date DATE NOT NULL,
  da_percent DECIMAL(5,2) NOT NULL,
  order_reference TEXT,
  notes TEXT
);

INSERT INTO public.da_history (effective_date, da_percent, order_reference, notes) VALUES
('2006-01-01', 2.00, '7th CPC Base', '7th CPC Baseline'),
('2016-01-01', 0.00, 'OM dated 10/10/2016', '7th CPC Reset'),
('2016-07-01', 2.00, 'OM dated 10/10/2016', 'First 7th CPC DA'),
('2017-01-01', 4.00, 'Cabinet approval', 'DA 4%'),
('2017-07-01', 5.00, 'Cabinet approval', 'DA 5%'),
('2018-01-01', 7.00, 'Cabinet approval', 'DA 7%'),
('2018-07-01', 9.00, 'Cabinet approval', 'DA 9%'),
('2019-01-01', 12.00, 'Cabinet approval', 'DA 12%'),
('2019-07-01', 17.00, 'Cabinet approval', 'DA 17%'),
('2020-01-01', 21.00, 'Cabinet approval', 'DA 21% (frozen due to COVID)'),
('2021-07-01', 28.00, 'Cabinet approval', 'Three instalments merged 17%+4%+3%+4%'),
('2022-01-01', 34.00, 'Cabinet approval', 'DA 34%'),
('2022-07-01', 38.00, 'Cabinet approval', 'DA 38%'),
('2023-01-01', 42.00, 'Cabinet approval', 'DA 42%'),
('2023-07-01', 46.00, 'Cabinet approval', 'DA 46%'),
('2024-01-01', 50.00, 'Cabinet approval', 'DA 50%'),
('2024-07-01', 53.00, 'Cabinet approval', 'DA 53%'),
('2025-01-01', 55.00, 'Cabinet approval', 'DA 55%'),
('2025-07-01', 59.00, 'Cabinet approval', 'DA 59% (projected)'),
('2026-01-01', 62.00, 'Cabinet approval', 'DA 62%'),
('2026-07-01', 65.00, 'Projected', 'DA 65% (projected)')
ON CONFLICT DO NOTHING;

-- ============================================================
-- PAY MATRIX (7th CPC - reference)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.pay_matrix_7th (
  pay_level INTEGER NOT NULL,
  cell_number INTEGER NOT NULL,
  basic_pay INTEGER NOT NULL,
  PRIMARY KEY (pay_level, cell_number)
);

-- ============================================================
-- INDEXES for performance
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_articles_status ON public.articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_category ON public.articles(category);
CREATE INDEX IF NOT EXISTS idx_articles_slug ON public.articles(slug);
CREATE INDEX IF NOT EXISTS idx_articles_featured ON public.articles(is_featured);
CREATE INDEX IF NOT EXISTS idx_articles_published_at ON public.articles(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_year ON public.govt_orders(year);
CREATE INDEX IF NOT EXISTS idx_orders_dept ON public.govt_orders(department);
CREATE INDEX IF NOT EXISTS idx_orders_category ON public.govt_orders(category);
CREATE INDEX IF NOT EXISTS idx_saved_calcs_user ON public.saved_calculations(user_id);
CREATE INDEX IF NOT EXISTS idx_bookmarks_user ON public.bookmarks(user_id);
CREATE INDEX IF NOT EXISTS idx_analytics_event_type ON public.analytics_events(event_type);
CREATE INDEX IF NOT EXISTS idx_analytics_created_at ON public.analytics_events(created_at DESC);

-- ============================================================
-- STORAGE BUCKETS (run in Storage tab or via API)
-- ============================================================
-- INSERT INTO storage.buckets (id, name, public) VALUES ('article-images', 'article-images', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('order-pdfs', 'order-pdfs', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('user-uploads', 'user-uploads', false);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('reports', 'reports', false);

-- ============================================================
-- SEED: Sample Articles
-- ============================================================
INSERT INTO public.articles (title, slug, excerpt, content, category, status, is_featured, is_trending, published_at) VALUES
(
  '8th Pay Commission: Expected Fitment Factor and Salary Structure Explained',
  '8th-pay-commission-fitment-factor-explained',
  'The 8th Central Pay Commission has been constituted. Here''s everything you need to know about the expected fitment factor ranging from 2.57x to 3.68x.',
  '<p>The Government of India has constituted the 8th Central Pay Commission (CPC) to review and recommend revisions in the pay structure for central government employees. The commission is expected to submit its recommendations by 2025-26 for implementation from January 2026.</p><h2>Expected Fitment Factor</h2><p>Based on historical trends and expert analysis, the expected fitment factor for the 8th CPC ranges between <strong>2.57x to 3.68x</strong>. The 7th CPC had implemented a fitment factor of 2.57x. Given inflation and cost of living adjustments, analysts expect a higher factor this time.</p><h2>Key Pay Levels</h2><p>The 8th CPC is expected to restructure pay levels from Level 1 to Level 18, with significant revisions across all grades.</p>',
  '8th CPC',
  'published',
  TRUE,
  TRUE,
  NOW() - INTERVAL '2 days'
),
(
  'DA Hike July 2026: Cabinet Expected to Approve 65% DA',
  'da-hike-july-2026-cabinet-approval',
  'The Union Cabinet is expected to approve the Dearness Allowance hike to 65% effective July 1, 2026. Calculate your revised DA arrears.',
  '<p>Central government employees are set for another DA hike as the Cabinet prepares to ratify the July 2026 installment. Based on AICPI data released for April and May 2026, the DA is projected to reach <strong>65%</strong> of basic pay.</p><h2>Impact on Salaries</h2><p>For an employee with basic pay of ₹44,900 (Level 7), the DA will increase from ₹27,838 to ₹29,185 — an increase of ₹1,347 per month. The arrears for April to June 2026 (3 months) will amount to approximately ₹4,041.</p>',
  'DA Update',
  'published',
  TRUE,
  TRUE,
  NOW() - INTERVAL '1 day'
),
(
  'NPS vs OPS: Complete Comparison for Government Employees 2026',
  'nps-vs-ops-comparison-2026',
  'A detailed comparison of the National Pension System (NPS) and Old Pension Scheme (OPS) to help government employees understand their retirement benefits.',
  '<p>One of the most debated topics among government employees is whether the National Pension System (NPS) provides adequate retirement security compared to the Old Pension Scheme (OPS). Here is a comprehensive analysis.</p><h2>Old Pension Scheme (OPS)</h2><p>OPS guaranteed 50% of the last drawn salary as pension, with full DA protection. It was a defined-benefit scheme with no contribution from the employee.</p><h2>National Pension System (NPS)</h2><p>NPS is a defined-contribution scheme where the employee contributes 10% of basic+DA, and the government contributes 14%. The accumulated corpus is used to purchase an annuity upon retirement.</p>',
  'NPS',
  'published',
  FALSE,
  FALSE,
  NOW() - INTERVAL '3 days'
)
ON CONFLICT (slug) DO NOTHING;
