/**
 * supabase.js — Supabase client initialization and data access layer
 * All DB operations go through this module.
 */

// ============================================================
// INITIALIZATION
// ============================================================
const SUPABASE_URL = window.__ENV?.SUPABASE_URL || '';
const SUPABASE_ANON_KEY = window.__ENV?.SUPABASE_ANON_KEY || '';

let supabase = null;

function initSupabase() {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    console.warn('Supabase not configured. Running in offline mode.');
    return null;
  }
  try {
    supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    console.log('✅ Supabase connected');
    setupAuthListener();
    return supabase;
  } catch (e) {
    console.error('Supabase init error:', e);
    return null;
  }
}

// ============================================================
// AUTH STATE
// ============================================================
let currentUser = null;
let userProfile = null;

function setupAuthListener() {
  if (!supabase) return;
  supabase.auth.onAuthStateChange(async (event, session) => {
    currentUser = session?.user || null;
    if (currentUser) {
      await loadUserProfile();
      updateAuthUI(true);
    } else {
      userProfile = null;
      updateAuthUI(false);
    }
  });
}

function updateAuthUI(isLoggedIn) {
  const authBtn = document.getElementById('authBtn');
  const userAvatar = document.getElementById('userAvatar');
  if (!authBtn) return;
  if (isLoggedIn) {
    authBtn.style.display = 'none';
    if (userAvatar) {
      userAvatar.style.display = 'flex';
      const initial = (currentUser.email || 'U').charAt(0).toUpperCase();
      userAvatar.textContent = initial;
    }
    // Show admin badge if admin
    if (userProfile?.role === 'admin' || userProfile?.role === 'editor') {
      const adminBadge = document.getElementById('adminBadge');
      if (adminBadge) adminBadge.classList.add('visible');
    }
  } else {
    authBtn.style.display = 'flex';
    if (userAvatar) userAvatar.style.display = 'none';
    const adminBadge = document.getElementById('adminBadge');
    if (adminBadge) adminBadge.classList.remove('visible');
  }
}

// ============================================================
// AUTH METHODS
// ============================================================
async function signInWithEmail(email, password) {
  if (!supabase) throw new Error('Supabase not configured');
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

async function signUpWithEmail(email, password, fullName) {
  if (!supabase) throw new Error('Supabase not configured');
  const { data, error } = await supabase.auth.signUp({
    email, password,
    options: { data: { full_name: fullName } }
  });
  if (error) throw error;
  return data;
}

async function signInWithGoogle() {
  if (!supabase) throw new Error('Supabase not configured');
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: window.location.origin }
  });
  if (error) throw error;
  return data;
}

async function signOut() {
  if (!supabase) return;
  await supabase.auth.signOut();
  currentUser = null;
  userProfile = null;
  showToast('Signed out successfully', 'info');
}

async function loadUserProfile() {
  if (!supabase || !currentUser) return null;
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', currentUser.id)
    .single();
  if (!error && data) userProfile = data;
  return userProfile;
}

async function updateUserProfile(updates) {
  if (!supabase || !currentUser) throw new Error('Not authenticated');
  const { data, error } = await supabase
    .from('profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', currentUser.id)
    .select()
    .single();
  if (error) throw error;
  userProfile = data;
  return data;
}

// ============================================================
// ARTICLES
// ============================================================
async function fetchArticles({ category, limit = 12, offset = 0, search, featured, trending } = {}) {
  if (!supabase) return { data: getLocalArticles(), count: getLocalArticles().length };
  let query = supabase
    .from('articles')
    .select('id, title, slug, excerpt, category, tags, author_name, featured_image, is_featured, is_trending, views, published_at', { count: 'exact' })
    .eq('status', 'published')
    .order('published_at', { ascending: false })
    .range(offset, offset + limit - 1);
  if (category) query = query.eq('category', category);
  if (featured) query = query.eq('is_featured', true);
  if (trending) query = query.eq('is_trending', true);
  if (search) query = query.ilike('title', `%${search}%`);
  const { data, error, count } = await query;
  if (error) { console.error('fetchArticles:', error); return { data: [], count: 0 }; }
  return { data: data || [], count };
}

async function fetchArticleBySlug(slug) {
  if (!supabase) return getLocalArticles().find(a => a.slug === slug) || null;
  const { data, error } = await supabase
    .from('articles')
    .select('*')
    .eq('slug', slug)
    .eq('status', 'published')
    .single();
  if (error) return null;
  // Increment views
  if (data?.id) supabase.rpc('increment_article_views', { article_id: data.id });
  return data;
}

async function createArticle(article) {
  if (!supabase || !currentUser) throw new Error('Not authenticated');
  const { data, error } = await supabase.from('articles').insert({
    ...article,
    author_id: currentUser.id,
    author_name: userProfile?.full_name || currentUser.email,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }).select().single();
  if (error) throw error;
  return data;
}

async function updateArticle(id, updates) {
  if (!supabase || !currentUser) throw new Error('Not authenticated');
  const { data, error } = await supabase
    .from('articles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data;
}

async function deleteArticle(id) {
  if (!supabase || !currentUser) throw new Error('Not authenticated');
  const { error } = await supabase.from('articles').delete().eq('id', id);
  if (error) throw error;
}

// ============================================================
// GOVERNMENT ORDERS
// ============================================================
async function fetchOrders({ department, category, year, search, limit = 20, offset = 0 } = {}) {
  if (!supabase) return { data: getLocalOrders(), count: getLocalOrders().length };
  let query = supabase
    .from('govt_orders')
    .select('*', { count: 'exact' })
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);
  if (department) query = query.eq('department', department);
  if (category) query = query.eq('category', category);
  if (year) query = query.eq('year', year);
  if (search) query = query.or(`title.ilike.%${search}%,order_number.ilike.%${search}%`);
  const { data, error, count } = await query;
  if (error) { console.error('fetchOrders:', error); return { data: [], count: 0 }; }
  return { data: data || [], count };
}

async function createOrder(order) {
  if (!supabase || !currentUser) throw new Error('Not authenticated');
  const { data, error } = await supabase.from('govt_orders').insert({
    ...order,
    created_by: currentUser.id,
    created_at: new Date().toISOString()
  }).select().single();
  if (error) throw error;
  return data;
}

// ============================================================
// SAVED CALCULATIONS
// ============================================================
async function saveCalculation(calcType, label, inputs, results) {
  const calc = { calc_type: calcType, label: label || `${calcType} - ${new Date().toLocaleDateString('en-IN')}`, inputs, results, created_at: new Date().toISOString() };
  if (!supabase || !currentUser) {
    // Save locally
    const local = JSON.parse(localStorage.getItem('saved_calcs') || '[]');
    local.unshift({ id: Date.now(), user_id: 'local', ...calc });
    localStorage.setItem('saved_calcs', JSON.stringify(local.slice(0, 50)));
    return calc;
  }
  const { data, error } = await supabase.from('saved_calculations').insert({
    ...calc,
    user_id: currentUser.id
  }).select().single();
  if (error) throw error;
  return data;
}

async function fetchSavedCalculations(calcType) {
  if (!supabase || !currentUser) {
    const local = JSON.parse(localStorage.getItem('saved_calcs') || '[]');
    return calcType ? local.filter(c => c.calc_type === calcType) : local;
  }
  let query = supabase.from('saved_calculations').select('*').eq('user_id', currentUser.id).order('created_at', { ascending: false });
  if (calcType) query = query.eq('calc_type', calcType);
  const { data, error } = await query;
  if (error) return [];
  return data || [];
}

async function deleteSavedCalculation(id) {
  if (!supabase || !currentUser) {
    const local = JSON.parse(localStorage.getItem('saved_calcs') || '[]');
    localStorage.setItem('saved_calcs', JSON.stringify(local.filter(c => c.id !== id)));
    return;
  }
  await supabase.from('saved_calculations').delete().eq('id', id).eq('user_id', currentUser.id);
}

// ============================================================
// BOOKMARKS
// ============================================================
async function toggleBookmark(contentType, contentId) {
  if (!supabase || !currentUser) {
    const key = `bookmark_${contentType}_${contentId}`;
    const exists = localStorage.getItem(key);
    if (exists) { localStorage.removeItem(key); return false; }
    else { localStorage.setItem(key, '1'); return true; }
  }
  const { data: existing } = await supabase
    .from('bookmarks')
    .select('id')
    .eq('user_id', currentUser.id)
    .eq('content_type', contentType)
    .eq('content_id', contentId)
    .single();
  if (existing) {
    await supabase.from('bookmarks').delete().eq('id', existing.id);
    return false;
  } else {
    await supabase.from('bookmarks').insert({ user_id: currentUser.id, content_type: contentType, content_id: contentId });
    return true;
  }
}

async function isBookmarked(contentType, contentId) {
  if (!supabase || !currentUser) return !!localStorage.getItem(`bookmark_${contentType}_${contentId}`);
  const { data } = await supabase.from('bookmarks').select('id').eq('user_id', currentUser.id).eq('content_type', contentType).eq('content_id', contentId).single();
  return !!data;
}

// ============================================================
// SUBSCRIBERS
// ============================================================
async function subscribeNewsletter(email, name) {
  if (!supabase) {
    const subs = JSON.parse(localStorage.getItem('newsletter_subs') || '[]');
    if (subs.includes(email)) throw new Error('Already subscribed');
    subs.push(email);
    localStorage.setItem('newsletter_subs', JSON.stringify(subs));
    return { email };
  }
  const { data, error } = await supabase.from('subscribers').insert({ email, name, subscribed_at: new Date().toISOString() }).select().single();
  if (error) {
    if (error.code === '23505') throw new Error('Already subscribed');
    throw error;
  }
  return data;
}

// ============================================================
// ANALYTICS
// ============================================================
async function trackEvent(eventType, eventData = {}) {
  // GA4 tracking
  if (typeof gtag !== 'undefined') {
    gtag('event', eventType, eventData);
  }
  // Supabase tracking
  if (!supabase) return;
  supabase.from('analytics_events').insert({
    user_id: currentUser?.id || null,
    event_type: eventType,
    event_data: eventData,
    session_id: getSessionId(),
    created_at: new Date().toISOString()
  }).then(() => {}).catch(() => {});
}

function getSessionId() {
  let sid = sessionStorage.getItem('session_id');
  if (!sid) {
    sid = 'sess_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    sessionStorage.setItem('session_id', sid);
  }
  return sid;
}

// ============================================================
// LOCAL FALLBACK DATA
// ============================================================
function getLocalArticles() {
  const stored = localStorage.getItem('cpc8_articles');
  if (stored) return JSON.parse(stored);
  return [
    { id: '1', title: '8th Pay Commission: Expected Fitment Factor and Salary Structure', slug: '8th-pay-commission-fitment-factor', excerpt: 'The 8th CPC is expected to revise the fitment factor from 2.57x to 3.68x. Here\'s what government employees can expect.', category: '8th CPC', is_featured: true, is_trending: true, views: 12450, published_at: new Date(Date.now() - 86400000*2).toISOString(), author_name: 'Editorial Team', tags: ['8th CPC', 'fitment', 'salary'] },
    { id: '2', title: 'DA Hike July 2026: Cabinet Approval Expected at 65%', slug: 'da-hike-july-2026', excerpt: 'Based on AICPI data, the DA hike for July 2026 is projected at 65%. Calculate your revised salary and arrears.', category: 'DA Update', is_featured: true, is_trending: true, views: 9820, published_at: new Date(Date.now() - 86400000).toISOString(), author_name: 'Editorial Team', tags: ['DA', '2026', 'arrears'] },
    { id: '3', title: 'NPS vs OPS: Complete Analysis for Government Employees 2026', slug: 'nps-vs-ops-2026', excerpt: 'A comprehensive comparison of NPS and OPS to help you plan your retirement better.', category: 'NPS', is_featured: false, is_trending: false, views: 6540, published_at: new Date(Date.now() - 86400000*5).toISOString(), author_name: 'Finance Desk', tags: ['NPS', 'OPS', 'pension', 'retirement'] },
    { id: '4', title: 'HRA Revision Under 8th CPC: X, Y, Z Cities Impact Analysis', slug: 'hra-revision-8th-cpc', excerpt: 'How HRA rates will change under 8th CPC for employees in X, Y, and Z category cities.', category: '8th CPC', is_featured: false, is_trending: true, views: 4210, published_at: new Date(Date.now() - 86400000*7).toISOString(), author_name: 'Editorial Team', tags: ['HRA', '8th CPC'] },
    { id: '5', title: 'Gratuity Ceiling Enhanced to ₹30 Lakh: Order Released', slug: 'gratuity-ceiling-30-lakh', excerpt: 'The government has enhanced the gratuity ceiling from ₹25 lakh to ₹30 lakh effective from January 2025.', category: 'Benefits', is_featured: false, is_trending: false, views: 3870, published_at: new Date(Date.now() - 86400000*10).toISOString(), author_name: 'Editorial Team', tags: ['gratuity', 'retirement'] },
    { id: '6', title: 'Defence Pay: Special Allowances and Military Service Pay Under 8th CPC', slug: 'defence-pay-8th-cpc', excerpt: 'Analysis of how Military Service Pay and special allowances will be revised under 8th CPC.', category: 'Defence', is_featured: false, is_trending: false, views: 5630, published_at: new Date(Date.now() - 86400000*4).toISOString(), author_name: 'Defence Desk', tags: ['defence', 'military', '8th CPC'] }
  ];
}

function getLocalOrders() {
  const stored = localStorage.getItem('cpc8_orders');
  if (stored) return JSON.parse(stored);
  return [
    { id: '1', title: 'Revision of DA to 62% of Basic Pay w.e.f. 01.01.2026', order_number: 'MF/PC-VII/2026/DA/01', department: 'Finance Ministry', category: 'DA', year: 2026, downloads: 4521, created_at: new Date().toISOString() },
    { id: '2', title: 'Grant of House Rent Allowance - Revised Rates 7th CPC', order_number: 'MF/PC-VII/2022/HRA/05', department: 'Finance Ministry', category: 'HRA', year: 2022, downloads: 2890, created_at: new Date(Date.now()-86400000*30).toISOString() },
    { id: '3', title: 'Revision of Gratuity Ceiling to Rs. 25,00,000', order_number: 'DOPT/2022/Pension/12', department: 'DoPT', category: 'Pension', year: 2022, downloads: 1850, created_at: new Date(Date.now()-86400000*60).toISOString() },
    { id: '4', title: 'National Pension System - Enhanced Government Contribution to 14%', order_number: 'PFRDA/2022/NPS/07', department: 'PFRDA', category: 'NPS', year: 2022, downloads: 3240, created_at: new Date(Date.now()-86400000*90).toISOString() },
    { id: '5', title: 'Implementation of 7th CPC Recommendations - Pay Matrix', order_number: 'MF/PC-VII/2016/Pay/01', department: 'Finance Ministry', category: 'Pay', year: 2016, downloads: 8760, created_at: new Date(Date.now()-86400000*365*2).toISOString() },
    { id: '6', title: 'Leave Travel Concession Rules Relaxation - Block 2022-25', order_number: 'DOPT/2023/LTC/03', department: 'DoPT', category: 'Leave', year: 2023, downloads: 2100, created_at: new Date(Date.now()-86400000*120).toISOString() }
  ];
}

// ============================================================
// ADMIN: FETCH ANALYTICS
// ============================================================
async function fetchAdminAnalytics() {
  if (!supabase) return null;
  const [users, articles, orders, events] = await Promise.all([
    supabase.from('profiles').select('id', { count: 'exact', head: true }),
    supabase.from('articles').select('id', { count: 'exact', head: true }),
    supabase.from('govt_orders').select('id', { count: 'exact', head: true }),
    supabase.from('analytics_events').select('event_type').order('created_at', { ascending: false }).limit(1000)
  ]);
  return {
    totalUsers: users.count || 0,
    totalArticles: articles.count || 0,
    totalOrders: orders.count || 0,
    recentEvents: events.data || []
  };
}
