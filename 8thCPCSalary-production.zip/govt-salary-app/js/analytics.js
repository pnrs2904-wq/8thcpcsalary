/**
 * analytics.js — Google Analytics 4 custom event tracking
 * Tracks all meaningful user interactions
 */

const GA_ID = 'G-G9V3KYRB5F';

// ── Custom Events ──────────────────────────────────────────
const EVENTS = {
  SALARY_CALCULATED:    'salary_calculated',
  PROMOTION_CALC:       'promotion_calculated',
  PDF_DOWNLOAD:         'pdf_download',
  SHARE_RESULT:         'share_result',
  PROFILE_SAVED:        'profile_saved',
  ARTICLE_VIEW:         'article_view',
  ORDER_DOWNLOAD:       'order_download',
  AI_QUERY:             'ai_query',
  DA_CALCULATED:        'da_calculated',
  NPS_CALCULATED:       'nps_calculated',
  PENSION_CALCULATED:   'pension_calculated',
  GRATUITY_CALCULATED:  'gratuity_calculated',
  COMPARISON_CALC:      'comparison_calculated',
  NEWSLETTER_SUB:       'newsletter_subscribed',
  SEARCH_PERFORMED:     'search_performed',
  SALARY_SLIP:          'salary_slip_generated',
  USER_SIGNUP:          'user_signup',
  USER_LOGIN:           'user_login',
  LEVEL_SELECTED:       'pay_level_selected',
  DARK_MODE_TOGGLE:     'dark_mode_toggle',
};

// ── Page View ──────────────────────────────────────────────
function trackPageView(pagePath, pageTitle) {
  if (typeof gtag === 'undefined') return;
  gtag('event', 'page_view', {
    page_path: pagePath || window.location.pathname,
    page_title: pageTitle || document.title,
    page_location: window.location.href
  });
}

// ── Scroll Depth ───────────────────────────────────────────
let scrollMilestones = new Set();
window.addEventListener('scroll', () => {
  const scrollPct = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
  [25, 50, 75, 90].forEach(milestone => {
    if (scrollPct >= milestone && !scrollMilestones.has(milestone)) {
      scrollMilestones.add(milestone);
      if (typeof gtag !== 'undefined') {
        gtag('event', 'scroll_depth', { percent_scrolled: milestone });
      }
    }
  });
}, { passive: true });

// ── Time on Page ───────────────────────────────────────────
const pageLoadTime = Date.now();
window.addEventListener('beforeunload', () => {
  const timeSpent = Math.round((Date.now() - pageLoadTime) / 1000);
  if (typeof gtag !== 'undefined' && timeSpent > 5) {
    gtag('event', 'time_on_page', { seconds: timeSpent });
  }
});

// ── Calculator Engagement ──────────────────────────────────
let calcInteractions = 0;
document.addEventListener('change', (e) => {
  if (e.target.closest('#mainCalc, #daCalc, #npsCalc, #pensionCalc')) {
    calcInteractions++;
    if (calcInteractions === 3) {
      if (typeof gtag !== 'undefined') {
        gtag('event', 'calculator_engaged', { interactions: 3 });
      }
    }
  }
}, { passive: true });

// ── Web Vitals ─────────────────────────────────────────────
function reportWebVitals() {
  if (typeof gtag === 'undefined') return;

  // Core Web Vitals via PerformanceObserver
  if ('PerformanceObserver' in window) {
    // LCP
    try {
      new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const last = entries[entries.length - 1];
        gtag('event', 'web_vitals', { metric_name: 'LCP', metric_value: Math.round(last.startTime), metric_rating: last.startTime < 2500 ? 'good' : last.startTime < 4000 ? 'needs-improvement' : 'poor' });
      }).observe({ type: 'largest-contentful-paint', buffered: true });
    } catch (e) {}

    // CLS
    try {
      let clsValue = 0;
      new PerformanceObserver((list) => {
        list.getEntries().forEach(entry => { if (!entry.hadRecentInput) clsValue += entry.value; });
      }).observe({ type: 'layout-shift', buffered: true });
      window.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') {
          gtag('event', 'web_vitals', { metric_name: 'CLS', metric_value: Math.round(clsValue * 1000), metric_rating: clsValue < 0.1 ? 'good' : clsValue < 0.25 ? 'needs-improvement' : 'poor' });
        }
      });
    } catch (e) {}

    // FID/INP
    try {
      new PerformanceObserver((list) => {
        list.getEntries().forEach(entry => {
          gtag('event', 'web_vitals', { metric_name: 'FID', metric_value: Math.round(entry.processingStart - entry.startTime), metric_rating: entry.processingStart - entry.startTime < 100 ? 'good' : 'needs-improvement' });
        });
      }).observe({ type: 'first-input', buffered: true });
    } catch (e) {}
  }

  // Navigation timing
  window.addEventListener('load', () => {
    setTimeout(() => {
      const nav = performance.getEntriesByType('navigation')[0];
      if (nav) {
        gtag('event', 'page_load_time', {
          dns: Math.round(nav.domainLookupEnd - nav.domainLookupStart),
          ttfb: Math.round(nav.responseStart - nav.requestStart),
          dom_load: Math.round(nav.domContentLoadedEventEnd - nav.navigationStart),
          full_load: Math.round(nav.loadEventEnd - nav.navigationStart)
        });
      }
    }, 0);
  });
}

// ── User Properties ────────────────────────────────────────
function setUserProperties(props) {
  if (typeof gtag === 'undefined') return;
  gtag('set', 'user_properties', props);
}

// ── Enhanced Ecommerce (for AdSense optimization) ─────────
function trackAdImpression(adUnit) {
  if (typeof gtag === 'undefined') return;
  gtag('event', 'ad_impression', { ad_unit: adUnit });
}

// ── Initialize ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  reportWebVitals();

  // Set user properties
  setUserProperties({
    platform: 'web',
    device_type: window.innerWidth < 768 ? 'mobile' : 'desktop',
    dark_mode: localStorage.getItem('darkMode') === '1',
    has_saved_profiles: (JSON.parse(localStorage.getItem('cpc8_profiles') || '[]').length > 0),
  });
});
