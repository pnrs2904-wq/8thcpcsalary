/**
 * app.js — Core calculator engine
 * 8th CPC Salary, DA, HRA, Pension, NPS, Gratuity, Leave, Promotion calculations
 */

// ============================================================
// PAY MATRIX DATA (7th CPC)
// ============================================================
const PAY_MATRIX_7TH = {
  1:  [18000,18500,19100,19700,20300,20900,21500,22100,22800,23500,24200,24900,25600,26400,27200,28000,28800,29700],
  2:  [19900,20500,21100,21700,22400,23100,23800,24500,25200,26000,26800,27600,28400,29300,30200,31100,32000,33000],
  3:  [21700,22400,23100,23800,24500,25200,26000,26800,27600,28400,29300,30200,31100,32000,33000,34000,35000,36100],
  4:  [25500,26300,27100,27900,28700,29600,30500,31400,32400,33400,34400,35400,36500,37600,38700,39900,41100,42300],
  5:  [29200,30100,31000,31900,32900,33900,34900,36000,37100,38200,39300,40500,41700,43000,44300,45600,47000,48400],
  6:  [35400,36500,37600,38700,39900,41100,42300,43600,44900,46200,47600,49000,50500,52000,53600,55200,56900,58600],
  7:  [44900,46200,47600,49000,50500,52000,53600,55200,56900,58600,60400,62200,64100,66000,68000,70000,72100,74300],
  8:  [47600,49000,50500,52000,53600,55200,56900,58600,60400,62200,64100,66000,68000,70000,72100,74300,76500,78800],
  9:  [53100,54700,56300,58000,59700,61500,63300,65200,67200,69200,71300,73400,75600,77900,80300,82700,85200,87800],
  10: [56100,57800,59500,61300,63100,65000,67000,69000,71100,73200,75400,77700,80000,82400,84900,87400,90000,92700],
  11: [67700,69700,71800,74000,76200,78500,80900,83300,85800,88400,91100,93800,96600,99500,102500,105600,108800,112100],
  12: [78800,81200,83600,86100,88700,91400,94100,96900,99800,102800,105900,109100,112400,115800,119300,122900,126600,130400],
  13: [123100,126800,130600,134500,138500,142700,147000,151400,155900,160600,165400,170400,175500,180800,186200,191800,197600,203500],
  14: [144200,148500,153000,157600,162300,167200,172200,177400,182700,188200,193900,199700,205700,211900,218300,224800,231500,238400],
  15: [182200,187700,193300,199100,205100,211300,217600,224100,230800,237700,244800,252100,259700,267500,275600,283900,292400,301200],
  16: [205400,211600,217900,224400,231100,238000,245200,252600,260200,268000,276000,284300,292800,301600,310600,320000,329500,339500],
  17: [225000,231800,238700,245900,253300,261000,268800,277000,285300,294000,302900,312000,321400,331000,341000,351200,361700,372600],
  18: [250000,257500,265200,273200,281400,289800,298500,307500,316700,326200,336000,346100,356400,367100,378100,389400,401100,413100]
};

// 8th CPC projected minimum pays (with 2.57x fitment)
const EIGHTH_CPC_MINIMUM = {
  1: 18000 * 2.57, 2: 19900 * 2.57, 3: 21700 * 2.57, 4: 25500 * 2.57,
  5: 29200 * 2.57, 6: 35400 * 2.57, 7: 44900 * 2.57, 8: 47600 * 2.57,
  9: 53100 * 2.57, 10: 56100 * 2.57, 11: 67700 * 2.57, 12: 78800 * 2.57,
  13: 123100 * 2.57, 14: 144200 * 2.57, 15: 182200 * 2.57,
  16: 205400 * 2.57, 17: 225000 * 2.57, 18: 250000 * 2.57
};

const DA_HISTORY_LOCAL = [
  { date: '2016-01-01', da: 0 }, { date: '2016-07-01', da: 2 },
  { date: '2017-01-01', da: 4 }, { date: '2017-07-01', da: 5 },
  { date: '2018-01-01', da: 7 }, { date: '2018-07-01', da: 9 },
  { date: '2019-01-01', da: 12 }, { date: '2019-07-01', da: 17 },
  { date: '2020-01-01', da: 21 }, { date: '2021-07-01', da: 28 },
  { date: '2022-01-01', da: 34 }, { date: '2022-07-01', da: 38 },
  { date: '2023-01-01', da: 42 }, { date: '2023-07-01', da: 46 },
  { date: '2024-01-01', da: 50 }, { date: '2024-07-01', da: 53 },
  { date: '2025-01-01', da: 55 }, { date: '2025-07-01', da: 59 },
  { date: '2026-01-01', da: 62 }, { date: '2026-07-01', da: 65 }
];

const HRA_RATES = { X: 0.27, Y: 0.18, Z: 0.09 };
const HRA_MINIMUM = { X: 5400, Y: 3600, Z: 1800 };
const HRA_RATES_8TH = { X: 0.30, Y: 0.20, Z: 0.10 };

// ============================================================
// MAIN SALARY CALCULATOR
// ============================================================
function calculateSalary() {
  const basicPay = parseFloat(document.getElementById('basicPay')?.value) || 44900;
  const daPercent = parseFloat(document.getElementById('daPercent')?.value) || 62;
  const hraCity = document.getElementById('hraCity')?.value || 'Y';
  const fitmentFactor = parseFloat(document.getElementById('fitmentSlider')?.value) || 2.57;
  const tptaPercent = parseFloat(document.getElementById('tptaPercent')?.value) || 3600;

  // Current 7th CPC calculations
  const currentDA = Math.round(basicPay * daPercent / 100);
  const currentHRA = Math.max(Math.round(basicPay * HRA_RATES[hraCity]), HRA_MINIMUM[hraCity]);
  const currentTA = basicPay >= 24200 ? 3600 : 1350;
  const currentDAonTA = Math.round(currentTA * daPercent / 100);
  const currentGross = basicPay + currentDA + currentHRA + currentTA + currentDAonTA;
  const currentNPS = Math.round(basicPay * 0.10);
  const currentNetInHand = currentGross - currentNPS;

  // 8th CPC projected calculations
  const newBasicPay = Math.round(basicPay * fitmentFactor);
  const newDA = 0; // DA resets to 0 on CPC revision
  const newHRA = Math.max(Math.round(newBasicPay * HRA_RATES_8TH[hraCity]), Math.round(HRA_MINIMUM[hraCity] * fitmentFactor));
  const newTA = newBasicPay >= 24200 * fitmentFactor ? Math.round(3600 * fitmentFactor) : Math.round(1350 * fitmentFactor);
  const newGross = newBasicPay + newDA + newHRA + newTA;
  const newNPS = Math.round(newBasicPay * 0.10);
  const newNetInHand = newGross - newNPS;

  const increase = newNetInHand - currentNetInHand;
  const increasePercent = currentNetInHand > 0 ? ((increase / currentNetInHand) * 100).toFixed(1) : 0;

  // Update UI
  const resultAmount = document.getElementById('resultAmount');
  const oldAmount = document.getElementById('oldAmount');
  const increaseBadge = document.getElementById('increaseBadge');
  const heroMonthlyStat = document.getElementById('heroMonthlyStat');

  if (resultAmount) {
    resultAmount.textContent = formatCurrency(newNetInHand);
    resultAmount.style.animation = 'none';
    setTimeout(() => { if (resultAmount) resultAmount.style.animation = 'countUp 0.5s ease'; }, 10);
  }
  if (oldAmount) oldAmount.textContent = formatCurrency(currentNetInHand);
  if (increaseBadge) {
    increaseBadge.style.display = 'flex';
    increaseBadge.textContent = `▲ +${formatCurrency(increase)}/month (+${increasePercent}%)`;
    increaseBadge.className = increase >= 0 ? 'increase-badge' : 'increase-badge decrease-badge';
  }
  if (heroMonthlyStat) heroMonthlyStat.textContent = formatCurrency(newNetInHand);

  // Store last result for PDF/share
  window.lastCalcResult = {
    basicPay, daPercent, hraCity, fitmentFactor,
    currentDA, currentHRA, currentTA, currentGross, currentNetInHand,
    newBasicPay, newDA, newHRA, newTA, newGross, newNetInHand,
    increase, increasePercent
  };

  trackEvent('salary_calculated', { basic_pay: basicPay, fitment: fitmentFactor, city: hraCity });
  return window.lastCalcResult;
}

// ============================================================
// DA CALCULATOR
// ============================================================
function calculateDA() {
  const basicPay = parseFloat(document.getElementById('daBasicPay')?.value) || 44900;
  const daPercent = parseFloat(document.getElementById('daPercentInput')?.value) || 62;
  const daAmount = Math.round(basicPay * daPercent / 100);

  const el = document.getElementById('daResult');
  if (el) {
    el.innerHTML = `
      <div class="rh-label">Dearness Allowance</div>
      <div class="rh-amount">${formatCurrency(daAmount)}/month</div>
      <div class="rh-sub">DA Rate: ${daPercent}% of Basic Pay ${formatCurrency(basicPay)}</div>
      <div class="rh-sub" style="margin-top:8px;">Annual DA: <strong>${formatCurrency(daAmount * 12)}</strong></div>
    `;
  }
  trackEvent('da_calculated', { basic_pay: basicPay, da_percent: daPercent });
  return daAmount;
}

// ============================================================
// DA ARREARS CALCULATOR
// ============================================================
function calculateDAarrears() {
  const basicPay = parseFloat(document.getElementById('arrBasicPay')?.value) || 44900;
  const oldDA = parseFloat(document.getElementById('arrOldDA')?.value) || 59;
  const newDA = parseFloat(document.getElementById('arrNewDA')?.value) || 62;
  const months = parseInt(document.getElementById('arrMonths')?.value) || 3;

  const oldDAAmount = Math.round(basicPay * oldDA / 100);
  const newDAAmount = Math.round(basicPay * newDA / 100);
  const differencePerMonth = newDAAmount - oldDAAmount;
  const totalArrears = differencePerMonth * months;

  const el = document.getElementById('arrearsResult');
  if (el) {
    el.innerHTML = `
      <div class="rh-label">Total DA Arrears</div>
      <div class="rh-amount">${formatCurrency(totalArrears)}</div>
      <div class="rh-sub">Increase: ${formatCurrency(differencePerMonth)}/month × ${months} months</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:16px;text-align:left;">
        <div class="ret-stat-card" style="background:var(--surface-2);border:1px solid var(--border);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--text-muted)">Old DA/month</div>
          <div style="font-weight:800;font-family:var(--font-mono)">${formatCurrency(oldDAAmount)}</div>
        </div>
        <div class="ret-stat-card" style="background:var(--surface-2);border:1px solid var(--border);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--text-muted)">New DA/month</div>
          <div style="font-weight:800;font-family:var(--font-mono)">${formatCurrency(newDAAmount)}</div>
        </div>
      </div>
    `;
  }
  trackEvent('arrears_calculated', { basic_pay: basicPay, old_da: oldDA, new_da: newDA, months });
  return totalArrears;
}

// ============================================================
// HRA CALCULATOR
// ============================================================
function calculateHRA() {
  const basicPay = parseFloat(document.getElementById('hraBasicPay')?.value) || 44900;
  const city = document.getElementById('hraCitySelect')?.value || 'Y';
  const daPercent = parseFloat(document.getElementById('hraDa')?.value) || 62;
  const useOld = document.getElementById('hraOld7th')?.checked !== false;

  const rates = useOld ? HRA_RATES : HRA_RATES_8TH;
  const hraCurrent = Math.max(Math.round(basicPay * rates[city]), HRA_MINIMUM[city]);
  const daAmount = Math.round(basicPay * daPercent / 100);

  const el = document.getElementById('hraResult');
  if (el) {
    el.innerHTML = `
      <div class="rh-label">House Rent Allowance</div>
      <div class="rh-amount">${formatCurrency(hraCurrent)}/month</div>
      <div class="rh-sub">Rate: ${(rates[city]*100).toFixed(0)}% | City: ${city} Category</div>
      <div class="rh-sub">Annual HRA: <strong>${formatCurrency(hraCurrent * 12)}</strong></div>
    `;
  }
  trackEvent('hra_calculated', { basic_pay: basicPay, city });
  return hraCurrent;
}

// ============================================================
// PENSION CALCULATOR
// ============================================================
function calculatePension() {
  const lastPay = parseFloat(document.getElementById('pensLastPay')?.value) || 78800;
  const yearsService = parseInt(document.getElementById('pensYears')?.value) || 30;
  const daPercent = parseFloat(document.getElementById('pensDa')?.value) || 62;
  const pensionType = document.getElementById('pensType')?.value || 'normal';

  // 50% of last basic pay as pension
  let pensionBase = Math.round(lastPay * 0.50);
  if (pensionType === 'pro_rata' && yearsService < 33) {
    pensionBase = Math.round(lastPay * yearsService / (33 * 2));
  }
  // Minimum pension
  pensionBase = Math.max(pensionBase, 9000);
  const dr = Math.round(pensionBase * daPercent / 100);
  const totalPension = pensionBase + dr;
  const familyPension = Math.round(pensionBase * 0.60);
  const commutation30 = Math.round(pensionBase * 0.40 * 8.194 * 12);
  const reducedPension = Math.round(pensionBase * 0.60);

  const el = document.getElementById('pensionResult');
  if (el) {
    el.innerHTML = `
      <div class="rh-label">Monthly Pension (incl. DR)</div>
      <div class="rh-amount">${formatCurrency(totalPension)}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px;text-align:left;">
        <div style="background:var(--surface-2);border:1px solid var(--border);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--text-muted)">Basic Pension</div>
          <div style="font-weight:800;font-family:var(--font-mono)">${formatCurrency(pensionBase)}</div>
        </div>
        <div style="background:var(--surface-2);border:1px solid var(--border);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--text-muted)">DR @ ${daPercent}%</div>
          <div style="font-weight:800;font-family:var(--font-mono)">${formatCurrency(dr)}</div>
        </div>
        <div style="background:var(--surface-2);border:1px solid var(--border);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--text-muted)">Family Pension</div>
          <div style="font-weight:800;font-family:var(--font-mono)">${formatCurrency(familyPension)}</div>
        </div>
        <div style="background:var(--india-green-light);border:1px solid var(--india-green);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--india-green)">Commutation (40%)</div>
          <div style="font-weight:800;font-family:var(--font-mono);color:var(--india-green)">${formatCurrency(commutation30)}</div>
        </div>
      </div>
    `;
  }
  window.lastPensionResult = { pensionBase, dr, totalPension, familyPension, commutation30, yearsService, lastPay };
  trackEvent('pension_calculated', { last_pay: lastPay, years: yearsService });
  return { pensionBase, dr, totalPension, familyPension, commutation30 };
}

// ============================================================
// NPS CALCULATOR
// ============================================================
function calculateNPS() {
  const basicPay = parseFloat(document.getElementById('npsBasicPay')?.value) || 44900;
  const daPercent = parseFloat(document.getElementById('npsDa')?.value) || 62;
  const yearsLeft = parseInt(document.getElementById('npsYearsLeft')?.value) || 20;
  const annualReturnRate = parseFloat(document.getElementById('npsReturn')?.value || 10) / 100;
  const annuityRate = parseFloat(document.getElementById('npsAnnuity')?.value || 6) / 100;

  const daAmount = Math.round(basicPay * daPercent / 100);
  const basicPlusDA = basicPay + daAmount;
  const employeeContrib = Math.round(basicPlusDA * 0.10);
  const govtContrib = Math.round(basicPlusDA * 0.14);
  const totalMonthlyContrib = employeeContrib + govtContrib;
  const monthlyRate = annualReturnRate / 12;
  const totalMonths = yearsLeft * 12;

  // Future value of monthly contributions
  const corpus = totalMonthlyContrib * (Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate;
  const lumpsum = corpus * 0.60;
  const annuityCorpus = corpus * 0.40;
  const monthlyPension = Math.round(annuityCorpus * annuityRate / 12);

  const el = document.getElementById('npsResult');
  if (el) {
    el.innerHTML = `
      <div class="rh-label">Projected NPS Corpus at Retirement</div>
      <div class="rh-amount">${formatCrore(corpus)}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px;text-align:left;">
        <div style="background:var(--surface-2);border:1px solid var(--border);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--text-muted)">Monthly Contribution</div>
          <div style="font-weight:800;font-family:var(--font-mono)">${formatCurrency(totalMonthlyContrib)}</div>
          <div style="font-size:0.6rem;color:var(--text-muted)">Emp: ${formatCurrency(employeeContrib)} + Govt: ${formatCurrency(govtContrib)}</div>
        </div>
        <div style="background:var(--india-blue-light);border:1px solid var(--india-blue);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--india-blue)">Lump Sum (60%)</div>
          <div style="font-weight:800;font-family:var(--font-mono);color:var(--india-blue)">${formatCrore(lumpsum)}</div>
        </div>
        <div style="background:var(--surface-2);border:1px solid var(--border);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--text-muted)">Annuity Corpus (40%)</div>
          <div style="font-weight:800;font-family:var(--font-mono)">${formatCrore(annuityCorpus)}</div>
        </div>
        <div style="background:var(--india-green-light);border:1px solid var(--india-green);padding:12px;border-radius:8px;">
          <div style="font-size:0.65rem;color:var(--india-green)">Est. Monthly Pension</div>
          <div style="font-weight:800;font-family:var(--font-mono);color:var(--india-green)">${formatCurrency(monthlyPension)}</div>
        </div>
      </div>
    `;
  }
  window.lastNPSResult = { corpus, lumpsum, annuityCorpus, monthlyPension, yearsLeft, totalMonthlyContrib };
  trackEvent('nps_calculated', { basic_pay: basicPay, years_left: yearsLeft });
  return { corpus, lumpsum, monthlyPension };
}

// ============================================================
// GRATUITY CALCULATOR
// ============================================================
function calculateGratuity() {
  const basicPay = parseFloat(document.getElementById('gratBasicPay')?.value) || 44900;
  const daPercent = parseFloat(document.getElementById('gratDa')?.value) || 62;
  const yearsService = parseInt(document.getElementById('gratYears')?.value) || 30;

  const daAmount = Math.round(basicPay * daPercent / 100);
  const basicPlusDA = basicPay + daAmount;
  // Gratuity = Basic+DA × 1/4 × completed 6-month periods (max 16.5)
  const halfYears = Math.min(yearsService * 2, 33);
  const gratuity = Math.round(basicPlusDA * halfYears / 4);
  const cappedGratuity = Math.min(gratuity, 2500000); // ₹25 lakh cap (₹30L pending revision)
  const taxFreeLimit = 2000000;
  const taxableAmount = Math.max(0, cappedGratuity - taxFreeLimit);

  const el = document.getElementById('gratuityResult');
  if (el) {
    el.innerHTML = `
      <div class="rh-label">Gratuity Amount</div>
      <div class="rh-amount">${formatCurrency(cappedGratuity)}</div>
      <div class="rh-sub">Based on ${yearsService} years service</div>
      <div style="margin-top:12px;padding:12px;background:var(--surface-2);border-radius:8px;font-size:0.75rem;">
        <div class="flex-between" style="margin-bottom:6px;"><span>Calculated Gratuity</span><strong>${formatCurrency(gratuity)}</strong></div>
        <div class="flex-between" style="margin-bottom:6px;"><span>Ceiling Cap (₹25L)</span><strong>${formatCurrency(cappedGratuity)}</strong></div>
        <div class="flex-between" style="margin-bottom:6px;"><span>Tax-Free Limit</span><strong>${formatCurrency(taxFreeLimit)}</strong></div>
        <div class="flex-between"><span>Taxable Portion</span><strong style="color:${taxableAmount > 0 ? 'var(--red)' : 'var(--green)'}">${formatCurrency(taxableAmount)}</strong></div>
      </div>
    `;
  }
  trackEvent('gratuity_calculated', { basic_pay: basicPay, years: yearsService });
  return cappedGratuity;
}

// ============================================================
// LEAVE ENCASHMENT CALCULATOR
// ============================================================
function calculateLeaveEncashment() {
  const basicPay = parseFloat(document.getElementById('leaveBasicPay')?.value) || 44900;
  const daPercent = parseFloat(document.getElementById('leaveDa')?.value) || 62;
  const earnedLeave = parseInt(document.getElementById('leaveEL')?.value) || 300;

  const daAmount = Math.round(basicPay * daPercent / 100);
  const totalPay = basicPay + daAmount;
  const cappedLeave = Math.min(earnedLeave, 300);
  const dailyPay = Math.round(totalPay / 30);
  const leaveEncashment = dailyPay * cappedLeave;
  const cappedEncashment = Math.min(leaveEncashment, 2500000); // ₹25L cap
  const taxFree = 2000000;
  const taxable = Math.max(0, cappedEncashment - taxFree);

  const el = document.getElementById('leaveResult');
  if (el) {
    el.innerHTML = `
      <div class="rh-label">Leave Encashment</div>
      <div class="rh-amount">${formatCurrency(cappedEncashment)}</div>
      <div class="rh-sub">${cappedLeave} days × ${formatCurrency(dailyPay)}/day</div>
      <div style="margin-top:12px;font-size:0.75rem;color:var(--text-muted)">
        Tax-free limit: ${formatCurrency(taxFree)} | Taxable: <span style="color:${taxable>0?'var(--red)':'var(--green)'}">${formatCurrency(taxable)}</span>
      </div>
    `;
  }
  trackEvent('leave_calculated', { basic_pay: basicPay, leave_days: earnedLeave });
  return cappedEncashment;
}

// ============================================================
// PROMOTION CALCULATOR
// ============================================================
function calculatePromotion() {
  const currentBasic = parseFloat(document.getElementById('promCurrentBasic')?.value) || 44900;
  const currentLevel = parseInt(document.getElementById('promCurrentLevel')?.value) || 7;
  const nextLevel = currentLevel + 1;
  const daPercent = parseFloat(document.getElementById('promDa')?.value) || 62;

  // Get next level minimum pay
  const nextLevelMatrix = PAY_MATRIX_7TH[nextLevel] || PAY_MATRIX_7TH[currentLevel];
  // Add 3% fixation benefit
  const withIncrement = Math.round(currentBasic * 1.03);
  // Find appropriate cell in next level
  let promotedBasic = nextLevelMatrix[0];
  for (let i = 0; i < nextLevelMatrix.length; i++) {
    if (nextLevelMatrix[i] >= withIncrement) { promotedBasic = nextLevelMatrix[i]; break; }
    if (i === nextLevelMatrix.length - 1) promotedBasic = nextLevelMatrix[i];
  }

  const hraCity = document.getElementById('promHRA')?.value || 'Y';
  const currentDA = Math.round(currentBasic * daPercent / 100);
  const currentHRA = Math.max(Math.round(currentBasic * HRA_RATES[hraCity]), HRA_MINIMUM[hraCity]);
  const currentGross = currentBasic + currentDA + currentHRA;

  const newDA = Math.round(promotedBasic * daPercent / 100);
  const newHRA = Math.max(Math.round(promotedBasic * HRA_RATES[hraCity]), HRA_MINIMUM[hraCity]);
  const newGross = promotedBasic + newDA + newHRA;
  const monthlyBenefit = newGross - currentGross;

  const el = document.getElementById('promotionResult');
  if (el) {
    el.innerHTML = `
      <div class="rh-label">Pay After Promotion to Level ${nextLevel}</div>
      <div class="rh-amount">${formatCurrency(promotedBasic)}</div>
      <div class="rh-sub">Monthly benefit: <strong>+${formatCurrency(monthlyBenefit)}</strong></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px;text-align:left;font-size:0.75rem;">
        <div style="background:var(--surface-2);padding:12px;border-radius:8px;">
          <div style="color:var(--text-muted);margin-bottom:4px;">Current Gross (Level ${currentLevel})</div>
          <div style="font-weight:800;font-family:var(--font-mono)">${formatCurrency(currentGross)}</div>
        </div>
        <div style="background:var(--india-green-light);padding:12px;border-radius:8px;border:1px solid var(--india-green);">
          <div style="color:var(--india-green);margin-bottom:4px;">New Gross (Level ${nextLevel})</div>
          <div style="font-weight:800;font-family:var(--font-mono);color:var(--india-green)">${formatCurrency(newGross)}</div>
        </div>
      </div>
    `;
  }
  trackEvent('promotion_calculated', { current_basic: currentBasic, current_level: currentLevel });
  return { promotedBasic, monthlyBenefit, nextLevel };
}

// ============================================================
// RETIREMENT DASHBOARD
// ============================================================
function updateRetirementDashboard() {
  const basicPay = parseFloat(document.getElementById('basicPay')?.value) || 44900;
  const daPercent = parseFloat(document.getElementById('daPercent')?.value) || 62;
  const dob = document.getElementById('retDOB')?.value;
  const doj = document.getElementById('retDOJ')?.value;

  const today = new Date();
  let retirementDate = new Date(today.getFullYear() + 15, today.getMonth(), 1);
  let yearsLeft = 15;
  let yearsService = 20;

  if (dob) {
    const birthDate = new Date(dob);
    retirementDate = new Date(birthDate.getFullYear() + 60, birthDate.getMonth(), 1);
    yearsLeft = Math.max(0, Math.round((retirementDate - today) / (1000 * 60 * 60 * 24 * 365.25)));
  }
  if (doj) {
    const joinDate = new Date(doj);
    yearsService = Math.round((today - joinDate) / (1000 * 60 * 60 * 24 * 365.25));
    const totalService = 33;
    yearsLeft = Math.max(0, totalService - yearsService);
  }

  const daAmount = Math.round(basicPay * daPercent / 100);
  const basicPlusDA = basicPay + daAmount;

  // Gratuity estimate
  const halfYears = Math.min((yearsService + yearsLeft) * 2, 33);
  const projectedBasic = Math.round(basicPay * 1.03 ** yearsLeft);
  const projectedDA = Math.round(projectedBasic * 0.50);
  const projectedGratuity = Math.min(Math.round((projectedBasic + projectedDA) * halfYears / 4), 2500000);

  // Pension estimate
  const projectedPension = Math.round(projectedBasic * 0.50);

  // NPS corpus estimate
  const monthlyContrib = Math.round(basicPlusDA * 0.24);
  const monthlyRate = 0.10 / 12;
  const npsCorpus = monthlyContrib * (Math.pow(1 + monthlyRate, yearsLeft * 12) - 1) / monthlyRate;

  // Update retirement stats
  const statsMap = {
    'retYearsLeft': yearsLeft + ' yrs',
    'retGratuity': formatCurrency(projectedGratuity),
    'retPension': formatCurrency(projectedPension) + '/mo',
    'retNPS': formatCrore(npsCorpus)
  };
  Object.entries(statsMap).forEach(([id, val]) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  });
}

// ============================================================
// SALARY SLIP GENERATOR
// ============================================================
function generateSalarySlip() {
  const name = document.getElementById('slipName')?.value || 'GOVERNMENT EMPLOYEE';
  const empId = document.getElementById('slipEmpId')?.value || 'EMP001';
  const designation = document.getElementById('slipDesignation')?.value || 'Assistant';
  const payLevel = document.getElementById('slipLevel')?.value || '7';
  const basicPay = parseFloat(document.getElementById('slipBasic')?.value) || 44900;
  const daPercent = parseFloat(document.getElementById('slipDA')?.value) || 62;
  const hraCity = document.getElementById('slipHRA')?.value || 'Y';
  const month = document.getElementById('slipMonth')?.value || new Date().toLocaleString('default', { month: 'long', year: 'numeric' });

  const da = Math.round(basicPay * daPercent / 100);
  const hra = Math.max(Math.round(basicPay * HRA_RATES[hraCity]), HRA_MINIMUM[hraCity]);
  const ta = basicPay >= 24200 ? 3600 : 1350;
  const daOnTA = Math.round(ta * daPercent / 100);
  const nps = Math.round(basicPay * 0.10);
  const cghs = 500;
  const grossEarnings = basicPay + da + hra + ta + daOnTA;
  const totalDeductions = nps + cghs;
  const netPay = grossEarnings - totalDeductions;

  const slipHTML = `
    <div class="salary-slip" id="generatedSlip">
      <div class="salary-slip-header">
        <div style="font-size:1.2rem;font-weight:800;">GOVERNMENT OF INDIA</div>
        <div style="font-size:0.75rem;opacity:0.8;margin-top:4px;">PAY SLIP FOR THE MONTH OF ${month.toUpperCase()}</div>
      </div>
      <div class="salary-slip-body">
        <table class="salary-slip-table" style="margin-bottom:20px;">
          <tr><td style="width:50%"><strong>Name:</strong> ${name}</td><td><strong>Employee ID:</strong> ${empId}</td></tr>
          <tr><td><strong>Designation:</strong> ${designation}</td><td><strong>Pay Level:</strong> ${payLevel}</td></tr>
          <tr><td><strong>Basic Pay:</strong> ${formatCurrency(basicPay)}</td><td><strong>DA Rate:</strong> ${daPercent}%</td></tr>
        </table>
        <table class="salary-slip-table">
          <thead><tr><th>Earnings</th><th>Amount (₹)</th><th>Deductions</th><th>Amount (₹)</th></tr></thead>
          <tbody>
            <tr><td>Basic Pay</td><td>${formatCurrency(basicPay)}</td><td>NPS (10%)</td><td>${formatCurrency(nps)}</td></tr>
            <tr><td>DA (${daPercent}%)</td><td>${formatCurrency(da)}</td><td>CGHS</td><td>${formatCurrency(cghs)}</td></tr>
            <tr><td>HRA (${(HRA_RATES[hraCity]*100)}%)</td><td>${formatCurrency(hra)}</td><td></td><td></td></tr>
            <tr><td>TA</td><td>${formatCurrency(ta)}</td><td></td><td></td></tr>
            <tr><td>DA on TA</td><td>${formatCurrency(daOnTA)}</td><td></td><td></td></tr>
            <tr class="salary-slip-total">
              <td><strong>Gross Earnings</strong></td>
              <td><strong>${formatCurrency(grossEarnings)}</strong></td>
              <td><strong>Total Deductions</strong></td>
              <td><strong>${formatCurrency(totalDeductions)}</strong></td>
            </tr>
          </tbody>
        </table>
        <div style="background:var(--india-blue);color:white;padding:14px;border-radius:8px;margin-top:16px;text-align:center;">
          <strong>NET PAY: ${formatCurrency(netPay)}</strong>
          <div style="font-size:0.7rem;opacity:0.7;margin-top:4px;">Amount in words: ${numberToWords(netPay)} Rupees Only</div>
        </div>
        <div style="font-size:0.65rem;color:#999;margin-top:12px;text-align:center;">
          This is a computer-generated salary slip. Generated on ${new Date().toLocaleDateString('en-IN')} via 8thCPCSalary.com
        </div>
      </div>
    </div>
  `;

  const el = document.getElementById('salarySlipPreview');
  if (el) el.innerHTML = slipHTML;
  trackEvent('salary_slip_generated', { pay_level: payLevel, basic_pay: basicPay });
}

// ============================================================
// COMPARISON: 7TH vs 8TH CPC
// ============================================================
function compareSalary() {
  const basicPay = parseFloat(document.getElementById('basicPay')?.value) || 44900;
  const daPercent = parseFloat(document.getElementById('daPercent')?.value) || 62;
  const hraCity = document.getElementById('hraCity')?.value || 'Y';

  const fitments = [2.57, 2.86, 3.00, 3.10, 3.20, 3.40, 3.68];
  let tableRows = fitments.map(ff => {
    const newBasic = Math.round(basicPay * ff);
    const newHRA = Math.max(Math.round(newBasic * HRA_RATES_8TH[hraCity]), HRA_MINIMUM[hraCity]);
    const newTA = Math.round(3600 * ff);
    const newGross = newBasic + newHRA + newTA;
    const newNPS = Math.round(newBasic * 0.10);
    const newNet = newGross - newNPS;
    return `<tr ${ff === 2.57 ? 'class="highlight-row"' : ''}><td>${ff}×</td><td class="new-val">${formatCurrency(newBasic)}</td><td class="new-val">${formatCurrency(newHRA)}</td><td class="new-val">${formatCurrency(newGross)}</td><td class="new-val">${formatCurrency(newNet)}</td></tr>`;
  }).join('');

  const currentDA = Math.round(basicPay * daPercent / 100);
  const currentHRA = Math.max(Math.round(basicPay * HRA_RATES[hraCity]), HRA_MINIMUM[hraCity]);
  const currentTA = 3600;
  const currentGross = basicPay + currentDA + currentHRA + currentTA;
  const currentNet = currentGross - Math.round(basicPay * 0.10);

  openModal('7th vs 8th CPC Comparison', `
    <h3 style="font-size:0.8rem;color:var(--text-muted);margin-bottom:12px;">Current (7th CPC at DA ${daPercent}%)</h3>
    <div class="result-highlight" style="padding:16px;margin-bottom:20px;text-align:left;">
      <div class="flex-between"><span>Basic Pay</span><strong class="old-val">${formatCurrency(basicPay)}</strong></div>
      <div class="flex-between"><span>DA (${daPercent}%)</span><strong class="old-val">${formatCurrency(currentDA)}</strong></div>
      <div class="flex-between"><span>HRA (${(HRA_RATES[hraCity]*100)}%)</span><strong class="old-val">${formatCurrency(currentHRA)}</strong></div>
      <div class="flex-between"><span>Gross</span><strong>${formatCurrency(currentGross)}</strong></div>
      <div class="flex-between"><span><strong>Net In-Hand</strong></span><strong style="color:var(--saffron);font-size:1.1rem">${formatCurrency(currentNet)}</strong></div>
    </div>
    <h3 style="font-size:0.8rem;color:var(--text-muted);margin-bottom:12px;">8th CPC Projections (DA resets to 0%)</h3>
    <div style="overflow-x:auto;">
      <table class="comparison-table">
        <thead><tr><th>Fitment</th><th>New Basic</th><th>New HRA</th><th>Gross</th><th>Net In-Hand</th></tr></thead>
        <tbody>${tableRows}</tbody>
      </table>
    </div>
    <p style="font-size:0.65rem;color:var(--text-muted);margin-top:12px;">* Highlighted row shows most likely fitment (2.57×). HRA rates revised under 8th CPC. TA estimated with fitment.</p>
  `);
  trackEvent('comparison_calculated', { basic_pay: basicPay });
}

// ============================================================
// PAY LEVEL EXPLORER
// ============================================================
function buildLevelExplorer() {
  const grid = document.getElementById('levelGrid');
  if (!grid) return;
  grid.innerHTML = '';
  for (let level = 1; level <= 18; level++) {
    const matrix = PAY_MATRIX_7TH[level];
    if (!matrix) continue;
    const minPay = matrix[0];
    const div = document.createElement('div');
    div.className = 'level-card';
    div.dataset.level = level;
    div.innerHTML = `<div class="lc-level">Level ${level}</div><div class="lc-pay">₹${(minPay/1000).toFixed(0)}K</div>`;
    div.onclick = () => selectLevel(level);
    grid.appendChild(div);
  }
}

function selectLevel(level) {
  document.querySelectorAll('.level-card').forEach(c => c.classList.remove('active'));
  const selected = document.querySelector(`.level-card[data-level="${level}"]`);
  if (selected) selected.classList.add('active');

  const matrix = PAY_MATRIX_7TH[level];
  if (!matrix) return;

  const detail = document.getElementById('levelDetail');
  if (!detail) return;
  detail.innerHTML = `
    <div style="margin-bottom:12px;">
      <h3 style="font-weight:800;">Level ${level} — Pay Matrix</h3>
      <div style="font-size:0.75rem;color:var(--text-muted)">₹${formatNum(matrix[0])} to ₹${formatNum(matrix[matrix.length-1])}</div>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:6px;">
      ${matrix.map((pay, i) => `<div style="background:var(--surface-2);border:1px solid var(--border);border-radius:6px;padding:6px 10px;font-size:0.7rem;font-weight:700;font-family:var(--font-mono);cursor:pointer;" onclick="fillBasicPay(${pay})" title="Click to use">Cell ${i+1}<br>₹${formatNum(pay)}</div>`).join('')}
    </div>
    <button class="btn-small" style="margin-top:12px;" onclick="fillBasicPay(${matrix[0]})">Use Min Pay ₹${formatNum(matrix[0])}</button>
  `;
}

function fillBasicPay(amount) {
  const el = document.getElementById('basicPay');
  if (el) { el.value = amount; calculateSalary(); }
  scrollToElement('mainCalc');
}

// ============================================================
// SALARY GROWTH TIMELINE
// ============================================================
function renderSalaryTimeline() {
  const basicPay = parseFloat(document.getElementById('basicPay')?.value) || 44900;
  const el = document.getElementById('salaryTimeline');
  if (!el) return;

  const currentYear = new Date().getFullYear();
  const years = [];
  let pay = basicPay;

  for (let y = currentYear; y <= currentYear + 20; y++) {
    const da = y <= currentYear ? 62 : Math.min(62 + (y - currentYear) * 3, 100);
    const total = pay + Math.round(pay * da / 100) + Math.max(Math.round(pay * 0.18), 3600);
    years.push({ year: y, basic: pay, da, total });
    // Annual increment of 3%
    if ((y - currentYear + 1) % 1 === 0) pay = Math.round(pay * 1.03);
  }

  el.innerHTML = years.slice(0, 10).map((y, i) => `
    <div class="timeline-item">
      <div class="timeline-dot ${i === 0 ? 'active' : ''}"></div>
      <div class="flex-between" style="flex-wrap:wrap;gap:8px;">
        <div>
          <div class="timeline-date">${y.year} ${i === 0 ? '(Current)' : ''}</div>
          <div class="timeline-da">${formatCurrency(y.basic)}</div>
          <div class="timeline-note">Basic | DA: ${y.da}% | Gross: ~${formatCurrency(y.total)}</div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:0.7rem;color:var(--text-muted)">Annual Pkg</div>
          <div style="font-weight:800;font-family:var(--font-mono)">${formatCurrency(y.total * 12)}</div>
        </div>
      </div>
      <div class="da-bar-wrap"><div class="da-bar" style="width:${Math.min(100, (y.total / (years[years.length-1].total || 1)) * 100)}%"></div></div>
    </div>
  `).join('');
}

// ============================================================
// DA HISTORY RENDER
// ============================================================
function renderDAHistory() {
  const el = document.getElementById('daHistory');
  if (!el) return;
  const recent = DA_HISTORY_LOCAL.slice(-8).reverse();
  el.innerHTML = recent.map((item, i) => `
    <div class="timeline-item">
      <div class="timeline-dot ${i === 0 ? 'active' : ''}"></div>
      <div class="flex-between">
        <div>
          <div class="timeline-date">${new Date(item.date).toLocaleDateString('en-IN', {month:'short', year:'numeric'})}</div>
          <div class="timeline-da">${item.da}%</div>
        </div>
        <div class="da-bar-wrap" style="flex:1;margin-left:16px;margin-top:0;align-self:center;">
          <div class="da-bar" style="width:${(item.da/70)*100}%"></div>
        </div>
        <div style="font-size:0.65rem;color:var(--text-muted);margin-left:12px;min-width:32px;text-align:right">${item.da}%</div>
      </div>
    </div>
  `).join('');
}

// ============================================================
// DA PREDICTION ENGINE
// ============================================================
function predictDA() {
  // Based on CPI trend analysis
  const currentDA = 62;
  const predictions = [
    { period: 'Jul 2026', da: 65, probability: 95, basis: 'AICPI Apr-May 2026' },
    { period: 'Jan 2027', da: 68, probability: 80, basis: 'Projected CPI trend' },
    { period: 'Jul 2027', da: 71, probability: 65, basis: 'Historical 3% avg increase' },
    { period: 'Jan 2028', da: 74, probability: 55, basis: 'Long-term projection' }
  ];

  const el = document.getElementById('daPrediction');
  if (!el) return;
  el.innerHTML = predictions.map(p => `
    <div style="padding:14px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
      <div>
        <div style="font-weight:700">${p.period}</div>
        <div style="font-size:0.65rem;color:var(--text-muted)">${p.basis}</div>
      </div>
      <div style="display:flex;align-items:center;gap:12px;">
        <div style="font-size:1.2rem;font-weight:800;font-family:var(--font-mono);color:var(--saffron)">${p.da}%</div>
        <div style="background:var(--${p.probability>=85?'india-green-light':'gold-light'});color:var(--${p.probability>=85?'india-green':'gold'});padding:3px 10px;border-radius:100px;font-size:0.65rem;font-weight:800">${p.probability}% likely</div>
      </div>
    </div>
  `).join('');
}

// ============================================================
// GLOBAL SEARCH
// ============================================================
function globalSearch() {
  const query = document.getElementById('globalSearch')?.value?.toLowerCase().trim();
  if (!query) return;
  const articles = getLocalArticles().filter(a =>
    a.title.toLowerCase().includes(query) ||
    a.category.toLowerCase().includes(query) ||
    (a.tags || []).some(t => t.toLowerCase().includes(query))
  );
  const orders = getLocalOrders().filter(o =>
    o.title.toLowerCase().includes(query) ||
    o.department.toLowerCase().includes(query)
  );

  if (articles.length === 0 && orders.length === 0) {
    showToast('No results found for "' + query + '"', 'info');
    return;
  }

  let content = '';
  if (articles.length > 0) {
    content += `<h4 style="margin-bottom:12px;font-size:0.8rem;color:var(--text-muted)">Articles (${articles.length})</h4>`;
    content += articles.slice(0, 5).map(a => `
      <div class="profile-card" onclick="openArticle('${a.slug}')">
        <div><div style="font-weight:700">${a.title}</div><div style="font-size:0.7rem;color:var(--text-muted)">${a.category}</div></div>
        <div class="badge badge-saffron">${a.category}</div>
      </div>
    `).join('');
  }
  if (orders.length > 0) {
    content += `<h4 style="margin-bottom:12px;margin-top:16px;font-size:0.8rem;color:var(--text-muted)">Orders (${orders.length})</h4>`;
    content += orders.slice(0, 5).map(o => `
      <div class="profile-card">
        <div><div style="font-weight:700">${o.title}</div><div style="font-size:0.7rem;color:var(--text-muted)">${o.department}</div></div>
        <div class="badge badge-blue">${o.year}</div>
      </div>
    `).join('');
  }
  openModal('Search Results: "' + query + '"', content);
  trackEvent('search_performed', { query });
}

// ============================================================
// PROFILE MANAGEMENT
// ============================================================
function saveCurrentProfile() {
  const basicPay = parseFloat(document.getElementById('basicPay')?.value) || 44900;
  const daPercent = parseFloat(document.getElementById('daPercent')?.value) || 62;
  const hraCity = document.getElementById('hraCity')?.value || 'Y';
  const fitment = parseFloat(document.getElementById('fitmentSlider')?.value) || 2.57;

  const profiles = JSON.parse(localStorage.getItem('cpc8_profiles') || '[]');
  const profile = {
    id: Date.now(),
    name: `Profile ${profiles.length + 1}`,
    basicPay, daPercent, hraCity, fitment,
    savedAt: new Date().toISOString()
  };
  profiles.unshift(profile);
  localStorage.setItem('cpc8_profiles', JSON.stringify(profiles.slice(0, 10)));

  if (supabase && currentUser) {
    saveCalculation('salary', profile.name, { basicPay, daPercent, hraCity, fitment }, window.lastCalcResult || {});
  }

  showToast('Profile saved! ✅', 'success');
  renderProfiles();
  trackEvent('profile_saved', { basic_pay: basicPay });
}

function renderProfiles() {
  const el = document.getElementById('savedProfiles');
  if (!el) return;
  const profiles = JSON.parse(localStorage.getItem('cpc8_profiles') || '[]');
  if (profiles.length === 0) {
    el.innerHTML = '<p style="text-align:center;color:var(--text-muted);font-size:0.8rem;padding:20px;">No saved profiles yet. Calculate and save your salary.</p>';
    return;
  }
  el.innerHTML = profiles.map(p => `
    <div class="profile-card" onclick="loadProfile(${JSON.stringify(p).replace(/"/g, '&quot;')})">
      <div>
        <div style="font-weight:700">${p.name}</div>
        <div style="font-size:0.7rem;color:var(--text-muted)">Basic: ${formatCurrency(p.basicPay)} | DA: ${p.daPercent}% | ${p.hraCity} City</div>
        <div style="font-size:0.65rem;color:var(--text-muted)">${new Date(p.savedAt).toLocaleDateString('en-IN')}</div>
      </div>
      <button class="btn-small" onclick="event.stopPropagation();deleteProfile(${p.id})">×</button>
    </div>
  `).join('');
}

function loadProfile(profile) {
  if (document.getElementById('basicPay')) document.getElementById('basicPay').value = profile.basicPay;
  if (document.getElementById('daPercent')) document.getElementById('daPercent').value = profile.daPercent;
  if (document.getElementById('hraCity')) document.getElementById('hraCity').value = profile.hraCity;
  if (document.getElementById('fitmentSlider')) {
    document.getElementById('fitmentSlider').value = profile.fitment;
    document.getElementById('fitmentValue').textContent = profile.fitment + '×';
  }
  calculateSalary();
  showToast('Profile loaded ✅', 'success');
}

function deleteProfile(id) {
  const profiles = JSON.parse(localStorage.getItem('cpc8_profiles') || '[]');
  localStorage.setItem('cpc8_profiles', JSON.stringify(profiles.filter(p => p.id !== id)));
  renderProfiles();
}

// ============================================================
// SHARE
// ============================================================
function shareSalary() {
  const result = window.lastCalcResult;
  if (!result) { calculateSalary(); return; }
  const text = `🏛️ 8th CPC Salary Calculator\n\nCurrent Salary: ${formatCurrency(result.currentNetInHand)}/month\n8th CPC Projected: ${formatCurrency(result.newNetInHand)}/month (+${result.increasePercent}%)\n\nCalculate yours at 8thcpcsalary.com`;
  if (navigator.share) {
    navigator.share({ title: '8th CPC Salary Calculator', text, url: 'https://8thcpcsalary.com' });
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(text);
    showToast('Copied to clipboard! 📋', 'success');
  }
  trackEvent('share_result', { new_salary: result.newNetInHand });
}

// ============================================================
// UTILITIES
// ============================================================
function formatCurrency(amount) {
  if (!amount && amount !== 0) return '₹0';
  const num = Math.round(Math.abs(amount));
  if (num >= 10000000) return '₹' + (num / 10000000).toFixed(2) + 'Cr';
  if (num >= 100000) return '₹' + (num / 100000).toFixed(2) + 'L';
  return '₹' + num.toLocaleString('en-IN');
}

function formatCrore(amount) {
  if (!amount) return '₹0';
  const num = Math.round(Math.abs(amount));
  if (num >= 10000000) return '₹' + (num / 10000000).toFixed(2) + ' Cr';
  if (num >= 100000) return '₹' + (num / 100000).toFixed(2) + ' L';
  return '₹' + num.toLocaleString('en-IN');
}

function formatNum(num) {
  return Math.round(num).toLocaleString('en-IN');
}

function numberToWords(amount) {
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  if (amount === 0) return 'Zero';
  const n = Math.round(amount);
  function convertGroup(num) {
    if (num === 0) return '';
    if (num < 20) return ones[num] + ' ';
    if (num < 100) return tens[Math.floor(num/10)] + (num % 10 !== 0 ? ' ' + ones[num % 10] : '') + ' ';
    return ones[Math.floor(num/100)] + ' Hundred ' + convertGroup(num % 100);
  }
  let result = '';
  if (n >= 10000000) { result += convertGroup(Math.floor(n/10000000)) + 'Crore '; }
  if (n >= 100000) { result += convertGroup(Math.floor((n%10000000)/100000)) + 'Lakh '; }
  if (n >= 1000) { result += convertGroup(Math.floor((n%100000)/1000)) + 'Thousand '; }
  result += convertGroup(n % 1000);
  return result.trim();
}

function showToast(message, type = 'info', duration = 3000) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'fadeOut 0.2s ease forwards';
    setTimeout(() => toast.remove(), 200);
  }, duration);
}

function openModal(title, content) {
  const modal = document.getElementById('modal');
  if (!modal) return;
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML = content;
  modal.classList.add('open');
}

function closeModal(id = 'modal') {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
}

function openArticle(slug) {
  closeModal();
  const article = getLocalArticles().find(a => a.slug === slug);
  if (!article) return;
  openModal(article.title, `
    <div class="badge badge-saffron" style="margin-bottom:12px;">${article.category}</div>
    <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:16px;">
      ${new Date(article.published_at).toLocaleDateString('en-IN', {day:'numeric',month:'long',year:'numeric'})} · By ${article.author_name} · ${article.views?.toLocaleString('en-IN')} views
    </div>
    <div style="font-size:0.875rem;color:var(--text-secondary);line-height:1.7;">${article.content || article.excerpt || ''}</div>
  `);
  trackEvent('article_view', { slug, category: article.category });
}

function scrollToElement(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function scrollToTop() { window.scrollTo({ top: 0, behavior: 'smooth' }); }

function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
  const isDark = document.body.classList.contains('dark-mode');
  localStorage.setItem('darkMode', isDark ? '1' : '0');
  const btn = document.querySelector('.dark-mode-toggle');
  if (btn) btn.innerHTML = isDark ? '☀️ Light Mode' : '🌙 Dark Mode';
}

function updateClock() {
  const el = document.getElementById('headerClock');
  if (el) el.textContent = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function showConfetti() {
  const c = document.getElementById('confettiCanvas');
  if (!c) return;
  c.width = window.innerWidth;
  c.height = window.innerHeight;
  const ctx = c.getContext('2d');
  const particles = Array.from({ length: 100 }, () => ({
    x: Math.random() * c.width, y: -10,
    vx: (Math.random() - 0.5) * 6, vy: Math.random() * 4 + 2,
    size: Math.random() * 8 + 3, color: `hsl(${Math.random() * 360}, 70%, 60%)`,
    rotation: Math.random() * 360
  }));
  let frame = 0;
  function animate() {
    if (frame++ > 120) { ctx.clearRect(0, 0, c.width, c.height); return; }
    ctx.clearRect(0, 0, c.width, c.height);
    particles.forEach(p => {
      p.x += p.vx; p.y += p.vy; p.rotation += 3;
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rotation * Math.PI / 180);
      ctx.fillStyle = p.color; ctx.fillRect(-p.size/2, -p.size/2, p.size, p.size);
      ctx.restore();
    });
    requestAnimationFrame(animate);
  }
  animate();
}

// ============================================================
// NAVIGATION TABS
// ============================================================
function switchTab(tabGroup, tabId) {
  const panels = document.querySelectorAll(`[data-tab-group="${tabGroup}"]`);
  const btns = document.querySelectorAll(`[data-tab-btn="${tabGroup}"]`);
  panels.forEach(p => p.classList.remove('active'));
  btns.forEach(b => b.classList.remove('active'));
  const panel = document.getElementById(tabId);
  const btn = document.querySelector(`[data-tab-target="${tabId}"]`);
  if (panel) panel.classList.add('active');
  if (btn) btn.classList.add('active');
}

function switchMainSection(sectionId) {
  document.querySelectorAll('.main-section').forEach(s => s.style.display = 'none');
  const target = document.getElementById(sectionId);
  if (target) target.style.display = 'block';
  // Update nav
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelector(`[data-nav="${sectionId}"]`)?.classList.add('active');
  scrollToTop();
}

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  // Dark mode persistence
  if (localStorage.getItem('darkMode') === '1') {
    document.body.classList.add('dark-mode');
    const btn = document.querySelector('.dark-mode-toggle');
    if (btn) btn.innerHTML = '☀️ Light Mode';
  }

  // Clock
  setInterval(updateClock, 1000);
  updateClock();

  // Scroll-to-top visibility
  window.addEventListener('scroll', () => {
    const btn = document.querySelector('.scroll-top-btn');
    if (btn) btn.classList.toggle('visible', window.scrollY > 300);
  });

  // Fitment slider
  const slider = document.getElementById('fitmentSlider');
  if (slider) {
    slider.addEventListener('input', (e) => {
      const val = document.getElementById('fitmentValue');
      if (val) val.textContent = parseFloat(e.target.value).toFixed(2) + '×';
      calculateSalary();
    });
  }

  // Init calculations
  calculateSalary();
  buildLevelExplorer();
  renderDAHistory();
  updateRetirementDashboard();
  renderProfiles();
  predictDA();
  renderSalaryTimeline();

  // Init Supabase
  if (typeof initSupabase === 'function') initSupabase();
  if (typeof initCharts === 'function') initCharts();
  if (typeof renderNews === 'function') renderNews();
  if (typeof renderOrders === 'function') renderOrders();

  // Search on enter
  const searchInput = document.getElementById('globalSearch');
  if (searchInput) {
    searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') globalSearch(); });
  }
});

// Keyboard shortcut
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal.open').forEach(m => m.classList.remove('open'));
  }
});
