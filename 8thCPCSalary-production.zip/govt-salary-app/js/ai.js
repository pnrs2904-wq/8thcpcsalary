/**
 * ai.js — AI Salary Assistant
 * Supports Gemini, OpenAI, DeepSeek via /api/ask-ai proxy
 */

const AI_SUGGESTED_PROMPTS = [
  "What will my salary be under 8th CPC with basic pay ₹56,100?",
  "Calculate DA arrears from 59% to 62% for 3 months",
  "How much pension will I get after 30 years of service?",
  "What is the NPS corpus for Level 7 employee retiring in 15 years?",
  "Compare 7th vs 8th CPC for Level 10 employee",
  "What is the gratuity for basic pay ₹78,800 after 25 years?",
  "Explain HRA calculation for X city employees",
  "What is the expected DA in January 2027?",
];

let chatHistory = [];
let isAITyping = false;

function initAIChat() {
  renderSuggestedPrompts();
  addSystemMessage();
}

function addSystemMessage() {
  const welcomeMsg = {
    role: 'assistant',
    content: `Namaste! 🙏 I'm your **8th CPC AI Salary Assistant**.\n\nI can help you with:\n• Salary calculations under 8th Pay Commission\n• DA, HRA, NPS, Pension & Gratuity queries\n• Latest government orders & circulars\n• Retirement planning & NPS corpus\n\nAsk me anything about your salary or retirement benefits!`
  };
  renderChatMessage(welcomeMsg);
}

function renderSuggestedPrompts() {
  const container = document.getElementById('chatSuggestions');
  if (!container) return;
  const shuffled = AI_SUGGESTED_PROMPTS.sort(() => Math.random() - 0.5).slice(0, 4);
  container.innerHTML = shuffled.map(p =>
    `<button class="chat-suggest-chip" onclick="sendSuggestedPrompt('${p.replace(/'/g,"\\'")}'">${p}</button>`
  ).join('');
}

function sendSuggestedPrompt(prompt) {
  const input = document.getElementById('chatInput');
  if (input) { input.value = prompt; sendChatMessage(); }
}

async function sendChatMessage() {
  const input = document.getElementById('chatInput');
  if (!input || isAITyping) return;
  const message = input.value.trim();
  if (!message) return;
  input.value = '';
  input.style.height = 'auto';

  // Add user message
  const userMsg = { role: 'user', content: message };
  chatHistory.push(userMsg);
  renderChatMessage(userMsg);
  scrollChatToBottom();

  // Show typing
  showTypingIndicator();
  isAITyping = true;

  try {
    const response = await callAIAPI(message);
    removeTypingIndicator();
    const assistantMsg = { role: 'assistant', content: response };
    chatHistory.push(assistantMsg);
    renderChatMessage(assistantMsg);
    trackEvent('ai_query', { query_length: message.length });
  } catch (err) {
    removeTypingIndicator();
    const errMsg = { role: 'assistant', content: `I apologize, I'm having trouble connecting right now. Please try again in a moment.\n\n**Tip:** You can still use all calculators above for precise calculations.` };
    renderChatMessage(errMsg);
  }
  isAITyping = false;
  scrollChatToBottom();
  renderSuggestedPrompts();
}

async function callAIAPI(userMessage) {
  // Build context-aware system prompt
  const currentCalc = window.lastCalcResult;
  const contextStr = currentCalc
    ? `\nUser's current calculation: Basic Pay ₹${currentCalc.basicPay}, DA ${currentCalc.daPercent}%, HRA City ${currentCalc.hraCity}, Current Net In-Hand ₹${currentCalc.currentNetInHand}, Projected 8th CPC ₹${currentCalc.newNetInHand}`
    : '';

  const systemPrompt = `You are an expert AI assistant for Indian government employees, specializing in 8th Pay Commission (8th CPC), DA calculations, pension, NPS, HRA, gratuity, leave encashment, and all central government pay-related queries.

Current context:
- Current DA: 62% (effective Jan 2026)
- Expected DA Jul 2026: 65%
- 8th CPC: constituted, expected fitment factor 2.57x–3.68x
- 7th CPC pay levels: 1 to 18
- NPS government contribution: 14% of (Basic+DA)
- Pension: 50% of last basic pay (OPS)${contextStr}

Guidelines:
- Always provide precise, actionable answers with actual numbers
- Format amounts in Indian system (₹ symbol, lakhs, crores)
- Cite relevant government orders when applicable
- Be concise but thorough
- Use bullet points for clarity
- If asked to calculate, show step-by-step working`;

  // Try /api/ask-ai proxy first
  try {
    const res = await fetch('/api/ask-ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: userMessage,
        history: chatHistory.slice(-6), // Last 3 exchanges
        system: systemPrompt
      })
    });
    if (res.ok) {
      const data = await res.json();
      return data.response || data.message || 'No response from AI.';
    }
  } catch (e) {
    // API not available, use fallback
  }

  // Fallback: rule-based calculator responses
  return generateFallbackResponse(userMessage);
}

function generateFallbackResponse(query) {
  const q = query.toLowerCase();

  // Extract numbers from query
  const numbers = query.match(/[\d,]+(?:\.\d+)?/g)?.map(n => parseFloat(n.replace(/,/g, ''))) || [];
  const basicPay = numbers[0] || (window.lastCalcResult?.basicPay) || 44900;

  if (q.includes('da') && (q.includes('arrear') || q.includes('arear'))) {
    const oldDA = 59, newDA = 62, months = 3;
    const diff = Math.round(basicPay * (newDA - oldDA) / 100);
    return `**DA Arrears Calculation**\n\nFor Basic Pay **₹${basicPay.toLocaleString('en-IN')}**:\n- DA @ ${oldDA}% = ₹${Math.round(basicPay*oldDA/100).toLocaleString('en-IN')}/month\n- DA @ ${newDA}% = ₹${Math.round(basicPay*newDA/100).toLocaleString('en-IN')}/month\n- Difference = ₹${diff.toLocaleString('en-IN')}/month\n- **Arrears for ${months} months = ₹${(diff*months).toLocaleString('en-IN')}**\n\nUse the DA Arrears Calculator above for custom periods.`;
  }

  if (q.includes('8th cpc') || q.includes('8th pay') || q.includes('fitment')) {
    const projected = Math.round(basicPay * 2.57);
    return `**8th CPC Salary Projection**\n\nFor Basic Pay **₹${basicPay.toLocaleString('en-IN')}** (Level based on current pay):\n\n| Fitment | New Basic | Est. In-Hand |\n|---------|-----------|-------------|\n| 2.57× | ₹${Math.round(basicPay*2.57).toLocaleString('en-IN')} | ₹${Math.round(basicPay*2.57*1.35).toLocaleString('en-IN')} |\n| 3.00× | ₹${Math.round(basicPay*3).toLocaleString('en-IN')} | ₹${Math.round(basicPay*3*1.35).toLocaleString('en-IN')} |\n| 3.68× | ₹${Math.round(basicPay*3.68).toLocaleString('en-IN')} | ₹${Math.round(basicPay*3.68*1.35).toLocaleString('en-IN')} |\n\n*Note: DA resets to 0% on 8th CPC implementation.*`;
  }

  if (q.includes('pension')) {
    const pension = Math.round(basicPay * 0.50);
    const dr = Math.round(pension * 0.62);
    return `**Pension Calculation (OPS)**\n\nFor last basic pay **₹${basicPay.toLocaleString('en-IN')}**:\n- Basic Pension (50%) = **₹${pension.toLocaleString('en-IN')}**/month\n- Dearness Relief @ 62% = ₹${dr.toLocaleString('en-IN')}/month\n- **Total Monthly Pension = ₹${(pension+dr).toLocaleString('en-IN')}**\n- Family Pension (60%) = ₹${Math.round(pension*0.6).toLocaleString('en-IN')}/month\n\nMinimum pension is ₹9,000/month.`;
  }

  if (q.includes('nps') || q.includes('national pension')) {
    const da = Math.round(basicPay * 0.62);
    const empContrib = Math.round((basicPay + da) * 0.10);
    const govtContrib = Math.round((basicPay + da) * 0.14);
    const total = empContrib + govtContrib;
    const corpus20yr = total * ((Math.pow(1 + 0.10/12, 240) - 1) / (0.10/12));
    return `**NPS Calculation**\n\nFor Basic Pay **₹${basicPay.toLocaleString('en-IN')}** + DA 62%:\n- Basic + DA = ₹${(basicPay+da).toLocaleString('en-IN')}\n- Employee Contribution (10%) = **₹${empContrib.toLocaleString('en-IN')}**/month\n- Government Contribution (14%) = **₹${govtContrib.toLocaleString('en-IN')}**/month\n- Total Monthly = **₹${total.toLocaleString('en-IN')}**\n\n**Projected Corpus (assuming 10% returns):**\n- After 20 years: ₹${(corpus20yr/10000000).toFixed(2)} Crore\n- Lump Sum (60%): ₹${(corpus20yr*0.6/10000000).toFixed(2)} Crore\n- Est. Monthly Pension: ₹${Math.round(corpus20yr*0.4*0.06/12).toLocaleString('en-IN')}`;
  }

  if (q.includes('hra') || q.includes('house rent')) {
    const hraX = Math.max(Math.round(basicPay * 0.27), 5400);
    const hraY = Math.max(Math.round(basicPay * 0.18), 3600);
    const hraZ = Math.max(Math.round(basicPay * 0.09), 1800);
    return `**HRA Calculation (7th CPC)**\n\nFor Basic Pay **₹${basicPay.toLocaleString('en-IN')}**:\n- **X City (27%):** ₹${hraX.toLocaleString('en-IN')}/month\n- **Y City (18%):** ₹${hraY.toLocaleString('en-IN')}/month\n- **Z City (9%):** ₹${hraZ.toLocaleString('en-IN')}/month\n\n*Rates under 8th CPC expected to be 30%/20%/10% for X/Y/Z cities.*`;
  }

  if (q.includes('gratuity')) {
    const years = numbers.find(n => n < 50) || 25;
    const da = Math.round(basicPay * 0.62);
    const halfYears = Math.min(years * 2, 33);
    const gratuity = Math.min(Math.round((basicPay + da) * halfYears / 4), 2500000);
    return `**Gratuity Calculation**\n\nFor Basic Pay **₹${basicPay.toLocaleString('en-IN')}**, ${years} years service:\n- Basic + DA = ₹${(basicPay+da).toLocaleString('en-IN')}\n- Formula: (Basic+DA) × ¼ × qualifying periods\n- Qualifying half-years: ${halfYears}\n- **Gratuity = ₹${gratuity.toLocaleString('en-IN')}**\n\n*Maximum gratuity ceiling: ₹25 Lakhs (₹30L revision pending)*`;
  }

  if (q.includes('da') && (q.includes('predict') || q.includes('next') || q.includes('july 2026') || q.includes('jan 2027'))) {
    return `**DA Prediction Analysis**\n\nBased on AICPI trend analysis:\n\n| Period | Expected DA | Probability |\n|--------|-------------|-------------|\n| Current | 62% | Confirmed |\n| Jul 2026 | **65%** | 95% likely |\n| Jan 2027 | 68% | 80% likely |\n| Jul 2027 | 71% | 65% likely |\n\n*Predictions based on historical 3% average biannual increase and current AICPI data.*`;
  }

  // Default response
  return `I can help you calculate that! Here's what I know:\n\n**Your Context:**\n- Current DA: 62% (Jan 2026)\n- Expected DA Jul 2026: ~65%\n- 8th CPC fitment: 2.57× to 3.68×\n\nFor precise calculations, please use the calculators above. Or ask me a specific question like:\n- "What is my 8th CPC salary for basic pay ₹44,900?"\n- "Calculate my NPS corpus with 15 years remaining"\n- "How much pension for ₹78,800 basic pay?"`;
}

function renderChatMessage(msg) {
  const container = document.getElementById('chatMessages');
  if (!container) return;
  const isUser = msg.role === 'user';
  const div = document.createElement('div');
  div.className = `chat-msg ${isUser ? 'user' : ''}`;
  div.innerHTML = `
    <div class="chat-msg-avatar">${isUser ? '👤' : '🤖'}</div>
    <div class="chat-msg-bubble">${formatMarkdown(msg.content)}</div>
  `;
  container.appendChild(div);
}

function formatMarkdown(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/`(.*?)`/g, '<code style="background:var(--surface-3);padding:1px 5px;border-radius:3px;font-family:var(--font-mono);font-size:0.8em">$1</code>')
    .replace(/\n/g, '<br>')
    .replace(/\|(.+)\|/g, (match) => {
      const cells = match.split('|').filter(c => c.trim());
      return '<table style="width:100%;border-collapse:collapse;margin:8px 0;font-size:0.78em">' +
        '<tr>' + cells.map(c => `<td style="border:1px solid var(--border);padding:5px 8px">${c.trim()}</td>`).join('') + '</tr></table>';
    });
}

function showTypingIndicator() {
  const container = document.getElementById('chatMessages');
  if (!container) return;
  const div = document.createElement('div');
  div.id = 'typingIndicator';
  div.className = 'chat-msg';
  div.innerHTML = `
    <div class="chat-msg-avatar">🤖</div>
    <div class="chat-msg-bubble">
      <div class="chat-typing"><span></span><span></span><span></span></div>
    </div>
  `;
  container.appendChild(div);
  scrollChatToBottom();
}

function removeTypingIndicator() {
  document.getElementById('typingIndicator')?.remove();
}

function scrollChatToBottom() {
  const container = document.getElementById('chatMessages');
  if (container) container.scrollTop = container.scrollHeight;
}

function clearChat() {
  chatHistory = [];
  const container = document.getElementById('chatMessages');
  if (container) container.innerHTML = '';
  addSystemMessage();
  showToast('Chat cleared', 'info');
}

// Auto-resize chat input
document.addEventListener('DOMContentLoaded', () => {
  const chatInput = document.getElementById('chatInput');
  if (chatInput) {
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMessage(); }
    });
    chatInput.addEventListener('input', () => {
      chatInput.style.height = 'auto';
      chatInput.style.height = Math.min(chatInput.scrollHeight, 100) + 'px';
    });
  }
  initAIChat();
});
