/**
 * pdf.js — Professional PDF report generator using jsPDF
 */

async function generatePDFReport() {
  if (!window.jspdf) { showToast('PDF library loading...', 'info'); return; }
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const result = window.lastCalcResult;
  if (!result) { calculateSalary(); await new Promise(r => setTimeout(r, 100)); }

  const W = 210, margin = 18;
  let y = 0;

  // ── Header bar (tricolor) ──────────────────────
  doc.setFillColor(255, 153, 51);
  doc.rect(0, 0, W / 3, 8, 'F');
  doc.setFillColor(255, 255, 255);
  doc.rect(W / 3, 0, W / 3, 8, 'F');
  doc.setFillColor(19, 136, 8);
  doc.rect((W / 3) * 2, 0, W / 3, 8, 'F');

  // ── Government Header ─────────────────────────
  doc.setFillColor(0, 43, 127);
  doc.rect(0, 8, W, 32, 'F');

  doc.setTextColor(255, 183, 77);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('8TH CPC SALARY REPORT', W / 2, 22, { align: 'center' });

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text('8thCPCSalary.com | India\'s #1 Pay Commission Portal', W / 2, 30, { align: 'center' });
  doc.text('Government Employee Financial Super App', W / 2, 35, { align: 'center' });

  y = 50;

  // ── Timestamp and watermark ───────────────────
  doc.setTextColor(150, 150, 150);
  doc.setFontSize(7);
  doc.text(`Generated: ${new Date().toLocaleString('en-IN')}`, margin, y);
  doc.text('CONFIDENTIAL — FOR PERSONAL USE ONLY', W - margin, y, { align: 'right' });
  y += 10;

  // ── Section: Current Inputs ───────────────────
  doc.setFillColor(248, 249, 252);
  doc.roundedRect(margin, y, W - margin * 2, 30, 3, 3, 'F');
  doc.setDrawColor(226, 230, 239);
  doc.roundedRect(margin, y, W - margin * 2, 30, 3, 3, 'D');

  doc.setTextColor(232, 117, 26);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('YOUR CURRENT DETAILS (7TH CPC)', margin + 6, y + 8);

  const r = window.lastCalcResult || {};
  const inputs = [
    ['Basic Pay', `₹${(r.basicPay || 0).toLocaleString('en-IN')}`],
    ['Current DA', `${r.daPercent || 62}%`],
    ['HRA City', r.hraCity || 'Y'],
    ['Fitment Factor', `${r.fitmentFactor || 2.57}×`]
  ];
  doc.setTextColor(61, 79, 110);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  inputs.forEach((item, i) => {
    const col = i < 2 ? margin + 6 : W / 2 + 6;
    const row = y + 16 + (i % 2) * 8;
    doc.text(`${item[0]}:`, col, row);
    doc.setFont('helvetica', 'bold');
    doc.text(item[1], col + 28, row);
    doc.setFont('helvetica', 'normal');
  });
  y += 38;

  // ── Section: 7th CPC Breakdown ────────────────
  doc.setFillColor(0, 43, 127);
  doc.roundedRect(margin, y, (W - margin * 2 - 8) / 2, 60, 3, 3, 'F');

  doc.setTextColor(255, 183, 77);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('7TH CPC (CURRENT)', margin + 6, y + 9);

  const old7 = [
    ['Basic Pay', r.basicPay || 0],
    ['DA (' + (r.daPercent || 62) + '%)', r.currentDA || 0],
    ['HRA', r.currentHRA || 0],
    ['TA + DA on TA', (r.currentTA || 0) + Math.round((r.currentTA || 0) * (r.daPercent || 62) / 100)],
    ['NPS Deduction', -Math.round((r.basicPay || 0) * 0.10)],
  ];
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(200, 210, 255);
  doc.setFontSize(8);
  old7.forEach((item, i) => {
    doc.text(item[0], margin + 6, y + 18 + i * 7);
    const val = item[1] < 0 ? `-₹${Math.abs(item[1]).toLocaleString('en-IN')}` : `₹${Math.round(item[1]).toLocaleString('en-IN')}`;
    doc.setTextColor(item[1] < 0 ? 255 : 255, item[1] < 0 ? 100 : 255, item[1] < 0 ? 100 : 255);
    doc.text(val, margin + 6 + (W - margin * 2 - 8) / 2 - 18, y + 18 + i * 7, { align: 'right' });
    doc.setTextColor(200, 210, 255);
  });
  doc.setFillColor(255, 255, 255, 0.1);
  doc.setDrawColor(255, 183, 77);
  doc.line(margin + 6, y + 52, margin + (W - margin * 2 - 8) / 2 - 4, y + 52);
  doc.setTextColor(255, 183, 77);
  doc.setFont('helvetica', 'bold');
  doc.text('Net In-Hand', margin + 6, y + 57);
  doc.text(`₹${(r.currentNetInHand || 0).toLocaleString('en-IN')}`, margin + 6 + (W - margin * 2 - 8) / 2 - 18, y + 57, { align: 'right' });

  // 8th CPC block
  const col2x = margin + (W - margin * 2 - 8) / 2 + 8;
  const col2w = (W - margin * 2 - 8) / 2;

  doc.setFillColor(4, 106, 56);
  doc.roundedRect(col2x, y, col2w, 60, 3, 3, 'F');

  doc.setTextColor(255, 215, 0);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('8TH CPC (PROJECTED)', col2x + 6, y + 9);

  const new8 = [
    ['New Basic Pay', r.newBasicPay || 0],
    ['DA (0% at reset)', 0],
    ['New HRA', r.newHRA || 0],
    ['New TA', r.newTA || 0],
    ['NPS Deduction', -Math.round((r.newBasicPay || 0) * 0.10)],
  ];
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(200, 255, 200);
  doc.setFontSize(8);
  new8.forEach((item, i) => {
    doc.text(item[0], col2x + 6, y + 18 + i * 7);
    const val = item[1] < 0 ? `-₹${Math.abs(item[1]).toLocaleString('en-IN')}` : `₹${Math.round(item[1]).toLocaleString('en-IN')}`;
    doc.setTextColor(item[1] < 0 ? 255 : 200, item[1] < 0 ? 100 : 255, item[1] < 0 ? 100 : 200);
    doc.text(val, col2x + col2w - 6, y + 18 + i * 7, { align: 'right' });
    doc.setTextColor(200, 255, 200);
  });
  doc.setDrawColor(255, 215, 0);
  doc.line(col2x + 6, y + 52, col2x + col2w - 4, y + 52);
  doc.setTextColor(255, 215, 0);
  doc.setFont('helvetica', 'bold');
  doc.text('Net In-Hand', col2x + 6, y + 57);
  doc.text(`₹${(r.newNetInHand || 0).toLocaleString('en-IN')}`, col2x + col2w - 6, y + 57, { align: 'right' });

  y += 68;

  // ── Monthly Increase Banner ───────────────────
  const increase = (r.newNetInHand || 0) - (r.currentNetInHand || 0);
  doc.setFillColor(255, 243, 232);
  doc.roundedRect(margin, y, W - margin * 2, 18, 3, 3, 'F');
  doc.setDrawColor(232, 117, 26);
  doc.roundedRect(margin, y, W - margin * 2, 18, 3, 3, 'D');
  doc.setTextColor(196, 94, 10);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(`Monthly Increase: +₹${increase.toLocaleString('en-IN')} (+${r.increasePercent}%)  |  Annual Increase: +₹${(increase * 12).toLocaleString('en-IN')}`, W / 2, y + 11, { align: 'center' });
  y += 26;

  // ── DA History ────────────────────────────────
  doc.setTextColor(232, 117, 26);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('DA HISTORY (7TH CPC)', margin, y);
  y += 6;

  const daData = [
    ['2020-Jan', '21%'], ['2021-Jul', '28%'], ['2022-Jan', '34%'], ['2022-Jul', '38%'],
    ['2023-Jan', '42%'], ['2023-Jul', '46%'], ['2024-Jan', '50%'], ['2024-Jul', '53%'],
    ['2025-Jan', '55%'], ['2025-Jul', '59%'], ['2026-Jan', '62% ✓'], ['2026-Jul', '65% (proj)']
  ];

  doc.setFillColor(226, 230, 239);
  doc.rect(margin, y, W - margin * 2, 6, 'F');
  doc.setTextColor(61, 79, 110);
  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.text('Period', margin + 4, y + 4);
  doc.text('DA Rate', margin + 40, y + 4);
  doc.text('Period', margin + 80, y + 4);
  doc.text('DA Rate', margin + 120, y + 4);
  doc.text('Period', margin + 140, y + 4);
  doc.text('DA Rate', margin + 160, y + 4);
  y += 7;

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(61, 79, 110);
  for (let i = 0; i < daData.length; i += 3) {
    if (i % 6 === 0) { doc.setFillColor(248, 249, 252); doc.rect(margin, y - 1, W - margin * 2, 7, 'F'); }
    const row = [daData[i], daData[i+1], daData[i+2]].filter(Boolean);
    row.forEach((d, j) => {
      doc.text(d[0], margin + 4 + j * 60, y + 4);
      doc.setTextColor(j === 2 ? 4 : 61, j === 2 ? 106 : 79, j === 2 ? 56 : 110);
      doc.text(d[1], margin + 40 + j * 60, y + 4);
      doc.setTextColor(61, 79, 110);
    });
    y += 7;
  }
  y += 8;

  // ── Footer ────────────────────────────────────
  doc.setFillColor(0, 43, 127);
  doc.rect(0, 287, W, 10, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7);
  doc.setFont('helvetica', 'normal');
  doc.text('8thCPCSalary.com — India\'s Most Trusted Government Employee Financial Platform', W / 2, 293, { align: 'center' });
  doc.text('This report is for informational purposes only. Actual figures may vary based on official government orders.', W / 2, 297, { align: 'center' });

  // ── Save ─────────────────────────────────────
  const filename = `8th_CPC_Report_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(filename);
  showToast('PDF downloaded! 📄', 'success');
  trackEvent('pdf_download', { basic_pay: r.basicPay });
}

async function generateSalarySlipPDF() {
  if (!window.jspdf) { showToast('PDF library loading...', 'info'); return; }
  const slip = document.getElementById('generatedSlip');
  if (!slip) { showToast('Generate salary slip first', 'info'); return; }
  showToast('Generating Salary Slip PDF...', 'info');
  // Use html2canvas approach or basic jsPDF text
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  // Header
  doc.setFillColor(0, 43, 127);
  doc.rect(0, 0, 210, 30, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('GOVERNMENT OF INDIA', 105, 13, { align: 'center' });
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('PAY SLIP', 105, 22, { align: 'center' });
  // Content from DOM
  const name = document.getElementById('slipName')?.value || 'Employee';
  const basic = parseFloat(document.getElementById('slipBasic')?.value) || 44900;
  const da = Math.round(basic * 0.62);
  const hra = Math.max(Math.round(basic * 0.18), 3600);
  const net = basic + da + hra - Math.round(basic * 0.10) - 500;
  let y = 40;
  doc.setTextColor(61, 79, 110);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(`Employee: ${name}`, 18, y);
  y += 8;
  const rows = [
    ['Basic Pay', basic, 'NPS (10%)', Math.round(basic * 0.10)],
    ['DA (62%)', da, 'CGHS', 500],
    ['HRA (18%)', hra, '', ''],
    ['TOTAL GROSS', basic + da + hra, 'TOTAL DEDUCTIONS', Math.round(basic * 0.10) + 500],
  ];
  rows.forEach((row, i) => {
    doc.setFillColor(i % 2 === 0 ? 248 : 255, 249, 252);
    doc.rect(18, y - 4, 174, 8, 'F');
    doc.setFont('helvetica', i === 3 ? 'bold' : 'normal');
    doc.setTextColor(61, 79, 110);
    doc.text(row[0], 22, y + 1);
    if (row[1]) doc.text(`₹${Math.round(row[1]).toLocaleString('en-IN')}`, 80, y + 1);
    if (row[2]) doc.text(row[2], 110, y + 1);
    if (row[3]) doc.text(`₹${Math.round(row[3]).toLocaleString('en-IN')}`, 168, y + 1);
    y += 9;
  });
  y += 6;
  doc.setFillColor(0, 43, 127);
  doc.rect(18, y, 174, 12, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(`NET PAY: ₹${net.toLocaleString('en-IN')}`, 105, y + 8, { align: 'center' });
  const filename = `Salary_Slip_${name.replace(/ /g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(filename);
  showToast('Salary Slip PDF downloaded! 📄', 'success');
  trackEvent('salary_slip_pdf', { basic_pay: basic });
}
