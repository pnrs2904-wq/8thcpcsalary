/**
 * cms.js — News rendering, Government Orders, Admin Panel
 */

// ============================================================
// NEWS / ARTICLES
// ============================================================
let newsPage = 1;
let newsCategory = 'all';
let articlesData = [];

async function renderNews(category = 'all', page = 1) {
  newsCategory = category;
  newsPage = page;
  const grid = document.getElementById('newsGrid');
  if (!grid) return;

  grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-muted)">Loading articles...</div>`;

  let articles;
  if (typeof fetchArticles === 'function' && window.supabase) {
    const res = await fetchArticles({ category: category === 'all' ? null : category, limit: 9, offset: (page - 1) * 9 });
    articles = res.data;
  } else {
    articles = getLocalArticles();
    if (category !== 'all') articles = articles.filter(a => a.category === category);
    const start = (page - 1) * 9;
    articles = articles.slice(start, start + 9);
  }

  articlesData = articles;
  grid.innerHTML = articles.length === 0
    ? `<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-muted)">No articles found.</div>`
    : articles.map(a => renderNewsCard(a)).join('');

  updateNewsCategoryTabs(category);
}

function renderNewsCard(article) {
  const catClass = {
    'DA Update': 'cat-da', 'Pension': 'cat-pension', 'NPS': 'cat-nps'
  }[article.category] || '';

  const catEmoji = {
    '8th CPC': '📊', 'DA Update': '📈', 'Pension': '🏛️', 'NPS': '💰',
    'Railways': '🚂', 'Defence': '🎖️', 'SSC': '📚', 'UPSC': '🎯',
    'Teachers': '👨‍🏫', 'Government Orders': '📜', 'Benefits': '✅', 'Retirement': '🌅'
  }[article.category] || '📰';

  const timeAgo = getTimeAgo(article.published_at);
  const badges = [
    article.is_featured ? '<span class="badge badge-gold" style="margin-left:6px;">Featured</span>' : '',
    article.is_trending ? '<span class="badge badge-saffron" style="margin-left:6px;">Trending 🔥</span>' : ''
  ].join('');

  return `
    <div class="news-card" onclick="openArticle('${article.slug}')">
      <div class="news-card-img">${catEmoji}</div>
      <div class="news-card-body">
        <span class="news-cat-badge ${catClass}">${article.category}</span>${badges}
        <div class="news-title">${sanitizeText(article.title)}</div>
        <div style="font-size:0.78rem;color:var(--text-secondary);margin-bottom:10px;line-height:1.5;">
          ${sanitizeText(article.excerpt || '').substring(0, 100)}${article.excerpt?.length > 100 ? '...' : ''}
        </div>
        <div class="news-meta">
          <span>${article.author_name || 'Editorial Team'}</span>
          <span class="news-meta-dot"></span>
          <span>${timeAgo}</span>
          <span class="news-meta-dot"></span>
          <span>👁 ${(article.views || 0).toLocaleString('en-IN')}</span>
        </div>
      </div>
    </div>
  `;
}

function updateNewsCategoryTabs(activeCategory) {
  document.querySelectorAll('[data-news-cat]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.newsCat === activeCategory);
  });
}

function filterNewsByCategory(category) {
  renderNews(category, 1);
}

function loadMoreNews() {
  renderNews(newsCategory, newsPage + 1);
}

// ============================================================
// GOVERNMENT ORDERS
// ============================================================
let ordersFilter = { year: '', dept: '', category: '' };

async function renderOrders(filters = {}) {
  ordersFilter = { ...ordersFilter, ...filters };
  const tbody = document.getElementById('ordersTableBody');
  if (!tbody) return;
  tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text-muted)">Loading orders...</td></tr>`;

  let orders;
  if (typeof fetchOrders === 'function') {
    const res = await fetchOrders({ ...ordersFilter });
    orders = res.data;
  } else {
    orders = getLocalOrders();
    if (ordersFilter.year) orders = orders.filter(o => o.year == ordersFilter.year);
    if (ordersFilter.dept) orders = orders.filter(o => o.department.toLowerCase().includes(ordersFilter.dept.toLowerCase()));
    if (ordersFilter.category) orders = orders.filter(o => o.category === ordersFilter.category);
  }

  tbody.innerHTML = orders.length === 0
    ? `<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text-muted)">No orders found.</td></tr>`
    : orders.map(o => `
        <tr>
          <td class="order-title-cell">${sanitizeText(o.title)}<br><span style="font-size:0.65rem;color:var(--text-muted)">${o.order_number || ''}</span></td>
          <td><span class="order-dept-badge">${o.department}</span></td>
          <td><span class="badge badge-blue">${o.category}</span></td>
          <td style="font-family:var(--font-mono);font-size:0.75rem">${o.year}</td>
          <td>
            ${o.pdf_url
              ? `<a href="${o.pdf_url}" target="_blank" onclick="trackOrderDownload('${o.id}')" class="btn-small">📥 PDF</a>`
              : `<button class="btn-small" disabled style="opacity:0.5">No PDF</button>`
            }
          </td>
        </tr>
      `).join('');
}

function trackOrderDownload(orderId) {
  trackEvent('order_download', { order_id: orderId });
  if (typeof incrementOrderDownloads === 'function') incrementOrderDownloads(orderId);
}

function filterOrders() {
  const year = document.getElementById('orderYearFilter')?.value || '';
  const dept = document.getElementById('orderDeptFilter')?.value || '';
  const cat = document.getElementById('orderCatFilter')?.value || '';
  renderOrders({ year, dept, category: cat });
}

// ============================================================
// ADMIN PANEL
// ============================================================
function openAdminPanel() {
  if (!currentUser) { openAuthModal('login'); return; }
  if (userProfile?.role !== 'admin' && userProfile?.role !== 'editor') {
    showToast('Admin access required', 'error');
    return;
  }
  openModal('👑 Admin Dashboard', renderAdminDashboard());
}

function renderAdminDashboard() {
  const articles = getLocalArticles();
  const orders = getLocalOrders();
  return `
    <div class="stats-grid" style="margin-bottom:20px;">
      <div class="stat-mini"><div class="stat-mini-val">${articles.length}</div><div class="stat-mini-label">Articles</div></div>
      <div class="stat-mini"><div class="stat-mini-val">${orders.length}</div><div class="stat-mini-label">Orders</div></div>
      <div class="stat-mini"><div class="stat-mini-val">—</div><div class="stat-mini-label">Subscribers</div></div>
    </div>
    <div style="display:grid;gap:10px;">
      <button class="btn-primary" style="width:100%;" onclick="closeModal();openCreateArticleModal()">📝 Create Article</button>
      <button class="btn-primary" style="width:100%;background:var(--india-blue);" onclick="closeModal();openCreateOrderModal()">📜 Upload Government Order</button>
      <button class="btn-secondary" style="width:100%;" onclick="closeModal();openArticleListAdmin()">📋 Manage Articles</button>
      <button class="btn-secondary" style="width:100%;" onclick="closeModal();openOrderListAdmin()">📂 Manage Orders</button>
      <button class="btn-danger" style="width:100%;margin-top:8px;" onclick="signOut();closeModal()">🚪 Logout</button>
    </div>
  `;
}

function openCreateArticleModal() {
  const cats = ['8th CPC', 'DA Update', 'Pension', 'NPS', 'Railways', 'Defence', 'SSC', 'UPSC', 'Teachers', 'Government Orders', 'Benefits', 'Retirement'];
  openModal('📝 Create Article', `
    <div class="input-group"><label class="input-label">Title *</label><input id="artTitle" class="input-field" placeholder="Article title" required></div>
    <div class="input-group"><label class="input-label">Slug</label><input id="artSlug" class="input-field" placeholder="auto-generated-from-title"></div>
    <div class="input-group"><label class="input-label">Category *</label>
      <select id="artCat" class="input-field">${cats.map(c => `<option>${c}</option>`).join('')}</select>
    </div>
    <div class="input-group"><label class="input-label">Excerpt</label><textarea id="artExcerpt" class="input-field" rows="2" placeholder="Brief summary (shown in listing)"></textarea></div>
    <div class="input-group"><label class="input-label">Content (HTML allowed)</label><textarea id="artContent" class="input-field" rows="6" placeholder="Full article content..."></textarea></div>
    <div class="input-group"><label class="input-label">Tags (comma separated)</label><input id="artTags" class="input-field" placeholder="8th CPC, DA, salary"></div>
    <div style="display:flex;gap:12px;margin-bottom:16px;">
      <label style="display:flex;align-items:center;gap:6px;font-size:0.8rem;cursor:pointer;"><input type="checkbox" id="artFeatured"> Featured</label>
      <label style="display:flex;align-items:center;gap:6px;font-size:0.8rem;cursor:pointer;"><input type="checkbox" id="artTrending"> Trending</label>
    </div>
    <div style="display:flex;gap:10px;">
      <button class="btn-primary" style="flex:1;" onclick="submitArticle('published')">🚀 Publish</button>
      <button class="btn-secondary" style="flex:1;" onclick="submitArticle('draft')">💾 Save Draft</button>
    </div>
  `);
}

async function submitArticle(status = 'published') {
  const title = document.getElementById('artTitle')?.value?.trim();
  if (!title) { showToast('Title is required', 'error'); return; }
  const slug = document.getElementById('artSlug')?.value?.trim() || title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const article = {
    title,
    slug,
    category: document.getElementById('artCat')?.value || '8th CPC',
    excerpt: document.getElementById('artExcerpt')?.value || '',
    content: document.getElementById('artContent')?.value || '',
    tags: (document.getElementById('artTags')?.value || '').split(',').map(t => t.trim()).filter(Boolean),
    is_featured: document.getElementById('artFeatured')?.checked || false,
    is_trending: document.getElementById('artTrending')?.checked || false,
    status,
    views: 0,
    published_at: new Date().toISOString(),
    author_name: userProfile?.full_name || currentUser?.email || 'Admin'
  };

  try {
    if (typeof createArticle === 'function') {
      await createArticle(article);
    } else {
      const local = getLocalArticles();
      local.unshift({ ...article, id: String(Date.now()) });
      localStorage.setItem('cpc8_articles', JSON.stringify(local));
    }
    closeModal();
    showToast(`Article ${status === 'published' ? 'published' : 'saved as draft'}! ✅`, 'success');
    renderNews();
    trackEvent('article_created', { category: article.category });
  } catch (e) {
    showToast('Error saving article: ' + e.message, 'error');
  }
}

function openCreateOrderModal() {
  const depts = ['Finance Ministry', 'DoPT', 'PFRDA', 'Railway Board', 'Defence HQ', 'DGHC', 'MEA', 'Home Ministry'];
  const cats = ['Pay', 'DA', 'HRA', 'Pension', 'NPS', 'Leave', 'Promotion', 'Transfer', 'Recruitment', 'Training', 'Other'];
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 15 }, (_, i) => currentYear - i);

  openModal('📜 Upload Government Order', `
    <div class="input-group"><label class="input-label">Order Title *</label><input id="orderTitle" class="input-field" placeholder="e.g. Revision of DA to 65% w.e.f. 01.07.2026"></div>
    <div class="input-group"><label class="input-label">Order Number</label><input id="orderNum" class="input-field" placeholder="e.g. MF/PC-VII/2026/DA/01"></div>
    <div class="form-row">
      <div class="input-group"><label class="input-label">Department *</label>
        <select id="orderDept" class="input-field">${depts.map(d => `<option>${d}</option>`).join('')}<option>Other</option></select>
      </div>
      <div class="input-group"><label class="input-label">Category *</label>
        <select id="orderCat" class="input-field">${cats.map(c => `<option>${c}</option>`).join('')}</select>
      </div>
    </div>
    <div class="form-row">
      <div class="input-group"><label class="input-label">Year *</label>
        <select id="orderYear" class="input-field">${years.map(y => `<option>${y}</option>`).join('')}</select>
      </div>
    </div>
    <div class="input-group"><label class="input-label">PDF URL</label><input id="orderPDF" class="input-field" placeholder="https://...pdf or upload path"></div>
    <div class="input-group"><label class="input-label">Summary</label><textarea id="orderSummary" class="input-field" rows="3" placeholder="Brief summary of the order..."></textarea></div>
    <button class="btn-primary" style="width:100%;" onclick="submitOrder()">📤 Upload Order</button>
  `);
}

async function submitOrder() {
  const title = document.getElementById('orderTitle')?.value?.trim();
  if (!title) { showToast('Title is required', 'error'); return; }
  const order = {
    title,
    order_number: document.getElementById('orderNum')?.value || '',
    department: document.getElementById('orderDept')?.value || 'Finance Ministry',
    category: document.getElementById('orderCat')?.value || 'Pay',
    year: parseInt(document.getElementById('orderYear')?.value) || new Date().getFullYear(),
    pdf_url: document.getElementById('orderPDF')?.value || null,
    summary: document.getElementById('orderSummary')?.value || '',
    downloads: 0
  };

  try {
    if (typeof createOrder === 'function') {
      await createOrder(order);
    } else {
      const local = getLocalOrders();
      local.unshift({ ...order, id: String(Date.now()), created_at: new Date().toISOString() });
      localStorage.setItem('cpc8_orders', JSON.stringify(local));
    }
    closeModal();
    showToast('Order uploaded! ✅', 'success');
    renderOrders();
    trackEvent('order_uploaded', { category: order.category });
  } catch (e) {
    showToast('Error uploading order: ' + e.message, 'error');
  }
}

function openArticleListAdmin() {
  const articles = getLocalArticles();
  openModal('📋 Manage Articles', `
    <div style="overflow-x:auto;">
      <table class="admin-table">
        <thead><tr><th>Title</th><th>Category</th><th>Status</th><th>Views</th><th>Actions</th></tr></thead>
        <tbody>
          ${articles.map(a => `
            <tr>
              <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${a.title}</td>
              <td><span class="badge badge-saffron">${a.category}</span></td>
              <td><span class="badge ${a.status === 'published' ? 'badge-green' : 'badge-gold'}">${a.status || 'published'}</span></td>
              <td style="font-family:var(--font-mono)">${(a.views || 0).toLocaleString('en-IN')}</td>
              <td>
                <button class="btn-small" onclick="deleteArticleLocal('${a.id}')">🗑️ Delete</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `);
}

function deleteArticleLocal(id) {
  if (!confirm('Delete this article?')) return;
  const articles = getLocalArticles().filter(a => a.id !== id);
  localStorage.setItem('cpc8_articles', JSON.stringify(articles));
  renderNews();
  closeModal();
  showToast('Article deleted', 'info');
  if (typeof deleteArticle === 'function' && supabase) deleteArticle(id);
}

function openOrderListAdmin() {
  const orders = getLocalOrders();
  openModal('📂 Manage Orders', `
    <div style="overflow-x:auto;">
      <table class="admin-table">
        <thead><tr><th>Title</th><th>Dept</th><th>Year</th><th>Downloads</th><th>Actions</th></tr></thead>
        <tbody>
          ${orders.map(o => `
            <tr>
              <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${o.title}</td>
              <td>${o.department}</td>
              <td style="font-family:var(--font-mono)">${o.year}</td>
              <td style="font-family:var(--font-mono)">${o.downloads || 0}</td>
              <td><button class="btn-small" onclick="deleteOrderLocal('${o.id}')">🗑️ Delete</button></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `);
}

function deleteOrderLocal(id) {
  if (!confirm('Delete this order?')) return;
  const orders = getLocalOrders().filter(o => o.id !== id);
  localStorage.setItem('cpc8_orders', JSON.stringify(orders));
  renderOrders();
  closeModal();
  showToast('Order deleted', 'info');
}

// ============================================================
// AUTH MODAL
// ============================================================
function openAuthModal(mode = 'login') {
  const isLogin = mode === 'login';
  openModal(isLogin ? '🔐 Sign In' : '📝 Create Account', `
    ${!isLogin ? `<div class="input-group"><label class="input-label">Full Name</label><input id="authName" class="input-field" placeholder="Your full name" type="text"></div>` : ''}
    <div class="input-group"><label class="input-label">Email</label><input id="authEmail" class="input-field" placeholder="you@example.com" type="email"></div>
    <div class="input-group"><label class="input-label">Password</label><input id="authPassword" class="input-field" placeholder="${isLogin ? 'Your password' : 'Min 6 characters'}" type="password"></div>
    <button class="btn-primary" style="width:100%;margin-bottom:12px;" onclick="submitAuth('${mode}')">
      ${isLogin ? '🚀 Sign In' : '✅ Create Account'}
    </button>
    <button class="btn-secondary" style="width:100%;margin-bottom:16px;" onclick="signInWithGoogle && signInWithGoogle()">
      <svg width="16" height="16" viewBox="0 0 24 24" style="display:inline;margin-right:6px;"><path fill="#4285f4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34a853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#fbbc05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#ea4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
      Continue with Google
    </button>
    <div style="text-align:center;font-size:0.75rem;color:var(--text-muted)">
      ${isLogin
        ? `Don't have an account? <a href="#" onclick="closeModal();openAuthModal('signup')" style="color:var(--saffron)">Sign up</a>`
        : `Already have an account? <a href="#" onclick="closeModal();openAuthModal('login')" style="color:var(--saffron)">Sign in</a>`
      }
    </div>
  `);
}

async function submitAuth(mode) {
  const email = document.getElementById('authEmail')?.value?.trim();
  const password = document.getElementById('authPassword')?.value;
  const name = document.getElementById('authName')?.value?.trim();
  if (!email || !password) { showToast('Email and password required', 'error'); return; }

  try {
    if (mode === 'login') {
      await signInWithEmail(email, password);
      closeModal();
      showToast('Welcome back! 👋', 'success');
      showConfetti();
    } else {
      await signUpWithEmail(email, password, name);
      closeModal();
      showToast('Account created! Check your email. 📧', 'success');
    }
  } catch (e) {
    if (!supabase) {
      // Demo mode — simulate login
      currentUser = { id: 'demo', email };
      userProfile = { role: 'admin', full_name: name || email };
      updateAuthUI(true);
      closeModal();
      showToast('Demo mode: Logged in ✅', 'success');
    } else {
      showToast('Auth error: ' + e.message, 'error');
    }
  }
}

// ============================================================
// NEWSLETTER SUBSCRIPTION
// ============================================================
async function handleSubscribe() {
  const email = document.getElementById('subscribeEmail')?.value?.trim();
  const name = document.getElementById('subscribeName')?.value?.trim();
  if (!email || !email.includes('@')) { showToast('Valid email required', 'error'); return; }
  try {
    await subscribeNewsletter(email, name);
    showToast('Subscribed successfully! 🎉', 'success');
    if (document.getElementById('subscribeEmail')) document.getElementById('subscribeEmail').value = '';
    trackEvent('newsletter_subscribed');
  } catch (e) {
    showToast(e.message === 'Already subscribed' ? 'Already subscribed! ✅' : 'Subscription failed. Try again.', e.message === 'Already subscribed' ? 'info' : 'error');
  }
}

// ============================================================
// UTILITIES
// ============================================================
function sanitizeText(str) {
  if (!str) return '';
  return str.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function getTimeAgo(dateStr) {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  const now = new Date();
  const diff = Math.floor((now - date) / 1000);
  if (diff < 60) return 'Just now';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}

// Initialize on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  renderNews();
  renderOrders();
});
