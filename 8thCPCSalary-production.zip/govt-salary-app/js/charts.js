/**
 * charts.js — Interactive Charts using Chart.js
 */

let chartsInitialized = {};

function initCharts() {
  if (typeof Chart === 'undefined') {
    // Retry after library loads
    setTimeout(initCharts, 500);
    return;
  }
  Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
  Chart.defaults.color = getComputedStyle(document.documentElement).getPropertyValue('--text-muted').trim() || '#7A8AAA';
  Chart.defaults.borderColor = getComputedStyle(document.documentElement).getPropertyValue('--border').trim() || '#E2E6EF';

  renderSalaryGrowthChart();
  renderDAHistoryChart();
  renderNPSGrowthChart();
  renderRetirementCorpusChart();
}

function getThemeColors() {
  const style = getComputedStyle(document.documentElement);
  return {
    saffron: '#E8751A',
    blue: '#002B7F',
    green: '#046A38',
    gold: '#B8860B',
    surface: style.getPropertyValue('--surface').trim() || '#FFFFFF',
    border: style.getPropertyValue('--border').trim() || '#E2E6EF',
    textMuted: style.getPropertyValue('--text-muted').trim() || '#7A8AAA',
  };
}

function destroyChart(id) {
  if (chartsInitialized[id]) {
    chartsInitialized[id].destroy();
    delete chartsInitialized[id];
  }
}

// ── Salary Growth Chart ──────────────────────────────
function renderSalaryGrowthChart() {
  const canvas = document.getElementById('salaryGrowthChart');
  if (!canvas) return;
  destroyChart('salaryGrowth');
  const colors = getThemeColors();
  const basicPay = parseFloat(document.getElementById('basicPay')?.value) || 44900;
  const currentYear = new Date().getFullYear();
  const years = [];
  const currentPays = [], projectedPays = [];
  let pay7th = basicPay;
  let pay8th = Math.round(basicPay * 2.57);

  for (let i = 0; i <= 12; i++) {
    const year = currentYear + i;
    years.push(year);
    const da7 = Math.min(62 + i * 3, 100);
    const da8 = Math.min(i > 2 ? (i - 2) * 3 : 0, 50);
    currentPays.push(Math.round(pay7th * (1 + da7 / 100) + Math.round(pay7th * 0.18)));
    projectedPays.push(Math.round(pay8th * (1 + da8 / 100) + Math.round(pay8th * 0.20)));
    pay7th = Math.round(pay7th * 1.03);
    if (i === 2) pay8th = Math.round(pay8th * 1.03);
    else if (i > 2) pay8th = Math.round(pay8th * 1.03);
  }

  chartsInitialized['salaryGrowth'] = new Chart(canvas, {
    type: 'line',
    data: {
      labels: years,
      datasets: [
        {
          label: '7th CPC (Current)',
          data: currentPays,
          borderColor: colors.blue,
          backgroundColor: 'rgba(0, 43, 127, 0.08)',
          borderWidth: 2,
          fill: true,
          tension: 0.4,
          pointRadius: 4,
          pointBackgroundColor: colors.blue,
        },
        {
          label: '8th CPC (Projected at 2.57×)',
          data: projectedPays,
          borderColor: colors.saffron,
          backgroundColor: 'rgba(232, 117, 26, 0.08)',
          borderWidth: 2.5,
          fill: true,
          tension: 0.4,
          pointRadius: 4,
          pointBackgroundColor: colors.saffron,
        }
      ]
    },
    options: {
      responsive: true,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'top', labels: { usePointStyle: true, padding: 16 } },
        tooltip: {
          callbacks: {
            label: (ctx) => `${ctx.dataset.label}: ₹${ctx.raw.toLocaleString('en-IN')}/month`
          }
        }
      },
      scales: {
        x: { grid: { color: 'rgba(226, 230, 239, 0.5)' } },
        y: {
          grid: { color: 'rgba(226, 230, 239, 0.5)' },
          ticks: { callback: (v) => v >= 100000 ? '₹' + (v / 100000).toFixed(1) + 'L' : '₹' + (v / 1000).toFixed(0) + 'K' }
        }
      }
    }
  });
}

// ── DA History Chart ──────────────────────────────────
function renderDAHistoryChart() {
  const canvas = document.getElementById('daHistoryChart');
  if (!canvas) return;
  destroyChart('daHistory');
  const colors = getThemeColors();

  const labels = DA_HISTORY_LOCAL.map(d => {
    const date = new Date(d.date);
    return date.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
  });
  const data = DA_HISTORY_LOCAL.map(d => d.da);
  const backgroundColors = data.map((da, i) =>
    i === data.length - 2 ? 'rgba(4, 106, 56, 0.8)' :
    i === data.length - 1 ? 'rgba(184, 134, 11, 0.6)' :
    'rgba(0, 43, 127, 0.7)'
  );

  chartsInitialized['daHistory'] = new Chart(canvas, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'DA Rate (%)',
        data,
        backgroundColor: backgroundColors,
        borderColor: backgroundColors.map(c => c.replace('0.7', '1').replace('0.8', '1').replace('0.6', '1')),
        borderWidth: 1,
        borderRadius: 4,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: (ctx) => `DA: ${ctx.raw}%` } }
      },
      scales: {
        x: { grid: { display: false } },
        y: {
          beginAtZero: true,
          max: 80,
          grid: { color: 'rgba(226, 230, 239, 0.5)' },
          ticks: { callback: (v) => v + '%' }
        }
      }
    }
  });
}

// ── NPS Growth Chart ──────────────────────────────────
function renderNPSGrowthChart() {
  const canvas = document.getElementById('npsGrowthChart');
  if (!canvas) return;
  destroyChart('npsGrowth');
  const colors = getThemeColors();

  const basicPay = parseFloat(document.getElementById('npsBasicPay')?.value || document.getElementById('basicPay')?.value) || 44900;
  const daAmt = Math.round(basicPay * 0.62);
  const monthlyContrib = Math.round((basicPay + daAmt) * 0.24);
  const years = Array.from({ length: 31 }, (_, i) => i);
  const corpus6 = years.map(y => monthlyContrib * ((Math.pow(1 + 0.06 / 12, y * 12) - 1) / (0.06 / 12)));
  const corpus10 = years.map(y => monthlyContrib * ((Math.pow(1 + 0.10 / 12, y * 12) - 1) / (0.10 / 12)));
  const corpus12 = years.map(y => monthlyContrib * ((Math.pow(1 + 0.12 / 12, y * 12) - 1) / (0.12 / 12)));

  chartsInitialized['npsGrowth'] = new Chart(canvas, {
    type: 'line',
    data: {
      labels: years.map(y => y + ' yrs'),
      datasets: [
        { label: '6% Return', data: corpus6, borderColor: colors.textMuted, borderWidth: 1.5, fill: false, tension: 0.4, pointRadius: 0 },
        { label: '10% Return', data: corpus10, borderColor: colors.saffron, borderWidth: 2.5, fill: true, backgroundColor: 'rgba(232, 117, 26, 0.06)', tension: 0.4, pointRadius: 0 },
        { label: '12% Return', data: corpus12, borderColor: colors.green, borderWidth: 1.5, fill: false, tension: 0.4, pointRadius: 0 }
      ]
    },
    options: {
      responsive: true,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'top', labels: { usePointStyle: true, padding: 16 } },
        tooltip: {
          callbacks: {
            label: (ctx) => {
              const val = ctx.raw;
              const label = val >= 10000000 ? `₹${(val / 10000000).toFixed(2)} Cr` : `₹${(val / 100000).toFixed(2)} L`;
              return `${ctx.dataset.label}: ${label}`;
            }
          }
        }
      },
      scales: {
        x: { grid: { display: false }, ticks: { maxTicksLimit: 8 } },
        y: {
          grid: { color: 'rgba(226, 230, 239, 0.5)' },
          ticks: {
            callback: (v) => v >= 10000000 ? '₹' + (v / 10000000).toFixed(1) + 'Cr' : '₹' + (v / 100000).toFixed(0) + 'L'
          }
        }
      }
    }
  });
}

// ── Retirement Corpus Chart ───────────────────────────
function renderRetirementCorpusChart() {
  const canvas = document.getElementById('retirementChart');
  if (!canvas) return;
  destroyChart('retirement');
  const colors = getThemeColors();

  const basicPay = parseFloat(document.getElementById('basicPay')?.value) || 44900;
  const daAmt = Math.round(basicPay * 0.62);
  const yearsLeft = 20;

  const npsCorpus = Math.round(Math.round((basicPay + daAmt) * 0.24) * ((Math.pow(1 + 0.10 / 12, yearsLeft * 12) - 1) / (0.10 / 12)));
  const gratuity = Math.min(Math.round((basicPay + daAmt) * Math.min(yearsLeft * 2 + 10, 33) / 4), 2500000);
  const leaveEncashment = Math.min(Math.round((basicPay + daAmt) / 30 * 300), 2500000);
  const pf = Math.round(basicPay * 0.12 * 12 * yearsLeft * 1.6);

  chartsInitialized['retirement'] = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels: ['NPS Corpus', 'Gratuity', 'Leave Encashment', 'Provident Fund'],
      datasets: [{
        data: [npsCorpus, gratuity, leaveEncashment, pf],
        backgroundColor: [
          'rgba(232, 117, 26, 0.85)',
          'rgba(0, 43, 127, 0.85)',
          'rgba(4, 106, 56, 0.85)',
          'rgba(184, 134, 11, 0.85)'
        ],
        borderColor: colors.surface,
        borderWidth: 3,
        hoverOffset: 8
      }]
    },
    options: {
      responsive: true,
      cutout: '65%',
      plugins: {
        legend: { position: 'bottom', labels: { usePointStyle: true, padding: 14 } },
        tooltip: {
          callbacks: {
            label: (ctx) => {
              const val = ctx.raw;
              const label = val >= 10000000 ? `₹${(val / 10000000).toFixed(2)} Cr` : `₹${(val / 100000).toFixed(2)} L`;
              const pct = ((val / (npsCorpus + gratuity + leaveEncashment + pf)) * 100).toFixed(1);
              return `${ctx.label}: ${label} (${pct}%)`;
            }
          }
        }
      }
    }
  });
}

// ── Promotion Timeline Chart ──────────────────────────
function renderPromotionChart() {
  const canvas = document.getElementById('promotionChart');
  if (!canvas) return;
  destroyChart('promotion');

  const basicPay = parseFloat(document.getElementById('basicPay')?.value) || 44900;
  const currentLevel = parseInt(document.getElementById('promCurrentLevel')?.value) || 7;
  const years = [], pays = [], levels = [];
  let pay = basicPay;
  let level = currentLevel;
  const currentYear = new Date().getFullYear();

  for (let i = 0; i <= 15; i++) {
    years.push(currentYear + i);
    pays.push(pay);
    levels.push(`L${level}`);
    pay = Math.round(pay * 1.03);
    // Simulate promotion every 5 years
    if (i > 0 && i % 5 === 0 && level < 18) {
      level++;
      const nextMatrix = PAY_MATRIX_7TH[level];
      if (nextMatrix) {
        const withIncrement = Math.round(pay * 1.03);
        for (const cellPay of nextMatrix) {
          if (cellPay >= withIncrement) { pay = cellPay; break; }
        }
      }
    }
  }

  chartsInitialized['promotion'] = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: years,
      datasets: [{
        label: 'Basic Pay',
        data: pays,
        backgroundColor: pays.map((_, i) => i > 0 && i % 5 === 0 ? 'rgba(4, 106, 56, 0.85)' : 'rgba(0, 43, 127, 0.7)'),
        borderRadius: 4,
        borderSkipped: false,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => `Basic: ₹${ctx.raw.toLocaleString('en-IN')} (${levels[ctx.dataIndex]})`,
            afterLabel: (ctx) => ctx.dataIndex > 0 && ctx.dataIndex % 5 === 0 ? '🎉 Promotion!' : ''
          }
        }
      },
      scales: {
        x: { grid: { display: false } },
        y: { ticks: { callback: v => '₹' + (v / 1000).toFixed(0) + 'K' }, grid: { color: 'rgba(226, 230, 239, 0.5)' } }
      }
    }
  });
}

// Re-render charts when dark mode changes
document.addEventListener('darkModeChanged', () => {
  setTimeout(() => {
    destroyChart('salaryGrowth');
    destroyChart('daHistory');
    destroyChart('npsGrowth');
    destroyChart('retirement');
    initCharts();
  }, 300);
});
