/**
 * utils.js — Shared utility functions
 */

// ── Input Validation ───────────────────────────────────────
function validateBasicPay(value) {
  const num = parseFloat(value);
  if (isNaN(num) || num < 18000 || num > 250000) {
    return { valid: false, message: 'Basic pay must be between ₹18,000 and ₹2,50,000' };
  }
  return { valid: true, value: num };
}

function validatePercentage(value, min = 0, max = 200) {
  const num = parseFloat(value);
  if (isNaN(num) || num < min || num > max) {
    return { valid: false, message: `Value must be between ${min}% and ${max}%` };
  }
  return { valid: true, value: num };
}

function validateYears(value, min = 1, max = 40) {
  const num = parseInt(value);
  if (isNaN(num) || num < min || num > max) {
    return { valid: false, message: `Years must be between ${min} and ${max}` };
  }
  return { valid: true, value: num };
}

// ── Number Formatting ──────────────────────────────────────
function formatIndianNumber(num) {
  if (!num && num !== 0) return '0';
  const n = Math.round(Math.abs(num));
  const sign = num < 0 ? '-' : '';
  const s = n.toString();
  if (s.length <= 3) return sign + s;
  const last3 = s.slice(-3);
  const rest = s.slice(0, -3);
  const formatted = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + last3;
  return sign + formatted;
}

function formatShortCurrency(amount) {
  const n = Math.abs(Math.round(amount));
  const sign = amount < 0 ? '-₹' : '₹';
  if (n >= 10000000) return sign + (n / 10000000).toFixed(2) + 'Cr';
  if (n >= 100000)   return sign + (n / 100000).toFixed(2) + 'L';
  if (n >= 1000)     return sign + (n / 1000).toFixed(1) + 'K';
  return sign + n;
}

// ── Date Utilities ─────────────────────────────────────────
function getFinancialYear(date = new Date()) {
  const month = date.getMonth();
  const year = date.getFullYear();
  return month >= 3
    ? `${year}-${(year + 1).toString().slice(-2)}`
    : `${year - 1}-${year.toString().slice(-2)}`;
}

function getNextDADate() {
  const now = new Date();
  const month = now.getMonth();
  const year = now.getFullYear();
  // DA released Jan and Jul
  if (month < 6) return new Date(year, 6, 1); // Jul 1
  return new Date(year + 1, 0, 1); // Jan 1 next year
}

function getDaysUntilRetirement(dob) {
  const birth = new Date(dob);
  const retirement = new Date(birth.getFullYear() + 60, birth.getMonth(), 1);
  const diff = retirement - new Date();
  return Math.max(0, Math.floor(diff / (1000 * 60 * 60 * 24)));
}

// ── Pay Matrix Utilities ───────────────────────────────────
function getPayLevelForBasic(basicPay) {
  for (let level = 1; level <= 18; level++) {
    const matrix = PAY_MATRIX_7TH?.[level];
    if (!matrix) continue;
    if (basicPay >= matrix[0] && basicPay <= matrix[matrix.length - 1]) {
      return level;
    }
  }
  return null;
}

function getNextCellInMatrix(level, currentBasic) {
  const matrix = PAY_MATRIX_7TH?.[level];
  if (!matrix) return currentBasic;
  const withIncrement = Math.round(currentBasic * 1.03);
  for (const pay of matrix) {
    if (pay >= withIncrement) return pay;
  }
  return matrix[matrix.length - 1];
}

function getAnnualIncrement(basicPay, level) {
  const nextCell = getNextCellInMatrix(level, basicPay);
  return nextCell - basicPay;
}

// ── Tax Calculations ───────────────────────────────────────
function calculateIncomeTax(annualIncome, regime = 'new') {
  // New Tax Regime FY 2026-27
  const newSlabs = [
    { limit: 400000, rate: 0 },
    { limit: 800000, rate: 0.05 },
    { limit: 1200000, rate: 0.10 },
    { limit: 1600000, rate: 0.15 },
    { limit: 2000000, rate: 0.20 },
    { limit: 2400000, rate: 0.25 },
    { limit: Infinity, rate: 0.30 }
  ];

  // Old Tax Regime
  const oldSlabs = [
    { limit: 250000, rate: 0 },
    { limit: 500000, rate: 0.05 },
    { limit: 1000000, rate: 0.20 },
    { limit: Infinity, rate: 0.30 }
  ];

  const slabs = regime === 'new' ? newSlabs : oldSlabs;
  let tax = 0;
  let prev = 0;

  for (const slab of slabs) {
    if (annualIncome <= prev) break;
    const taxable = Math.min(annualIncome, slab.limit) - prev;
    tax += taxable * slab.rate;
    prev = slab.limit;
    if (slab.limit === Infinity) break;
  }

  // Rebate under Section 87A (new regime: up to ₹7L)
  if (regime === 'new' && annualIncome <= 700000) tax = 0;
  if (regime === 'old' && annualIncome <= 500000) tax = 0;

  const cess = tax * 0.04; // 4% health & education cess
  return Math.round(tax + cess);
}

// ── Clipboard & Share ──────────────────────────────────────
async function copyToClipboard(text, successMsg = 'Copied!') {
  try {
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(text);
    } else {
      const el = document.createElement('textarea');
      el.value = text;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
    }
    showToast(successMsg, 'success');
    return true;
  } catch {
    showToast('Copy failed. Please copy manually.', 'error');
    return false;
  }
}

// ── Local Storage Helpers ──────────────────────────────────
const Storage = {
  get(key, fallback = null) {
    try {
      const val = localStorage.getItem(key);
      return val ? JSON.parse(val) : fallback;
    } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch { return false; }
  },
  remove(key) {
    try { localStorage.removeItem(key); return true; }
    catch { return false; }
  },
  clear(prefix) {
    try {
      Object.keys(localStorage).filter(k => k.startsWith(prefix)).forEach(k => localStorage.removeItem(k));
      return true;
    } catch { return false; }
  }
};

// ── Debounce ───────────────────────────────────────────────
function debounce(fn, delay = 300) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// ── Throttle ──────────────────────────────────────────────
function throttle(fn, limit = 200) {
  let lastRun = 0;
  return (...args) => {
    const now = Date.now();
    if (now - lastRun >= limit) { lastRun = now; fn(...args); }
  };
}

// ── Print ──────────────────────────────────────────────────
function printSection(sectionId) {
  const section = document.getElementById(sectionId);
  if (!section) return;
  const html = `
    <!DOCTYPE html><html><head>
    <title>8thCPCSalary.com — Print</title>
    <meta charset="UTF-8">
    <style>
      body{font-family:'Plus Jakarta Sans',sans-serif;padding:20px;color:#333}
      h2{color:#002B7F;border-bottom:2px solid #E8751A;padding-bottom:8px}
      table{width:100%;border-collapse:collapse;font-size:12px}
      th{background:#002B7F;color:white;padding:8px}
      td{padding:8px;border:1px solid #ddd}
      .footer{margin-top:20px;font-size:10px;color:#999;text-align:center}
    </style></head><body>
    <h2>🏛️ 8thCPCSalary.com</h2>
    ${section.outerHTML}
    <div class="footer">Generated on ${new Date().toLocaleString('en-IN')} | 8thCPCSalary.com</div>
    </body></html>
  `;
  const win = window.open('', '_blank');
  win.document.write(html);
  win.document.close();
  win.print();
  win.close();
}

// ── URL Params ────────────────────────────────────────────
function getQueryParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

function setQueryParams(params) {
  const url = new URL(window.location.href);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== null && v !== undefined) url.searchParams.set(k, v);
    else url.searchParams.delete(k);
  });
  window.history.replaceState({}, '', url.toString());
}

// ── Auto-fill from URL params on load ─────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const basic = getQueryParam('basic');
  const da = getQueryParam('da');
  const city = getQueryParam('city');
  const ff = getQueryParam('ff');

  if (basic) { const el = document.getElementById('basicPay'); if (el) el.value = basic; }
  if (da) { const el = document.getElementById('daPercent'); if (el) el.value = da; }
  if (city) { const el = document.getElementById('hraCity'); if (el) el.value = city; }
  if (ff) {
    const el = document.getElementById('fitmentSlider');
    const val = document.getElementById('fitmentValue');
    if (el) el.value = ff;
    if (val) val.textContent = parseFloat(ff).toFixed(2) + '×';
  }
});

// ── Debounced inputs ──────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const debouncedCalc = debounce(() => {
    if (typeof calculateSalary === 'function') calculateSalary();
  }, 400);
  document.getElementById('basicPay')?.addEventListener('input', debouncedCalc);
  document.getElementById('daPercent')?.addEventListener('input', debouncedCalc);
});
