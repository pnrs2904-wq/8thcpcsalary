import type { MetadataRoute } from "next";
import { payMatrix } from "@/lib/salary";
import { site } from "@/data/platform";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const staticRoutes = ["", "/calculators/8th-cpc-salary", "/dashboard", "/about-us", "/contact", "/privacy-policy", "/terms-and-conditions", "/editorial-policy", "/disclaimer"];
  const levelRoutes = Object.keys(payMatrix).map((level) => `/salary/level/${level}`);

  return [...staticRoutes, ...levelRoutes].map((route) => ({
    url: `${site.url}${route}`,
    lastModified: now,
    changeFrequency: route.includes("/salary/level") ? "weekly" : "daily",
    priority: route === "" ? 1 : route.includes("/calculators") ? 0.9 : 0.7,
  }));
}
