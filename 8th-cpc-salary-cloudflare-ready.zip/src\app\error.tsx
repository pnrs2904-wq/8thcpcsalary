"use client";

export default function Error({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="container-shell grid min-h-[60vh] place-items-center py-10">
      <div className="card max-w-xl p-8 text-center">
        <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Error</p>
        <h1 className="mt-2 text-3xl font-black">Something went wrong</h1>
        <p className="mt-3 text-slate-600">Please retry the calculation or reload the page.</p>
        <button onClick={reset} className="mt-6 rounded-full bg-[var(--india-blue)] px-5 py-3 font-black text-white">
          Try again
        </button>
      </div>
    </main>
  );
}
