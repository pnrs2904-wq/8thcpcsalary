import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

export default function PrivacyPolicyPage() {
  return <Policy title="Privacy Policy" body="We collect only the information required to provide saved calculations, account features and premium services. Salary calculator inputs can remain local unless a user chooses to save them. We do not sell personal salary data." />;
}

function Policy({ title, body }: { title: string; body: string }) {
  return (
    <>
      <Header />
      <main className="container-shell py-10">
        <article className="card p-6">
          <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Legal</p>
          <h1 className="mt-2 text-4xl font-black">{title}</h1>
          <p className="mt-5 max-w-3xl text-lg leading-8 text-slate-700">{body}</p>
          <p className="mt-5 text-sm font-semibold text-slate-500">Last updated: May 27, 2026</p>
        </article>
      </main>
      <Footer />
    </>
  );
}
