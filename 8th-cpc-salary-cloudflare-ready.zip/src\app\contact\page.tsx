import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

export default function ContactPage() {
  return (
    <>
      <Header />
      <main className="container-shell py-10">
        <article className="card p-6">
          <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Contact</p>
          <h1 className="mt-2 text-4xl font-black">Contact 8thCPCSalary.com</h1>
          <p className="mt-5 max-w-3xl text-lg leading-8 text-slate-700">
            For editorial corrections, calculator feedback, partnership requests or support, contact the platform team at
            support@8thcpcsalary.com.
          </p>
          <p className="mt-5 text-sm font-semibold text-slate-500">Last updated: May 27, 2026</p>
        </article>
      </main>
      <Footer />
    </>
  );
}
