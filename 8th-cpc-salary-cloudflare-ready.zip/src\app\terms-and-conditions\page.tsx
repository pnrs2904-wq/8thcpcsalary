import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

export default function TermsPage() {
  return (
    <>
      <Header />
      <main className="container-shell py-10">
        <article className="card p-6">
          <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Legal</p>
          <h1 className="mt-2 text-4xl font-black">Terms & Conditions</h1>
          <p className="mt-5 max-w-3xl text-lg leading-8 text-slate-700">
            The platform provides informational tools and projections. Users should verify official pay, pension, DA and tax
            rules with government notifications, department circulars and qualified financial professionals.
          </p>
          <p className="mt-5 text-sm font-semibold text-slate-500">Last updated: May 27, 2026</p>
        </article>
      </main>
      <Footer />
    </>
  );
}
