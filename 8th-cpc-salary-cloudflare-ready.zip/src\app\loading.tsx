export default function Loading() {
  return (
    <div className="container-shell py-10">
      <div className="grid gap-4 md:grid-cols-3">
        {[1, 2, 3].map((item) => (
          <div key={item} className="h-36 animate-pulse rounded-lg bg-slate-200" />
        ))}
      </div>
    </div>
  );
}
