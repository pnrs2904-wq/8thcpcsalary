"use client";

import { useMemo, useState } from "react";
import { ArrowUpRight, Download, MessageCircle, RotateCcw, Send, ShieldCheck } from "lucide-react";
import {
  calculateSalary,
  defaultSalaryInput,
  formatINR,
  hraRates,
  payMatrix,
  type HraClass,
  type SalaryInput,
  type TaxRegime,
} from "@/lib/salary";

const rows = [
  ["Basic Pay", "basic"],
  ["Dearness Allowance", "da"],
  ["House Rent Allowance", "hra"],
  ["Transport Allowance", "ta"],
  ["Gross Pay", "gross"],
  ["NPS Deduction", "nps"],
  ["Monthly Tax", "taxMonthly"],
  ["Other Deductions", "otherDeductions"],
  ["In-Hand Pay", "net"],
] as const;

export function SalaryCalculator({ compact = false }: { compact?: boolean }) {
  const [input, setInput] = useState<SalaryInput>(defaultSalaryInput);
  const result = useMemo(() => calculateSalary(input), [input]);

  const update = <K extends keyof SalaryInput>(key: K, value: SalaryInput[K]) => {
    setInput((current) => ({ ...current, [key]: value }));
  };

  const shareText = `8th CPC salary projection: ${formatINR(result.old.net)}/mo to ${formatINR(
    result.projected.net,
  )}/mo. Monthly increase ${formatINR(result.monthlyIncrease)}.`;

  return (
    <section id="calculator" className="container-shell py-8">
      <div className="mb-5 flex flex-col justify-between gap-3 md:flex-row md:items-end">
        <div>
          <p className="text-sm font-bold uppercase tracking-[0.16em] text-[var(--saffron)]">Salary Calculator Ecosystem</p>
          <h2 className="mt-2 text-2xl font-black tracking-tight md:text-3xl">8th CPC salary projection engine</h2>
        </div>
        <div className="ad-slot w-full md:w-80">Advertisement</div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[0.92fr_1.08fr]">
        <div className="card p-5">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <h3 className="font-black">Your Pay Details</h3>
              <p className="text-sm text-[var(--muted)]">Validated inputs with bounded salary assumptions.</p>
            </div>
            <button
              className="focus-ring inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-2 text-sm font-bold"
              onClick={() => setInput(defaultSalaryInput)}
            >
              <RotateCcw size={15} />
              Reset
            </button>
          </div>

          <div className="grid gap-4">
            <Field label="7th CPC Pay Level">
              <select
                value={result.level}
                onChange={(event) => update("currentBasic", payMatrix[Number(event.target.value)] ?? input.currentBasic)}
                className="input"
              >
                {Object.entries(payMatrix).map(([level, basic]) => (
                  <option key={level} value={level}>
                    Level {level} - {formatINR(basic)}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Current Basic Pay">
              <input
                className="input"
                type="number"
                min={18000}
                max={250000}
                value={input.currentBasic}
                onChange={(event) => update("currentBasic", Number(event.target.value))}
              />
            </Field>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Current DA %">
                <input
                  className="input"
                  type="number"
                  min={0}
                  max={200}
                  value={input.daPercent}
                  onChange={(event) => update("daPercent", Number(event.target.value))}
                />
              </Field>
              <Field label="HRA City Class">
                <select className="input" value={input.hraClass} onChange={(event) => update("hraClass", event.target.value as HraClass)}>
                  {(["X", "Y", "Z"] as HraClass[]).map((item) => (
                    <option key={item} value={item}>
                      {item} City ({Math.round(hraRates[item] * 100)}%)
                    </option>
                  ))}
                </select>
              </Field>
            </div>

            <Field label={`Expected Fitment Factor: ${input.fitmentFactor.toFixed(2)}x`}>
              <input
                type="range"
                min={1.92}
                max={3.83}
                step={0.01}
                value={input.fitmentFactor}
                onChange={(event) => update("fitmentFactor", Number(event.target.value))}
                className="w-full accent-[var(--saffron)]"
              />
              <div className="mt-2 grid grid-cols-3 text-xs font-semibold text-[var(--muted)]">
                <span>1.92x</span>
                <span className="text-center">2.57x</span>
                <span className="text-right">3.83x</span>
              </div>
            </Field>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="NPS Deduction %">
                <input
                  className="input"
                  type="number"
                  min={0}
                  max={20}
                  value={input.npsPercent}
                  onChange={(event) => update("npsPercent", Number(event.target.value))}
                />
              </Field>
              <Field label="8th CPC DA %">
                <input
                  className="input"
                  type="number"
                  min={0}
                  max={100}
                  value={input.eighthCpcDaPercent}
                  onChange={(event) => update("eighthCpcDaPercent", Number(event.target.value))}
                />
              </Field>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Tax Regime">
                <select className="input" value={input.taxRegime} onChange={(event) => update("taxRegime", event.target.value as TaxRegime)}>
                  <option value="new">New Regime</option>
                  <option value="old">Old Regime</option>
                </select>
              </Field>
              <Field label="Annual Extra Deductions">
                <input
                  className="input"
                  type="number"
                  min={0}
                  value={input.extraDeductionsAnnual}
                  onChange={(event) => update("extraDeductionsAnnual", Number(event.target.value))}
                />
              </Field>
            </div>

            <label className="flex items-center justify-between gap-4 rounded-lg border border-slate-200 bg-slate-50 p-4">
              <span>
                <span className="block text-sm font-black">Conservative fitment method</span>
                <span className="text-xs text-[var(--muted)]">Use Basic x Fitment instead of (Basic + DA) x Fitment.</span>
              </span>
              <input
                type="checkbox"
                checked={input.useBasicOnlyFitment}
                onChange={(event) => update("useBasicOnlyFitment", event.target.checked)}
                className="h-5 w-5 accent-[var(--india-blue)]"
              />
            </label>
          </div>
        </div>

        <div className="card overflow-hidden">
          <div className="bg-[#071d49] p-5 text-white">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.16em] text-orange-200">Estimated 8th CPC In-Hand</p>
                <div className="metric-value mt-2 text-4xl font-black md:text-5xl">{formatINR(result.projected.net)}</div>
                <p className="mt-2 text-sm text-blue-100">
                  Current 7th CPC in-hand: <strong>{formatINR(result.old.net)}</strong>
                </p>
              </div>
              <div className="rounded-lg bg-white/10 px-3 py-2 text-right">
                <div className="text-xs text-blue-100">Monthly boost</div>
                <div className="metric-value text-xl font-black text-[#8ff0b6]">{formatINR(result.monthlyIncrease)}</div>
              </div>
            </div>
            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              <MiniMetric label="Annual gain" value={formatINR(result.annualIncrease)} />
              <MiniMetric label="Pay level" value={`Level ${result.level}`} />
              <MiniMetric label="Gross pay" value={formatINR(result.projected.gross)} />
            </div>
          </div>

          <div className="p-5">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[620px] text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-[0.12em] text-[var(--muted)]">
                    <th className="py-3">Component</th>
                    <th className="py-3">7th CPC</th>
                    <th className="py-3">8th CPC</th>
                    <th className="py-3">Change</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map(([label, key]) => {
                    const oldValue = result.old[key];
                    const newValue = result.projected[key];
                    const diff = newValue - oldValue;
                    const highlight = key === "gross" || key === "net";
                    return (
                      <tr key={key} className={`border-b border-slate-100 ${highlight ? "font-black" : ""}`}>
                        <td className="py-3">{label}</td>
                        <td className="metric-value py-3">{formatINR(oldValue)}</td>
                        <td className="metric-value py-3 text-[var(--saffron)]">{formatINR(newValue)}</td>
                        <td className={`metric-value py-3 ${diff >= 0 ? "text-[var(--green)]" : "text-[var(--danger)]"}`}>
                          {diff >= 0 ? "+" : ""}
                          {formatINR(diff)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {!compact && (
              <div className="mt-5 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-950">
                <div className="flex gap-2 font-black">
                  <ShieldCheck size={18} />
                  Assumptions
                </div>
                <ul className="mt-2 grid gap-1">
                  {result.assumptions.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mt-5 flex flex-wrap gap-3">
              <ShareLink
                href={`https://wa.me/?text=${encodeURIComponent(shareText)}`}
                label="WhatsApp"
                icon={<MessageCircle size={16} />}
                tone="green"
              />
              <ShareLink
                href={`https://t.me/share/url?url=https://8thcpcsalary.com&text=${encodeURIComponent(shareText)}`}
                label="Telegram"
                icon={<Send size={16} />}
                tone="blue"
              />
              <button className="focus-ring inline-flex items-center gap-2 rounded-full border border-slate-200 px-4 py-2 text-sm font-black">
                <Download size={16} />
                PDF Report
              </button>
              <a href="/dashboard" className="focus-ring inline-flex items-center gap-2 rounded-full bg-[var(--india-blue)] px-4 py-2 text-sm font-black text-white">
                Save to Dashboard
                <ArrowUpRight size={16} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black text-slate-800">{label}</span>
      {children}
    </label>
  );
}

function MiniMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-white/10 bg-white/10 p-3">
      <div className="text-xs text-blue-100">{label}</div>
      <div className="metric-value mt-1 text-lg font-black">{value}</div>
    </div>
  );
}

function ShareLink({ href, label, icon, tone }: { href: string; label: string; icon: React.ReactNode; tone: "green" | "blue" }) {
  const className =
    tone === "green"
      ? "bg-[var(--green)] text-white"
      : "bg-[var(--india-blue)] text-white";

  return (
    <a href={href} target="_blank" rel="noreferrer" className={`focus-ring inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-black ${className}`}>
      {icon}
      {label}
    </a>
  );
}
