import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { calculateSalary, defaultSalaryInput, formatINR, payMatrix } from "@/lib/salary";

type Props = {
  params: Promise<{ level: string }>;
};

export function generateStaticParams() {
  return Object.keys(payMatrix).map((level) => ({ level }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { level } = await params;
  const numericLevel = Number(level);
  if (!payMatrix[numericLevel]) return {};

  return {
    title: `Pay Level ${numericLevel} Salary After 8th CPC`,
    description: `Expected 8th CPC salary, DA, HRA, tax and pension planning guide for Pay Level ${numericLevel} government employees.`,
    alternates: { canonical: `/salary/level/${numericLevel}` },
  };
}

export default async function PayLevelPage({ params }: Props) {
  const { level } = await params;
  const numericLevel = Number(level);
  const basic = payMatrix[numericLevel];
  if (!basic) notFound();

  const projection = calculateSalary({ ...defaultSalaryInput, currentBasic: basic });

  const faq = [
    {
      question: `What is the basic pay for Level ${numericLevel}?`,
      answer: `The entry basic pay used for Level ${numericLevel} is ${formatINR(basic)} as per the 7th CPC matrix baseline.`,
    },
    {
      question: `What is the expected 8th CPC salary for Level ${numericLevel}?`,
      answer: `Using the default 2.57x projection, estimated in-hand pay is ${formatINR(projection.projected.net)} per month.`,
    },
  ];

  const schema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faq.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: { "@type": "Answer", text: item.answer },
    })),
  };

  return (
    <>
      <Header />
      <main className="container-shell py-8">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
        <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Programmatic Salary Page</p>
        <h1 className="mt-2 text-4xl font-black tracking-tight text-[#071d49]">Pay Level {numericLevel} salary after 8th CPC</h1>
        <p className="mt-3 max-w-3xl text-lg leading-8 text-slate-600">
          This SEO-first salary page explains the projected 8th CPC salary for Pay Level {numericLevel}, including basic pay,
          DA, HRA, tax impact and in-hand salary assumptions.
        </p>

        <div className="mt-7 grid gap-5 md:grid-cols-4">
          <Metric label="7th CPC Basic" value={formatINR(basic)} />
          <Metric label="Projected Basic" value={formatINR(projection.projected.basic)} />
          <Metric label="Projected Gross" value={formatINR(projection.projected.gross)} />
          <Metric label="Projected In-Hand" value={formatINR(projection.projected.net)} />
        </div>

        <article className="card mt-6 p-6 text-slate-700">
          <h2 className="text-2xl font-black text-[#071d49]">Level {numericLevel} 8th Pay Commission analysis</h2>
          <p className="mt-4 leading-8">
            Employees in Pay Level {numericLevel} can use this page as a planning reference for salary negotiations,
            retirement planning and tax forecasting. The projection is based on current basic pay, 62% DA, Y-city HRA and a
            2.57x fitment factor by default.
          </p>
          <div className="ad-slot mt-6">Advertisement</div>
          <h3 className="mt-6 text-xl font-black text-[#071d49]">Frequently asked questions</h3>
          <div className="mt-4 grid gap-4">
            {faq.map((item) => (
              <div key={item.question} className="rounded-lg border border-slate-200 bg-slate-50 p-4">
                <h4 className="font-black">{item.question}</h4>
                <p className="mt-2 leading-7">{item.answer}</p>
              </div>
            ))}
          </div>
        </article>
      </main>
      <Footer />
    </>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="card p-5">
      <div className="text-xs font-black uppercase tracking-[0.12em] text-[var(--muted)]">{label}</div>
      <div className="metric-value mt-3 text-2xl font-black text-[#071d49]">{value}</div>
    </div>
  );
}
