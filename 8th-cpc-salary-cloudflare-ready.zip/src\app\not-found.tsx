import Link from "next/link";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

export default function NotFound() {
  return (
    <>
      <Header />
      <main className="container-shell grid min-h-[54vh] place-items-center py-10">
        <div className="card max-w-xl p-8 text-center">
          <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">404</p>
          <h1 className="mt-2 text-3xl font-black">Page not found</h1>
          <p className="mt-3 text-slate-600">The salary resource you opened is not available yet.</p>
          <Link href="/" className="mt-6 inline-flex rounded-full bg-[var(--india-blue)] px-5 py-3 font-black text-white">
            Go home
          </Link>
        </div>
      </main>
      <Footer />
    </>
  );
}
