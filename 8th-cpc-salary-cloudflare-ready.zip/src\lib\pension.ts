import { formatINR } from "@/lib/salary";

export type PensionInput = {
  basic: number;
  daPercent: number;
  yearsOfService: number;
  npsCagr: number;
};

export function calculatePension(input: PensionInput) {
  const lastPay = input.basic * (1 + input.daPercent / 100);
  const opsMonthly = lastPay * 0.5;
  const gratuity = Math.min(lastPay * (input.yearsOfService / 2) * (15 / 12), 2000000);
  const monthlyContribution = lastPay * 0.24;
  const monthlyRate = input.npsCagr / 100 / 12;
  const months = input.yearsOfService * 12;
  const corpus =
    monthlyRate > 0
      ? monthlyContribution * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate)
      : monthlyContribution * months;
  const annuityCorpus = corpus * 0.4;
  const lumpSum = corpus * 0.6;
  const annuityMonthly = (annuityCorpus * 0.06) / 12;

  return {
    lastPay,
    opsMonthly,
    gratuity,
    corpus,
    annuityCorpus,
    lumpSum,
    annuityMonthly,
    summary: `OPS ${formatINR(opsMonthly)}/mo vs estimated NPS annuity ${formatINR(annuityMonthly)}/mo`,
  };
}
