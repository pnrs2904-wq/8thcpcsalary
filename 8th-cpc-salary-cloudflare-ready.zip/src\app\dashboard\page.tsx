import type { Metadata } from "next";
import { Bell, Download, FileText, LineChart, Lock, UserRound } from "lucide-react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { dashboardCards } from "@/data/platform";

export const metadata: Metadata = {
  title: "Salary Dashboard",
  description: "Authenticated dashboard concept for saved calculations, salary history, DA alerts and pension projections.",
};

export default function DashboardPage() {
  return (
    <>
      <Header />
      <main className="container-shell py-8">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Fintech SaaS Dashboard</p>
            <h1 className="mt-2 text-4xl font-black tracking-tight text-[#071d49]">Your government salary command center</h1>
          </div>
          <button className="focus-ring inline-flex items-center gap-2 rounded-full bg-[var(--india-blue)] px-5 py-3 font-black text-white">
            <Lock size={17} />
            Connect Auth.js
          </button>
        </div>

        <div className="mt-7 grid gap-4 md:grid-cols-4">
          {dashboardCards.map((card) => (
            <div key={card.label} className="card p-5">
              <card.icon size={20} className="text-[var(--india-blue)]" />
              <div className="metric-value mt-4 text-3xl font-black">{card.value}</div>
              <div className="mt-1 text-sm font-bold text-slate-700">{card.label}</div>
              <div className="mt-2 text-xs font-semibold text-[var(--green)]">{card.delta}</div>
            </div>
          ))}
        </div>

        <div className="mt-6 grid gap-5 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="card p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-black">Salary trend visualization</h2>
              <LineChart size={22} className="text-[var(--india-blue)]" />
            </div>
            <div className="mt-6 flex h-72 items-end gap-3 rounded-lg bg-slate-50 p-4">
              {[42, 48, 52, 58, 66, 74, 82, 90].map((height, index) => (
                <div key={height} className="flex flex-1 flex-col items-center gap-2">
                  <div className="w-full rounded-t-md bg-gradient-to-t from-[var(--india-blue)] to-[var(--saffron)]" style={{ height: `${height}%` }} />
                  <span className="text-xs font-bold text-slate-500">{2020 + index}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-5">
            <Widget icon={<Bell size={20} />} title="Notification Center" items={["DA July 2026 projection ready", "Pension revision scenario updated", "Tax regime comparison available"]} />
            <Widget icon={<Download size={20} />} title="Downloadable Reports" items={["8th CPC salary summary", "Retirement corpus projection", "Pay level comparison card"]} />
          </div>
        </div>

        <div className="mt-6 card overflow-hidden">
          <div className="border-b border-slate-200 p-5">
            <h2 className="text-xl font-black">Recent calculations</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-[0.12em] text-slate-500">
                <tr>
                  <th className="px-5 py-3">Profile</th>
                  <th className="px-5 py-3">Level</th>
                  <th className="px-5 py-3">Current Net</th>
                  <th className="px-5 py-3">Projected Net</th>
                  <th className="px-5 py-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {["Railway JE", "Defence NCO", "Teacher PGT", "IAS Deputy Secretary"].map((profile, index) => (
                  <tr key={profile} className="border-t border-slate-100">
                    <td className="px-5 py-4 font-bold"><UserRound size={16} className="mr-2 inline" />{profile}</td>
                    <td className="px-5 py-4">Level {index + 6}</td>
                    <td className="metric-value px-5 py-4">₹{["54,200", "67,100", "72,900", "1,78,400"][index]}</td>
                    <td className="metric-value px-5 py-4 text-[var(--saffron)]">₹{["82,300", "1,02,400", "1,11,900", "2,72,600"][index]}</td>
                    <td className="px-5 py-4"><span className="rounded-full bg-green-50 px-3 py-1 text-xs font-black text-[var(--green)]">Saved</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}

function Widget({ icon, title, items }: { icon: React.ReactNode; title: string; items: string[] }) {
  return (
    <div className="card p-5">
      <div className="flex items-center gap-2 text-lg font-black">
        <span className="text-[var(--india-blue)]">{icon}</span>
        {title}
      </div>
      <div className="mt-4 grid gap-3">
        {items.map((item) => (
          <div key={item} className="flex items-center gap-3 rounded-lg bg-slate-50 p-3 text-sm font-semibold">
            <FileText size={16} className="text-slate-500" />
            {item}
          </div>
        ))}
      </div>
    </div>
  );
}
