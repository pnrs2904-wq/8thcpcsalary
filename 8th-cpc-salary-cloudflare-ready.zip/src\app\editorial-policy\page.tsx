import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

export default function EditorialPolicyPage() {
  return (
    <>
      <Header />
      <main className="container-shell py-10">
        <article className="card p-6">
          <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Editorial Policy</p>
          <h1 className="mt-2 text-4xl font-black">Editorial Policy</h1>
          <p className="mt-5 max-w-3xl text-lg leading-8 text-slate-700">
            We explain salary and pension topics using clear assumptions, dated updates and source-aware editorial review. Any
            projection is labeled as an estimate until an official circular confirms the rule.
          </p>
          <p className="mt-5 text-sm font-semibold text-slate-500">Last updated: May 27, 2026</p>
        </article>
      </main>
      <Footer />
    </>
  );
}
