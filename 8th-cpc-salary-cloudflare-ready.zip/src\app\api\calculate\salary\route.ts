import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { calculateSalary } from "@/lib/salary";

const salaryInputSchema = z.object({
  currentBasic: z.number().min(18000).max(250000),
  daPercent: z.number().min(0).max(200),
  hraClass: z.enum(["X", "Y", "Z"]),
  fitmentFactor: z.number().min(1.92).max(3.83),
  npsPercent: z.number().min(0).max(20),
  taxRegime: z.enum(["new", "old"]),
  extraDeductionsAnnual: z.number().min(0),
  miscDeductionsMonthly: z.number().min(0),
  useBasicOnlyFitment: z.boolean(),
  eighthCpcDaPercent: z.number().min(0).max(100),
});

export async function POST(request: NextRequest) {
  const payload: unknown = await request.json();
  const parsed = salaryInputSchema.safeParse(payload);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid salary input", issues: parsed.error.flatten() },
      { status: 400 },
    );
  }

  return NextResponse.json({ result: calculateSalary(parsed.data) });
}
