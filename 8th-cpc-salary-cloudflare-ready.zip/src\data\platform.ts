import {
  Bell,
  Calculator,
  CircleDollarSign,
  FileText,
  Landmark,
  LineChart,
  Lock,
  PiggyBank,
  ReceiptText,
  ShieldCheck,
  TrendingUp,
  Users,
} from "lucide-react";

export const site = {
  name: "8thCPCSalary.com",
  title: "India's Most Advanced Government Salary & Pension Platform",
  description:
    "8th Pay Commission salary, pension, DA, tax and retirement planning tools for Indian government employees.",
  url: "https://8thcpcsalary.com",
};

export const toolModules = [
  {
    title: "8th CPC Salary Calculator",
    description: "Compare 7th CPC and projected 8th CPC in-hand pay with DA, HRA, TA, NPS and tax.",
    icon: Calculator,
    href: "/calculators/8th-cpc-salary",
  },
  {
    title: "Pension & NPS Planner",
    description: "Estimate OPS pension, NPS corpus, commutation, gratuity and retirement payouts.",
    icon: PiggyBank,
    href: "/dashboard",
  },
  {
    title: "DA Tracker",
    description: "Track DA history, upcoming revisions and monthly impact across pay levels.",
    icon: TrendingUp,
    href: "/#da-tracker",
  },
  {
    title: "Salary Slip Generator",
    description: "Generate clean projection reports and shareable salary summaries.",
    icon: ReceiptText,
    href: "/dashboard",
  },
  {
    title: "Tax Comparison",
    description: "Compare old and new tax regimes with deductions built for salaried employees.",
    icon: CircleDollarSign,
    href: "/#tax",
  },
  {
    title: "Pay Matrix Intelligence",
    description: "Browse level-wise salary pages, matrix insights and fitment scenarios.",
    icon: LineChart,
    href: "/salary/level/7",
  },
];

export const trustSignals = [
  { label: "Official-formula inspired", icon: ShieldCheck },
  { label: "Privacy-first calculations", icon: Lock },
  { label: "Built for employees & pensioners", icon: Users },
  { label: "Report-ready outputs", icon: FileText },
];

export const dashboardCards = [
  { label: "Saved calculations", value: "24", delta: "+6 this month", icon: FileText },
  { label: "Projected in-hand", value: "₹1.18L", delta: "+₹31.4K vs current", icon: Landmark },
  { label: "DA alerts", value: "3", delta: "Next update in July", icon: Bell },
  { label: "Retirement corpus", value: "₹1.84Cr", delta: "8% CAGR scenario", icon: PiggyBank },
];

export const seoClusters = [
  "8th CPC salary calculator",
  "8th pay commission pension calculator",
  "central government DA calculator",
  "pay level salary after 8th CPC",
  "railway salary after 8th pay commission",
  "teacher salary calculator 2026",
  "defence pension calculator",
  "old vs new tax regime government employee",
];
