export type HraClass = "X" | "Y" | "Z";
export type TaxRegime = "new" | "old";

export type SalaryInput = {
  currentBasic: number;
  daPercent: number;
  hraClass: HraClass;
  fitmentFactor: number;
  npsPercent: number;
  taxRegime: TaxRegime;
  extraDeductionsAnnual: number;
  miscDeductionsMonthly: number;
  useBasicOnlyFitment: boolean;
  eighthCpcDaPercent: number;
};

export type TaxSlab = {
  range: string;
  rate: number;
  taxable: number;
  tax: number;
};

export type TaxResult = {
  taxableIncome: number;
  tax: number;
  cess: number;
  surcharge: number;
  rebate: number;
  totalTax: number;
  slabs: TaxSlab[];
};

export type SalaryResult = {
  level: number;
  old: SalarySide;
  projected: SalarySide;
  monthlyIncrease: number;
  annualIncrease: number;
  assumptions: string[];
};

export type SalarySide = {
  basic: number;
  da: number;
  hra: number;
  ta: number;
  gross: number;
  nps: number;
  taxMonthly: number;
  otherDeductions: number;
  net: number;
  tax: TaxResult;
};

export const payMatrix: Record<number, number> = {
  1: 18000,
  2: 19900,
  3: 21700,
  4: 25500,
  5: 29200,
  6: 35400,
  7: 44900,
  8: 47600,
  9: 53100,
  10: 56100,
  11: 67700,
  12: 78800,
  13: 123100,
  14: 144200,
  15: 182200,
  16: 205400,
  17: 225000,
  18: 250000,
};

export const hraRates: Record<HraClass, number> = { X: 0.24, Y: 0.16, Z: 0.08 };
export const standardDeduction: Record<TaxRegime, number> = { new: 75000, old: 50000 };

export const defaultSalaryInput: SalaryInput = {
  currentBasic: 44900,
  daPercent: 62,
  hraClass: "Y",
  fitmentFactor: 2.57,
  npsPercent: 10,
  taxRegime: "new",
  extraDeductionsAnnual: 0,
  miscDeductionsMonthly: 30,
  useBasicOnlyFitment: false,
  eighthCpcDaPercent: 0,
};

export function formatINR(value: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Math.round(safeNumber(value)));
}

export function nearestPayLevel(basic: number) {
  let level = 7;
  let distance = Number.POSITIVE_INFINITY;

  for (const [key, value] of Object.entries(payMatrix)) {
    const candidateDistance = Math.abs(value - basic);
    if (candidateDistance < distance) {
      distance = candidateDistance;
      level = Number(key);
    }
  }

  return level;
}

export function transportAllowance(level: number) {
  if (level <= 2) return 1350;
  if (level <= 8) return 3600;
  return 7200;
}

export function calculateTax(annualIncome: number, regime: TaxRegime): TaxResult {
  const taxableIncome = Math.max(0, safeNumber(annualIncome));
  const slabs: TaxSlab[] = [];
  let tax = 0;
  let rebate = 0;

  const slabConfig =
    regime === "new"
      ? [
          [0, 300000, 0],
          [300000, 700000, 5],
          [700000, 1000000, 10],
          [1000000, 1200000, 15],
          [1200000, 1500000, 20],
          [1500000, Number.POSITIVE_INFINITY, 30],
        ]
      : [
          [0, 250000, 0],
          [250000, 500000, 5],
          [500000, 1000000, 20],
          [1000000, Number.POSITIVE_INFINITY, 30],
        ];

  for (const [from, to, rate] of slabConfig) {
    if (taxableIncome <= from) continue;
    const slabTaxable = Math.max(0, Math.min(taxableIncome, to) - from);
    const slabTax = (slabTaxable * rate) / 100;
    tax += slabTax;
    slabs.push({
      range: `${formatShortINR(from)}-${Number.isFinite(to) ? formatShortINR(to) : "above"}`,
      rate,
      taxable: slabTaxable,
      tax: slabTax,
    });
  }

  if ((regime === "new" && taxableIncome <= 700000) || (regime === "old" && taxableIncome <= 500000)) {
    rebate = tax;
    tax = 0;
  }

  const surcharge = calculateSurcharge(taxableIncome, tax);
  const cess = (tax + surcharge) * 0.04;

  return {
    taxableIncome,
    tax,
    cess,
    surcharge,
    rebate,
    totalTax: tax + surcharge + cess,
    slabs,
  };
}

export function calculateSalary(input: SalaryInput): SalaryResult {
  const currentBasic = clamp(input.currentBasic, 18000, 250000);
  const daPercent = clamp(input.daPercent, 0, 200);
  const fitmentFactor = clamp(input.fitmentFactor, 1.92, 3.83);
  const npsPercent = clamp(input.npsPercent, 0, 20);
  const eighthCpcDaPercent = clamp(input.eighthCpcDaPercent, 0, 100);
  const level = nearestPayLevel(currentBasic);
  const taBase = transportAllowance(level);
  const stdDeduction = standardDeduction[input.taxRegime];

  const oldDa = currentBasic * (daPercent / 100);
  const oldTa = taBase + taBase * (daPercent / 100);
  const oldHra = currentBasic * hraRates[input.hraClass];
  const oldGross = currentBasic + oldDa + oldHra + oldTa;
  const oldNps = Math.round((currentBasic + oldDa) * (npsPercent / 100));
  const oldTax = calculateTax(oldGross * 12 - stdDeduction - input.extraDeductionsAnnual, input.taxRegime);
  const oldTaxMonthly = oldTax.totalTax / 12;
  const oldNet = oldGross - oldNps - input.miscDeductionsMonthly - oldTaxMonthly;

  const projectedBasic = Math.round(
    input.useBasicOnlyFitment ? currentBasic * fitmentFactor : (currentBasic + oldDa) * fitmentFactor,
  );
  const projectedDa = projectedBasic * (eighthCpcDaPercent / 100);
  const projectedHra = projectedBasic * hraRates[input.hraClass];
  const projectedTa = taBase * fitmentFactor;
  const projectedGross = projectedBasic + projectedDa + projectedHra + projectedTa;
  const projectedNps = Math.round((projectedBasic + projectedDa) * (npsPercent / 100));
  const projectedTax = calculateTax(
    projectedGross * 12 - stdDeduction - input.extraDeductionsAnnual,
    input.taxRegime,
  );
  const projectedTaxMonthly = projectedTax.totalTax / 12;
  const projectedNet = projectedGross - projectedNps - input.miscDeductionsMonthly - projectedTaxMonthly;

  const monthlyIncrease = projectedNet - oldNet;

  return {
    level,
    old: {
      basic: currentBasic,
      da: oldDa,
      hra: oldHra,
      ta: oldTa,
      gross: oldGross,
      nps: oldNps,
      taxMonthly: oldTaxMonthly,
      otherDeductions: input.miscDeductionsMonthly,
      net: oldNet,
      tax: oldTax,
    },
    projected: {
      basic: projectedBasic,
      da: projectedDa,
      hra: projectedHra,
      ta: projectedTa,
      gross: projectedGross,
      nps: projectedNps,
      taxMonthly: projectedTaxMonthly,
      otherDeductions: input.miscDeductionsMonthly,
      net: projectedNet,
      tax: projectedTax,
    },
    monthlyIncrease,
    annualIncrease: monthlyIncrease * 12,
    assumptions: [
      `${fitmentFactor.toFixed(2)}x fitment factor`,
      `${eighthCpcDaPercent}% projected DA after reset`,
      `${input.hraClass} city HRA at ${(hraRates[input.hraClass] * 100).toFixed(0)}%`,
      `${input.taxRegime === "new" ? "New" : "Old"} tax regime with ${formatINR(stdDeduction)} standard deduction`,
    ],
  };
}

function calculateSurcharge(taxableIncome: number, tax: number) {
  if (taxableIncome > 50000000) return tax * 0.37;
  if (taxableIncome > 20000000) return tax * 0.25;
  if (taxableIncome > 10000000) return tax * 0.15;
  if (taxableIncome > 5000000) return tax * 0.1;
  return 0;
}

function formatShortINR(value: number) {
  if (value === 0) return "₹0";
  if (value >= 100000) return `₹${value / 100000}L`;
  return formatINR(value);
}

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(safeNumber(value), min), max);
}

function safeNumber(value: number) {
  return Number.isFinite(value) ? value : 0;
}
