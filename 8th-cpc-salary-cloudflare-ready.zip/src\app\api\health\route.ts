import { NextResponse } from "next/server";

export function GET() {
  return NextResponse.json({
    ok: true,
    service: "8th-cpc-salary-platform",
    timestamp: new Date().toISOString(),
  });
}
