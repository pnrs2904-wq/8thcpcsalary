import Link from "next/link";
import { ArrowRight, BadgeIndianRupee, CheckCircle2, Crown, Sparkles } from "lucide-react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { SalaryCalculator } from "@/components/salary-calculator";
import { dashboardCards, seoClusters, toolModules, trustSignals } from "@/data/platform";

export default function HomePage() {
  return (
    <>
      <Header />
      <main>
        <section className="container-shell grid gap-8 py-10 lg:grid-cols-[1.05fr_0.95fr] lg:py-14">
          <div className="flex flex-col justify-center">
            <div className="inline-flex w-fit items-center gap-2 rounded-full border border-orange-200 bg-orange-50 px-3 py-2 text-sm font-black text-[var(--saffron)]">
              <Sparkles size={16} />
              India&apos;s Most Advanced Government Salary & Pension Platform
            </div>
            <h1 className="mt-5 text-4xl font-black tracking-tight text-[#071d49] md:text-6xl">
              8th Pay Commission salary intelligence for every government employee.
            </h1>
            <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-600">
              Calculate 8th CPC salary, pension, DA, tax and retirement projections with a fintech-grade dashboard built for
              central employees, state staff, defence, railways, teachers, PSUs and pensioners.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/calculators/8th-cpc-salary" className="focus-ring inline-flex items-center gap-2 rounded-full bg-[var(--india-blue)] px-5 py-3 font-black text-white shadow-lg shadow-blue-900/20">
                Start Calculator
                <ArrowRight size={18} />
              </Link>
              <Link href="/dashboard" className="focus-ring inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-3 font-black shadow-sm">
                View SaaS Dashboard
              </Link>
            </div>
            <div className="mt-7 grid gap-3 sm:grid-cols-2">
              {trustSignals.map((item) => (
                <div key={item.label} className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 text-sm font-bold shadow-sm">
                  <item.icon size={18} className="text-[var(--green)]" />
                  {item.label}
                </div>
              ))}
            </div>
          </div>

          <div className="glass rounded-lg p-4">
            <div className="grid gap-4">
              <div className="rounded-lg bg-[#071d49] p-5 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-100">Projected monthly gain</p>
                    <div className="metric-value mt-2 text-4xl font-black">₹31,428</div>
                  </div>
                  <BadgeIndianRupee size={40} className="text-orange-300" />
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                {dashboardCards.map((card) => (
                  <div key={card.label} className="rounded-lg border border-slate-200 bg-white p-4">
                    <card.icon size={18} className="text-[var(--india-blue)]" />
                    <div className="metric-value mt-3 text-2xl font-black">{card.value}</div>
                    <div className="text-sm font-bold text-slate-700">{card.label}</div>
                    <div className="mt-1 text-xs text-[var(--green)]">{card.delta}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <SalaryCalculator compact />

        <section className="container-shell py-8" id="da-tracker">
          <div className="grid gap-5 lg:grid-cols-[0.72fr_1.28fr]">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Platform Modules</p>
              <h2 className="mt-2 text-3xl font-black tracking-tight">A full operating system for salary planning.</h2>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              {toolModules.map((tool) => (
                <Link key={tool.title} href={tool.href} className="card group p-5 transition hover:-translate-y-1 hover:shadow-xl">
                  <tool.icon size={22} className="text-[var(--india-blue)]" />
                  <h3 className="mt-4 font-black">{tool.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-[var(--muted)]">{tool.description}</p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="container-shell py-8" id="monetization">
          <div className="grid gap-5 lg:grid-cols-3">
            <PlanCard title="Free" price="₹0" features={["Core calculators", "Shareable salary summary", "Ad-supported experience"]} />
            <PlanCard title="Premium" price="₹199/mo" featured features={["Unlimited saved reports", "PDF exports", "Retirement projections", "Ad-free dashboard"]} />
            <PlanCard title="Union / Department" price="Custom" features={["Bulk employee planning", "Private dashboards", "Custom salary rules", "Priority support"]} />
          </div>
        </section>

        <section className="container-shell py-8">
          <div className="card p-6">
            <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
              <div>
                <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Programmatic SEO</p>
                <h2 className="mt-2 text-2xl font-black">Scalable topical authority structure</h2>
              </div>
              <div className="ad-slot w-full md:w-80">Advertisement</div>
            </div>
            <div className="mt-6 flex flex-wrap gap-2">
              {seoClusters.map((item) => (
                <span key={item} className="rounded-full border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-bold text-slate-700">
                  {item}
                </span>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function PlanCard({ title, price, features, featured = false }: { title: string; price: string; features: string[]; featured?: boolean }) {
  return (
    <div className={`card p-6 ${featured ? "border-[var(--saffron)] shadow-xl" : ""}`}>
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-black">{title}</h3>
        {featured && <Crown size={20} className="text-[var(--saffron)]" />}
      </div>
      <div className="metric-value mt-4 text-3xl font-black">{price}</div>
      <div className="mt-5 grid gap-3">
        {features.map((feature) => (
          <div key={feature} className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <CheckCircle2 size={16} className="text-[var(--green)]" />
            {feature}
          </div>
        ))}
      </div>
      <button className={`focus-ring mt-6 w-full rounded-full px-4 py-3 font-black ${featured ? "bg-[var(--india-blue)] text-white" : "border border-slate-200 bg-white"}`}>
        {featured ? "Upgrade with Razorpay" : "Get Started"}
      </button>
    </div>
  );
}
