import Image from "next/image";
import Link from "next/link";
import { Bell, LayoutDashboard, Menu, ShieldCheck } from "lucide-react";

const nav = [
  { label: "Calculator", href: "/calculators/8th-cpc-salary" },
  { label: "DA Tracker", href: "/#da-tracker" },
  { label: "Pension", href: "/#pension" },
  { label: "Dashboard", href: "/dashboard" },
];

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur-xl">
      <div className="tricolor" />
      <div className="container-shell flex h-16 items-center justify-between gap-4">
        <Link href="/" aria-label="8thCPCSalary home" className="flex items-center">
          <Image src="/gemini-svg.svg" alt="8thCPCSalary.com" width={300} height={72} priority className="h-12 w-auto" />
        </Link>
        <nav className="hidden items-center rounded-full border border-slate-200 bg-slate-50 p-1 lg:flex">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-full px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-white hover:text-[var(--india-blue)] hover:shadow-sm"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link
            href="/dashboard"
            className="hidden items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-semibold shadow-sm transition hover:border-[var(--india-blue)] sm:flex"
          >
            <LayoutDashboard size={16} />
            Dashboard
          </Link>
          <button aria-label="Notifications" className="focus-ring grid h-10 w-10 place-items-center rounded-full border border-slate-200 bg-white shadow-sm">
            <Bell size={17} />
          </button>
          <button aria-label="Open menu" className="focus-ring grid h-10 w-10 place-items-center rounded-full border border-slate-200 bg-white shadow-sm lg:hidden">
            <Menu size={18} />
          </button>
        </div>
      </div>
      <div className="hidden border-t border-slate-100 bg-slate-50/80 py-2 text-xs font-semibold text-slate-600 md:block">
        <div className="container-shell flex items-center justify-center gap-2">
          <ShieldCheck size={14} className="text-[var(--green)]" />
          Projection tools are informational and should be verified against official circulars before financial decisions.
        </div>
      </div>
    </header>
  );
}
