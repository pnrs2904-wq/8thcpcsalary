import type { Metadata } from "next";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { SalaryCalculator } from "@/components/salary-calculator";

export const metadata: Metadata = {
  title: "8th CPC Salary Calculator 2026",
  description:
    "Calculate expected 8th Pay Commission salary with DA, HRA, NPS, tax and in-hand comparison against 7th CPC.",
  alternates: { canonical: "/calculators/8th-cpc-salary" },
};

export default function CalculatorPage() {
  return (
    <>
      <Header />
      <main>
        <section className="container-shell py-8">
          <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Calculator Landing Page</p>
          <h1 className="mt-2 text-4xl font-black tracking-tight text-[#071d49]">8th CPC Salary Calculator 2026</h1>
          <p className="mt-3 max-w-3xl text-lg leading-8 text-slate-600">
            Use this professional calculator to estimate projected 8th CPC in-hand pay, gross salary, deductions, tax and
            annual gain. Inputs stay in your browser unless you save them after authentication.
          </p>
        </section>
        <SalaryCalculator />
      </main>
      <Footer />
    </>
  );
}
