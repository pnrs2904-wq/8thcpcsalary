import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

export default function DisclaimerPage() {
  return (
    <>
      <Header />
      <main className="container-shell py-10">
        <article className="card p-6">
          <p className="text-sm font-black uppercase tracking-[0.16em] text-[var(--saffron)]">Disclaimer</p>
          <h1 className="mt-2 text-4xl font-black">Disclaimer</h1>
          <p className="mt-5 max-w-3xl text-lg leading-8 text-slate-700">
            8thCPCSalary.com is not a government website. Calculations are estimates for planning and education. Official
            salary, pension, tax and DA decisions must be confirmed from competent authorities.
          </p>
          <p className="mt-5 text-sm font-semibold text-slate-500">Last updated: May 27, 2026</p>
        </article>
      </main>
      <Footer />
    </>
  );
}
