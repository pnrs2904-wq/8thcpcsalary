import Link from "next/link";
import { site } from "@/data/platform";

const legal = ["About Us", "Contact", "Privacy Policy", "Terms & Conditions", "Editorial Policy", "Disclaimer"];

export function Footer() {
  return (
    <footer className="mt-16 border-t border-slate-200 bg-[#071227] text-white">
      <div className="container-shell grid gap-8 py-10 md:grid-cols-[1.2fr_0.8fr_0.8fr]">
        <div>
          <div className="text-lg font-black">{site.name}</div>
          <p className="mt-3 max-w-md text-sm leading-7 text-slate-300">
            India-focused salary, pension, DA and retirement planning platform for government employees. Built for clarity,
            trust and repeat financial planning.
          </p>
        </div>
        <div>
          <div className="text-sm font-bold uppercase tracking-[0.14em] text-slate-400">Platform</div>
          <div className="mt-4 grid gap-2 text-sm text-slate-300">
            <Link href="/calculators/8th-cpc-salary">8th CPC Calculator</Link>
            <Link href="/dashboard">Dashboard</Link>
            <Link href="/salary/level/7">Pay Level Pages</Link>
          </div>
        </div>
        <div>
          <div className="text-sm font-bold uppercase tracking-[0.14em] text-slate-400">AdSense Trust Pages</div>
          <div className="mt-4 grid gap-2 text-sm text-slate-300">
            {legal.map((item) => (
              <Link key={item} href={`/${item.toLowerCase().replaceAll(" ", "-").replaceAll("&", "and")}`}>
                {item}
              </Link>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-slate-400">
        Updated May 27, 2026. This platform is independent and not affiliated with the Government of India.
      </div>
    </footer>
  );
}
